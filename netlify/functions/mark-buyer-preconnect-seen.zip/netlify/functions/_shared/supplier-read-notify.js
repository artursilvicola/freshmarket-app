var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var supplier_read_notify_exports = {};
__export(supplier_read_notify_exports, {
  notifySupplierOfferRead: () => notifySupplierOfferRead,
  notifySupplierOffersRead: () => notifySupplierOffersRead
});
module.exports = __toCommonJS(supplier_read_notify_exports);
var import_supplier_email_templates = require("./supplier-email-templates.js");
function isUuidLike(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value || ""));
}
async function findCompanyBySupplierKey(supaSvc, supplierKey) {
  if (!supplierKey) return null;
  const { data: byLegacy, error: legacyErr } = await supaSvc.from("companies").select("id, name, legacy_supplier_id").eq("legacy_supplier_id", supplierKey).maybeSingle();
  if (legacyErr) throw legacyErr;
  if (byLegacy) return byLegacy;
  if (!isUuidLike(supplierKey)) return null;
  const { data: byId, error: idErr } = await supaSvc.from("companies").select("id, name, legacy_supplier_id").eq("id", supplierKey).maybeSingle();
  if (idErr) throw idErr;
  return byId || null;
}
async function sendResendEmail({ env, to, subject, html }) {
  if (!env.resendApiKey) return { ok: false, reason: "no_resend_key" };
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.resendApiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from: "Fresh Market <newsletter@freshmarket.eu>",
      to: [to],
      subject,
      html
    })
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    return { ok: false, reason: `resend_${res.status}: ${detail}` };
  }
  const r = await res.json().catch(() => ({}));
  return { ok: true, message_id: r.id || null };
}
function pickOfferTitle(offer, fallbackId) {
  return offer?.title || offer?.product || `Oferta #${fallbackId || ""}`.trim();
}
async function notifySupplierOffersRead({ supaSvc, env, legacyIds, openedVia }) {
  const ids = [...new Set((legacyIds || []).map(Number).filter((id) => Number.isFinite(id) && id > 0))];
  if (!ids.length) return { ok: true, status: "skipped", reason: "missing_legacy_ids", notifications: [] };
  const { data: rows, error: rowErr } = await supaSvc.from("legacy_sends").select("legacy_id, status, data, retailer_id, offer_legacy_id, supplier_legacy_id").in("legacy_id", ids);
  if (rowErr) return { ok: false, status: "error", reason: rowErr.message, notifications: [] };
  const pendingRows = (rows || []).filter((row) => !(row.data || {}).supplierNotifiedAt);
  if (!pendingRows.length) {
    return { ok: true, status: "skipped", reason: "already_notified", notifications: [] };
  }
  const offerIds = [...new Set(pendingRows.map((row) => row.offer_legacy_id || row.data?.offerId).filter(Boolean))];
  const offerMap = /* @__PURE__ */ new Map();
  if (offerIds.length) {
    const { data: offerRows } = await supaSvc.from("legacy_offers").select("legacy_id, data").in("legacy_id", offerIds);
    for (const offerRow of offerRows || []) {
      offerMap.set(String(offerRow.legacy_id), offerRow.data || {});
    }
  }
  const retailerIds = [...new Set(pendingRows.map((row) => row.retailer_id).filter(Boolean))];
  const retailerMap = /* @__PURE__ */ new Map();
  if (retailerIds.length) {
    const { data: retailerRows } = await supaSvc.from("retailers").select("id, name").in("id", retailerIds);
    for (const retailer of retailerRows || []) {
      retailerMap.set(Number(retailer.id), retailer);
    }
  }
  const companyCache = /* @__PURE__ */ new Map();
  const groups = /* @__PURE__ */ new Map();
  const errors = [];
  for (const row of pendingRows) {
    try {
      const supplierKey = row.supplier_legacy_id || row.data?.supplierId;
      if (!companyCache.has(supplierKey)) {
        companyCache.set(supplierKey, await findCompanyBySupplierKey(supaSvc, supplierKey));
      }
      const company = companyCache.get(supplierKey);
      if (!company?.id) {
        errors.push({ legacy_id: row.legacy_id, ok: false, status: "error", reason: "company_not_found" });
        continue;
      }
      const groupKey = `${company.id}|${row.retailer_id || "none"}`;
      if (!groups.has(groupKey)) {
        groups.set(groupKey, {
          company,
          retailer: retailerMap.get(Number(row.retailer_id)) || null,
          rows: [],
          offers: []
        });
      }
      const offerId = row.offer_legacy_id || row.data?.offerId;
      const offer = offerMap.get(String(offerId)) || {};
      const title = pickOfferTitle(offer, offerId || row.legacy_id);
      const group = groups.get(groupKey);
      group.rows.push(row);
      group.offers.push({ title });
    } catch (e) {
      errors.push({ legacy_id: row.legacy_id, ok: false, status: "error", reason: e?.message || String(e) });
    }
  }
  const notifications = [...errors];
  for (const group of groups.values()) {
    const { data: owner } = await supaSvc.from("profiles").select("name, email, active, locale").eq("company_id", group.company.id).eq("role", "supplier").eq("active", true).order("created_at", { ascending: true }).limit(1).maybeSingle();
    if (!owner?.email) {
      try {
        console.log("[notifySupplierOffersRead OWNER_NOT_FOUND]", JSON.stringify({ company_id: group.company.id, company_name: group.company.name }));
      } catch (e) {
      }
      notifications.push({
        ok: false,
        status: "error",
        reason: "owner_not_found",
        legacy_ids: group.rows.map((row) => row.legacy_id)
      });
      continue;
    }
    try {
      console.log("[notifySupplierOffersRead OWNER]", JSON.stringify({ company_id: group.company.id, owner_email: owner.email, offer_count: group.offers.length }));
    } catch (e) {
    }
    const openedAt = (/* @__PURE__ */ new Date()).toISOString().slice(0, 16).replace("T", " ");
    const tpl = (0, import_supplier_email_templates.pickTemplate)("offers_read_by_buyer", {
      companyName: group.company.name || "",
      contactName: owner.name || null,
      offers: group.offers,
      offerCount: group.offers.length,
      retailerName: group.retailer?.name || "",
      openedVia,
      openedAt,
      appUrl: env.b2bAppUrl,
      // [P2-backend-mails C2] locale → tplOffersReadByBuyer dispatcher.
      locale: owner.locale || "pl"
    });
    if (!tpl) {
      notifications.push({ ok: false, status: "error", reason: "no_template" });
      continue;
    }
    const sent = await sendResendEmail({ env, to: owner.email, subject: tpl.subject, html: tpl.html });
    try {
      console.log("[notifySupplierOffersRead RESEND]", JSON.stringify({ to: owner.email, subject: tpl.subject, ok: sent.ok, reason: sent.reason, message_id: sent.message_id }));
    } catch (e) {
    }
    if (!sent.ok) {
      notifications.push({
        ok: false,
        status: "error",
        reason: sent.reason,
        to: owner.email,
        legacy_ids: group.rows.map((row) => row.legacy_id)
      });
      continue;
    }
    const notifiedAt = (/* @__PURE__ */ new Date()).toISOString();
    const groupIds = group.rows.map((row) => Number(row.legacy_id));
    const { data: markedCount, error: markErr } = await supaSvc.rpc("mark_legacy_sends_supplier_notified", {
      p_legacy_ids: groupIds,
      p_via: openedVia,
      p_batch_size: group.rows.length,
      p_notified_at: notifiedAt
    });
    if (markErr) {
      try {
        console.log("[notifySupplierOffersRead MARK_ERROR]", JSON.stringify({ legacy_ids: groupIds, reason: markErr.message }));
      } catch (e) {
      }
    }
    notifications.push({
      ok: !markErr,
      status: "sent",
      message_id: sent.message_id,
      to: owner.email,
      offer_count: group.offers.length,
      legacy_ids: groupIds,
      marker_ok: !markErr,
      marker_rows: markErr ? null : Number(markedCount ?? 0),
      ...markErr ? { marker_error: markErr.message } : {}
    });
  }
  const sentCount = notifications.filter((n) => n.status === "sent").length;
  try {
    console.log("[notifySupplierOffersRead DONE]", JSON.stringify({ openedVia, sentCount, total: notifications.length, notifications }));
  } catch (e) {
  }
  return {
    ok: notifications.every((n) => n.ok),
    status: sentCount ? "sent" : "error",
    notifications
  };
}
async function notifySupplierOfferRead({ supaSvc, env, legacyId, openedVia }) {
  const result = await notifySupplierOffersRead({
    supaSvc,
    env,
    legacyIds: [legacyId],
    openedVia
  });
  const first = result.notifications?.[0];
  if (first) return first;
  return { ok: result.ok, status: result.status, reason: result.reason };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  notifySupplierOfferRead,
  notifySupplierOffersRead
});
