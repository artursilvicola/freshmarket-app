var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var payu_exports = {};
__export(payu_exports, {
  createPayuOrder: () => createPayuOrder,
  fetchPayuToken: () => fetchPayuToken,
  normalizePayuCurrencyCode: () => normalizePayuCurrencyCode,
  parsePayuStatusCode: () => parsePayuStatusCode,
  parsePositiveNumber: () => parsePositiveNumber,
  payuBaseUrl: () => payuBaseUrl,
  toMinorUnits: () => toMinorUnits,
  verifyPayuSignature: () => verifyPayuSignature
});
module.exports = __toCommonJS(payu_exports);
var import_node_crypto = __toESM(require("node:crypto"), 1);
const MINOR_UNIT_FACTOR = {
  BIF: 1,
  CLP: 1,
  DJF: 1,
  GNF: 1,
  JPY: 1,
  KMF: 1,
  KRW: 1,
  MGA: 1,
  PYG: 1,
  RWF: 1,
  UGX: 1,
  VND: 1,
  VUV: 1,
  XAF: 1,
  XOF: 1,
  XPF: 1
};
function payuBaseUrl(env) {
  const normalized = String(env || "sandbox").trim().toLowerCase();
  return ["production", "prod", "live"].includes(normalized) ? "https://secure.payu.com" : "https://secure.snd.payu.com";
}
async function fetchPayuToken({ baseUrl, clientId, clientSecret }) {
  const tokenUrl = `${baseUrl}/pl/standard/user/oauth/authorize`;
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret
  });
  const res = await fetch(tokenUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString()
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`PayU OAuth ${res.status}: ${detail || res.statusText}`);
  }
  const data = await res.json();
  if (!data.access_token) {
    throw new Error("PayU OAuth: brak access_token w odpowiedzi");
  }
  return data.access_token;
}
function normalizePayuCurrencyCode(value) {
  const code = String(value || "EUR").trim().toUpperCase();
  if (!/^[A-Z]{3}$/.test(code)) {
    throw new Error(`Nieprawidlowa waluta PayU: ${value || "(pusta)"}`);
  }
  return code;
}
function parsePositiveNumber(value, fallback = null) {
  if (value == null || value === "") return fallback;
  const normalized = String(value).trim().replace(",", ".");
  const parsed = Number(normalized);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
function toMinorUnits(amount, currencyCode = "EUR") {
  const factor = MINOR_UNIT_FACTOR[currencyCode] || 100;
  return String(Math.round(Number(amount) * factor));
}
function parsePayuStatusCode(error) {
  const message = String(error?.message || error || "");
  const match = message.match(/"statusCode"\s*:\s*"([^"]+)"/);
  return match?.[1] || null;
}
async function createPayuOrder({
  baseUrl,
  accessToken,
  posId,
  customerIp,
  description,
  currencyCode,
  totalAmount,
  // string, w groszach/centach (np. "60000" = 600.00 EUR)
  extOrderId,
  buyer,
  // { email, firstName, lastName, phone, language }
  products,
  // [{ name, unitPrice, quantity }]
  notifyUrl,
  continueUrl,
  metadata
}) {
  const orderUrl = `${baseUrl}/api/v2_1/orders`;
  const payload = {
    notifyUrl,
    continueUrl,
    customerIp: customerIp || "127.0.0.1",
    merchantPosId: posId,
    description,
    currencyCode,
    totalAmount,
    extOrderId,
    buyer: buyer || void 0,
    products
  };
  const res = await fetch(orderUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    },
    body: JSON.stringify(payload),
    redirect: "manual"
  });
  const body = await readPayuBody(res);
  const json = body.json;
  if (res.status !== 200 && res.status !== 302) {
    const detail = json ? JSON.stringify(json) : body.text;
    throw new Error(`PayU createOrder ${res.status}: ${detail || res.statusText}`);
  }
  const redirectUri = json?.redirectUri || res.headers.get("location");
  const orderId = json?.orderId || null;
  const statusCode = json?.status?.statusCode || (res.status === 302 ? "SUCCESS" : null);
  if (!redirectUri) {
    const detail = json ? JSON.stringify(json) : body.text;
    throw new Error(`PayU createOrder: brak redirectUri w odpowiedzi (${detail || `HTTP ${res.status}`})`);
  }
  return {
    redirectUri,
    orderId,
    extOrderId,
    statusCode,
    raw: {
      request: { ...payload, metadata },
      response: json,
      httpStatus: res.status,
      location: res.headers.get("location")
    }
  };
}
async function readPayuBody(res) {
  const text = await res.text().catch(() => "");
  if (!text) return { text: "", json: null };
  try {
    return { text, json: JSON.parse(text) };
  } catch {
    return { text, json: null };
  }
}
function verifyPayuSignature({ rawBody, signatureHeader, secondKey }) {
  if (!signatureHeader || !rawBody || !secondKey) return false;
  const parts = signatureHeader.split(";").reduce((acc, p) => {
    const [k, v] = p.split("=");
    if (k && v) acc[k.trim()] = v.trim();
    return acc;
  }, {});
  const sig = parts.signature;
  const algo = (parts.algorithm || "SHA-256").toUpperCase();
  if (!sig) return false;
  if (algo !== "SHA-256" && algo !== "SHA256" && algo !== "MD5") return false;
  const hashAlgo = algo === "MD5" ? "md5" : "sha256";
  const computed = import_node_crypto.default.createHash(hashAlgo).update(rawBody + secondKey, "utf8").digest("hex");
  return import_node_crypto.default.timingSafeEqual(
    Buffer.from(computed, "hex"),
    Buffer.from(sig, "hex")
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createPayuOrder,
  fetchPayuToken,
  normalizePayuCurrencyCode,
  parsePayuStatusCode,
  parsePositiveNumber,
  payuBaseUrl,
  toMinorUnits,
  verifyPayuSignature
});
