var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var payu_notify_exports = {};
__export(payu_notify_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(payu_notify_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_payu = require("./_shared/payu.js");
const handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "Method Not Allowed" });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey", "payuSecondKey"]);
  if (missing.length) {
    console.error("[payu-notify] brak konfiguracji:", missing);
    return reply(200, { ignored: "missing_env", missing });
  }
  const rawBody = event.body || "";
  const sigHeader = event.headers["openpayu-signature"] || event.headers["OpenPayU-Signature"] || event.headers["Openpayu-Signature"] || "";
  if (!(0, import_payu.verifyPayuSignature)({ rawBody, signatureHeader: sigHeader, secondKey: env.payuSecondKey })) {
    console.warn("[payu-notify] z\u0142a sygnatura, ignorujemy");
    return reply(200, { ignored: "bad_signature" });
  }
  let payload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return reply(200, { ignored: "invalid_json" });
  }
  const order = payload?.order;
  if (!order) return reply(200, { ignored: "no_order" });
  const payuOrderId = order.orderId;
  const extOrderId = order.extOrderId;
  const newStatus = String(order.status || "").toUpperCase();
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  let { data: row } = await supaSvc.from("payu_orders").select("*").eq("payu_order_id", payuOrderId).maybeSingle();
  if (!row && extOrderId) {
    const { data: row2 } = await supaSvc.from("payu_orders").select("*").eq("ext_order_id", extOrderId).maybeSingle();
    row = row2;
  }
  if (!row) {
    console.warn("[payu-notify] zam\xF3wienie nie znalezione", { payuOrderId, extOrderId });
    return reply(200, { ignored: "unknown_order", payuOrderId, extOrderId });
  }
  if (row.status === "completed") {
    return reply(200, { ok: true, idempotent: true });
  }
  if (newStatus === "COMPLETED") {
    const { data: pkgId, error: rpcErr } = await supaSvc.rpc("purchase_package", {
      p_company_id: row.company_id,
      p_plan_id: row.plan_id,
      p_price_paid: row.price_eur,
      p_currency: row.currency,
      p_payment_ref: payuOrderId || `payu-${row.id}`
    });
    if (rpcErr) {
      console.error("[payu-notify] purchase_package RPC error", rpcErr);
      await supaSvc.from("payu_orders").update({
        status: "failed",
        failure_reason: `RPC: ${rpcErr.message}`,
        raw_notify: payload
      }).eq("id", row.id);
      return reply(200, { error: "rpc_failed", message: rpcErr.message });
    }
    await supaSvc.from("payu_orders").update({
      status: "completed",
      package_id: pkgId,
      payment_method: order.payMethod?.type || order.payMethod || null,
      raw_notify: payload,
      completed_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", row.id);
    return reply(200, { ok: true, package_id: pkgId });
  }
  if (newStatus === "CANCELED" || newStatus === "CANCELLED") {
    await supaSvc.from("payu_orders").update({
      status: "canceled",
      raw_notify: payload
    }).eq("id", row.id);
    return reply(200, { ok: true, status: "canceled" });
  }
  if (newStatus === "REJECTED") {
    await supaSvc.from("payu_orders").update({
      status: "rejected",
      raw_notify: payload
    }).eq("id", row.id);
    return reply(200, { ok: true, status: "rejected" });
  }
  await supaSvc.from("payu_orders").update({
    status: "pending",
    raw_notify: payload
  }).eq("id", row.id);
  return reply(200, { ok: true, status: newStatus });
};
function reply(statusCode, payload) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
