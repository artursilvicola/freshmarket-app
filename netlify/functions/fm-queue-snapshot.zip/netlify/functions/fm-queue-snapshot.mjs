
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/fm-queue-snapshot.js
import { createClient } from "@supabase/supabase-js";

// netlify/functions/_shared/netlify-modern.js
function getEnv(name) {
  try {
    const v = globalThis.Netlify?.env?.get?.(name);
    if (v != null && v !== "") return v;
  } catch {
  }
  return process.env[name] ?? "";
}
function envConfig() {
  const first = (...keys) => keys.map(getEnv).find(Boolean) || "";
  return {
    supabaseUrl: first("SUPABASE_URL", "VITE_SUPABASE_URL"),
    supabaseAnonKey: first("SUPABASE_ANON_KEY", "VITE_SUPABASE_ANON_KEY"),
    supabaseServiceRoleKey: first("SUPABASE_SERVICE_ROLE_KEY"),
    staffPinPepper: first("STAFF_PIN_PEPPER")
  };
}
function missingOf(cfg, keys) {
  return keys.filter((k) => !cfg[k]);
}
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, Accept-Language",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};

// netlify/functions/fm-queue-snapshot.js
var cached = (status, payload, maxAge) => new Response(JSON.stringify(payload), {
  status,
  headers: {
    ...CORS,
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": maxAge ? `public, max-age=${maxAge}, s-maxage=${maxAge}, stale-while-revalidate=10` : "no-store",
    "Netlify-CDN-Cache-Control": maxAge ? `public, max-age=${maxAge}, stale-while-revalidate=10` : "no-store"
  }
});
var fm_queue_snapshot_default = async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (request.method !== "GET") return cached(405, { error: "Method not allowed" }, 0);
  const cfg = envConfig();
  const missing = missingOf(cfg, ["supabaseUrl", "supabaseAnonKey"]);
  if (missing.length) return cached(500, { error: `Brak konfiguracji: ${missing.join(", ")}` }, 0);
  const url = new URL(request.url);
  const d = url.searchParams.get("date") || "";
  const date = /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : null;
  const anon = createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: false } });
  const { data, error } = await anon.rpc("fm_queue_public_snapshot", { p_event_date: date });
  if (error) return cached(502, { error: "snapshot unavailable" }, 0);
  return cached(200, data, 5);
};
export {
  fm_queue_snapshot_default as default
};
