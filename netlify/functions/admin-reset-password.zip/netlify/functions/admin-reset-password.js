var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_reset_password_exports = {};
__export(admin_reset_password_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_reset_password_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_error_messages = require("./_shared/error-messages.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers: cors, body: (0, import_error_messages.errLoc)(locale, "method_not_allowed") };
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey", "supabaseAnonKey"]);
  if (missing.length) {
    return errJson(500, (0, import_function_env.envErrorPayload)("admin-reset-password", missing));
  }
  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader?.startsWith("Bearer ")) return errJson(401, (0, import_error_messages.errLoc)(locale, "no_auth_header"));
  const token = authHeader.slice(7);
  const supaUser = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } }
  });
  const { data: userData, error: uErr } = await supaUser.auth.getUser(token);
  if (uErr || !userData?.user) return errJson(401, (0, import_error_messages.errLoc)(locale, "invalid_token"));
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: caller, error: cErr } = await supaSvc.from("profiles").select("role, locale").eq("id", userData.user.id).maybeSingle();
  if (cErr || caller?.role !== "admin") return errJson(403, (0, import_error_messages.errLoc)(locale, "only_admin_reset_password"));
  locale = (0, import_error_messages.resolveLocale)({ profileLocale: caller.locale, acceptLanguage: acceptLang });
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return errJson(400, (0, import_error_messages.errLoc)(locale, "invalid_json"));
  }
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, profileLocale: caller.locale, acceptLanguage: acceptLang });
  const { email, new_password, send_magic_link = false } = body;
  if (!email) return errJson(400, (0, import_error_messages.errLoc)(locale, "missing_email_short"));
  if (!new_password && !send_magic_link) {
    return errJson(400, (0, import_error_messages.errLoc)(locale, "missing_user_password_or_link"));
  }
  const { data: profile } = await supaSvc.from("profiles").select("id, email").eq("email", email).maybeSingle();
  if (!profile?.id) return errJson(404, (0, import_error_messages.errLoc)(locale, "user_not_found"));
  if (new_password) {
    const { error: updErr } = await supaSvc.auth.admin.updateUserById(
      profile.id,
      { password: new_password }
    );
    if (updErr) return errJson(500, (0, import_error_messages.errLoc)(locale, "password_update_failed", { detail: updErr.message }));
    return okJson({ user_id: profile.id, email, password_reset: true });
  }
  const { data: linkData, error: linkErr } = await supaSvc.auth.admin.generateLink({
    type: "magiclink",
    email,
    options: {
      redirectTo: env.b2bAppUrl
    }
  });
  if (linkErr) return errJson(500, (0, import_error_messages.errLoc)(locale, "magic_link_failed", { detail: linkErr.message }));
  return okJson({
    user_id: profile.id,
    email,
    magic_link: linkData?.properties?.action_link || null
  });
};
function okJson(p) {
  return { statusCode: 200, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(p) };
}
function errJson(c, m) {
  return { statusCode: c, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(typeof m === "string" ? { error: m } : m) };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
