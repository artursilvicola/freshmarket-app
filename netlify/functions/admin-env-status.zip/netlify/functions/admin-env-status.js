var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_env_status_exports = {};
__export(admin_env_status_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_env_status_exports);
var import_function_env = require("./_shared/function-env.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, OPTIONS"
};
const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors };
  }
  if (event.httpMethod !== "GET") {
    return json(405, { error: "Method Not Allowed" });
  }
  const env = (0, import_function_env.resolveEnvConfig)();
  const missingAdmin = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseAnonKey", "supabaseServiceRoleKey"]);
  const missingSendOffer = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey", "resendApiKey"]);
  const missingAiFeatures = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseAnonKey", "supabaseServiceRoleKey", "openAiApiKey"]);
  const missingPayu = (0, import_function_env.missingEnvNames)(env, [
    "supabaseUrl",
    "supabaseServiceRoleKey",
    "payuPosId",
    "payuSecondKey",
    "payuClientId",
    "payuClientSecret",
    "payuCurrencyCode"
  ]);
  if (env.payuCurrencyCode !== "EUR" && !env.payuEurToPayuRate) {
    missingPayu.push("PAYU_EUR_TO_PAYU_RATE");
  }
  return json(200, {
    ok: missingAdmin.length === 0 && missingSendOffer.length === 0 && missingAiFeatures.length === 0 && missingPayu.length === 0,
    checks: {
      adminUsers: {
        ok: missingAdmin.length === 0,
        missing: missingAdmin
      },
      sendOffer: {
        ok: missingSendOffer.length === 0,
        missing: missingSendOffer
      },
      aiFeatures: {
        ok: missingAiFeatures.length === 0,
        missing: missingAiFeatures
      },
      payu: {
        ok: missingPayu.length === 0,
        missing: missingPayu
      }
    },
    hint: "Ustaw brakuj\u0105ce zmienne w Netlify -> Site configuration -> Environment variables i zr\xF3b nowy deploy."
  });
};
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
