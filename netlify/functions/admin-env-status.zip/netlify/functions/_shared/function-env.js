var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var function_env_exports = {};
__export(function_env_exports, {
  envErrorPayload: () => envErrorPayload,
  getFirstEnv: () => getFirstEnv,
  missingEnvNames: () => missingEnvNames,
  resolveEnvConfig: () => resolveEnvConfig
});
module.exports = __toCommonJS(function_env_exports);
function getFirstEnv(...keys) {
  for (const key of keys) {
    const value = process.env[key];
    if (value) return value;
  }
  return null;
}
function resolveEnvConfig() {
  const supabaseUrl = getFirstEnv("SUPABASE_URL", "VITE_SUPABASE_URL");
  const supabaseAnonKey = getFirstEnv("SUPABASE_ANON_KEY", "VITE_SUPABASE_ANON_KEY");
  const supabaseServiceRoleKey = getFirstEnv("SUPABASE_SERVICE_ROLE_KEY");
  const resendApiKey = getFirstEnv("RESEND_API_KEY");
  const resendWebhookSecret = getFirstEnv("RESEND_WEBHOOK_SECRET");
  const openAiApiKey = getFirstEnv("OPENAI_API_KEY");
  const openAiModel = getFirstEnv("OPENAI_MODEL") || "gpt-4.1-mini";
  const b2bAppUrl = getFirstEnv("B2B_APP_URL") || "https://b2b.freshmarket.eu";
  const payuEnv = getFirstEnv("PAYU_ENV") || "sandbox";
  const payuPosId = getFirstEnv("PAYU_POS_ID");
  const payuSecondKey = getFirstEnv("PAYU_SECOND_KEY");
  const payuClientId = getFirstEnv("PAYU_OAUTH_CLIENT_ID");
  const payuClientSecret = getFirstEnv("PAYU_OAUTH_CLIENT_SECRET");
  const payuCurrencyCode = (getFirstEnv("PAYU_CURRENCY_CODE") || "EUR").trim().toUpperCase();
  const payuEurToPayuRate = getFirstEnv("PAYU_EUR_TO_PAYU_RATE");
  const payuVatRate = getFirstEnv("PAYU_VAT_RATE") || "23";
  return {
    supabaseUrl,
    supabaseAnonKey,
    supabaseServiceRoleKey,
    resendApiKey,
    resendWebhookSecret,
    openAiApiKey,
    openAiModel,
    b2bAppUrl,
    payuEnv,
    payuPosId,
    payuSecondKey,
    payuClientId,
    payuClientSecret,
    payuCurrencyCode,
    payuEurToPayuRate,
    payuVatRate
  };
}
function missingEnvNames(config, requiredKeys = []) {
  const mapping = {
    supabaseUrl: "SUPABASE_URL (lub VITE_SUPABASE_URL)",
    supabaseAnonKey: "SUPABASE_ANON_KEY (lub VITE_SUPABASE_ANON_KEY)",
    supabaseServiceRoleKey: "SUPABASE_SERVICE_ROLE_KEY",
    resendApiKey: "RESEND_API_KEY",
    resendWebhookSecret: "RESEND_WEBHOOK_SECRET",
    openAiApiKey: "OPENAI_API_KEY",
    openAiModel: "OPENAI_MODEL",
    b2bAppUrl: "B2B_APP_URL",
    payuEnv: "PAYU_ENV",
    payuPosId: "PAYU_POS_ID",
    payuSecondKey: "PAYU_SECOND_KEY",
    payuClientId: "PAYU_OAUTH_CLIENT_ID",
    payuClientSecret: "PAYU_OAUTH_CLIENT_SECRET",
    payuCurrencyCode: "PAYU_CURRENCY_CODE",
    payuEurToPayuRate: "PAYU_EUR_TO_PAYU_RATE",
    payuVatRate: "PAYU_VAT_RATE"
  };
  return requiredKeys.filter((key) => !config[key]).map((key) => mapping[key] || key);
}
function envErrorPayload(scope, missing) {
  return {
    error: `${scope}: brak konfiguracji \u015Brodowiska`,
    missing,
    hint: "Ustaw brakuj\u0105ce zmienne w Netlify -> Site configuration -> Environment variables i zr\xF3b nowy deploy."
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  envErrorPayload,
  getFirstEnv,
  missingEnvNames,
  resolveEnvConfig
});
