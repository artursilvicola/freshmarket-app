var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var generate_proforma_exports = {};
__export(generate_proforma_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generate_proforma_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_error_messages = require("./_shared/error-messages.js");
var import_proforma_template = require("./_shared/proforma-template.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const VAT_RATE = 23;
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return json(405, { error: (0, import_error_messages.errLoc)(locale, "method_not_allowed") });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey", "resendApiKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("generate-proforma", missing));
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return json(401, { error: (0, import_error_messages.errLoc)(locale, "no_auth_token") });
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: userData, error: userErr } = await supaSvc.auth.getUser(token);
  if (userErr || !userData?.user) return json(401, { error: (0, import_error_messages.errLoc)(locale, "invalid_token") });
  const userId = userData.user.id;
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "invalid_json") });
  }
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, acceptLanguage: acceptLang });
  const planId = String(body.plan_id || "").trim();
  if (!planId) return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_plan_id") });
  const { data: profile, error: profErr } = await supaSvc.from("profiles").select("id, email, name, role, company_id, locale, company:companies!company_id(id, name, nip, country, city)").eq("id", userId).maybeSingle();
  if (profErr || !profile) return json(403, { error: (0, import_error_messages.errLoc)(locale, "profile_not_found") });
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, profileLocale: profile.locale, acceptLanguage: acceptLang });
  if (profile.role !== "supplier" && profile.role !== "admin") {
    return json(403, { error: (0, import_error_messages.errLoc)(locale, "only_supplier_buy_pkg") });
  }
  const companyId = profile.company_id;
  if (!companyId) return json(400, { error: (0, import_error_messages.errLoc)(locale, "no_company_assigned") });
  const company = profile.company || {};
  const nip = String(company.nip || "").trim();
  if (!nip) return json(400, { error: (0, import_error_messages.errLoc)(locale, "proforma_nip_required") });
  const { data: plan, error: planErr } = await supaSvc.from("package_plans").select("*").eq("id", planId).eq("active", true).maybeSingle();
  if (planErr || !plan) return json(400, { error: (0, import_error_messages.errLoc)(locale, "plan_not_found", { planId }) });
  const net = Number(plan.price_eur);
  const vat = Math.round(net * (VAT_RATE / 100) * 100) / 100;
  const gross = Math.round((net + vat) * 100) / 100;
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const { data: seqData, error: seqErr } = await supaSvc.rpc("allocate_proforma_number", { p_year: year });
  if (seqErr || seqData == null) {
    return json(500, { error: (0, import_error_messages.errLoc)(locale, "proforma_number_failed", { detail: seqErr?.message || "unknown" }) });
  }
  const seq = Number(seqData);
  const number = `PF/${year}/${String(seq).padStart(6, "0")}`;
  let brandLogoUrl = null;
  try {
    const { data: settings } = await supaSvc.from("fm_settings").select("brand_logo_url").order("updated_at", { ascending: false }).limit(1).maybeSingle();
    brandLogoUrl = settings?.brand_logo_url || null;
  } catch {
    brandLogoUrl = null;
  }
  const issuedAt = (/* @__PURE__ */ new Date()).toISOString();
  const planLabel = `${plan.tier} ${plan.qty}`;
  const addressSnapshot = [company.city, company.country].filter(Boolean).join(", ");
  const { subject, html, emailIntro } = (0, import_proforma_template.renderProforma)({
    number,
    issuedAt,
    planLabel,
    qty: plan.qty,
    currency: "EUR",
    net,
    vatRate: VAT_RATE,
    vat,
    gross,
    company: { name: company.name, nip, address: addressSnapshot },
    brandLogoUrl,
    locale
  });
  const { data: row, error: insErr } = await supaSvc.from("proformas").insert({
    company_id: companyId,
    number,
    year,
    seq,
    plan_id: plan.id,
    qty: plan.qty,
    currency: "EUR",
    net_amount: net,
    vat_rate: VAT_RATE,
    vat_amount: vat,
    gross_amount: gross,
    company_name_snapshot: company.name || null,
    company_nip_snapshot: nip,
    company_address_snapshot: addressSnapshot || null,
    status: "pending",
    html,
    locale,
    issued_at: issuedAt
  }).select("id, number, status, issued_at, gross_amount, currency").single();
  if (insErr || !row) {
    return json(500, { error: (0, import_error_messages.errLoc)(locale, "proforma_create_failed", { detail: insErr?.message || "unknown" }) });
  }
  let emailed = false;
  try {
    const emailHtml = html.replace(
      "</body></html>",
      `<table role="presentation" width="100%"><tr><td align="center" style="padding:12px;color:#94a3b8;font-size:11px;font-family:Arial,sans-serif;">${escAttr(emailIntro)}</td></tr></table></body></html>`
    );
    const resendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${env.resendApiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "Fresh Market <newsletter@freshmarket.eu>",
        to: [profile.email],
        subject,
        html: emailHtml
      })
    });
    emailed = resendRes.ok;
  } catch {
    emailed = false;
  }
  return json(200, {
    proforma_id: row.id,
    number: row.number,
    status: row.status,
    gross: Number(row.gross_amount),
    currency: row.currency,
    issued_at: row.issued_at,
    html,
    emailed
  });
};
function escAttr(value) {
  return String(value ?? "").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
