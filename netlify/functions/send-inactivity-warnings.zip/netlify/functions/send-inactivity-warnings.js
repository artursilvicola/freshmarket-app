var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var send_inactivity_warnings_exports = {};
__export(send_inactivity_warnings_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(send_inactivity_warnings_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_error_messages = require("./_shared/error-messages.js");
var import_inactivity_template = require("./_shared/inactivity-template.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  const locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return json(405, { error: (0, import_error_messages.errLoc)(locale, "method_not_allowed") });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey", "resendApiKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("send-inactivity-warnings", missing));
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return json(401, { error: (0, import_error_messages.errLoc)(locale, "no_auth_token") });
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: userData, error: userErr } = await supaSvc.auth.getUser(token);
  if (userErr || !userData?.user) return json(401, { error: (0, import_error_messages.errLoc)(locale, "invalid_token") });
  const { data: rows, error: rpcErr } = await supaSvc.rpc("claim_due_inactivity_warnings", { p_limit: 200 });
  if (rpcErr) return json(500, { error: "claim_due_inactivity_warnings failed", detail: rpcErr.message });
  const claimed = Array.isArray(rows) ? rows : [];
  let sent = 0;
  const failures = [];
  for (const r of claimed) {
    const email = r.email;
    if (!email) continue;
    try {
      const { subject, html } = (0, import_inactivity_template.tplInactivityWarning)({
        name: r.name,
        stage: r.stage,
        deleteAfter: r.delete_after,
        appUrl: env.b2bAppUrl,
        locale: r.locale || "pl"
      });
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${env.resendApiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: "Fresh Market <newsletter@freshmarket.eu>",
          to: [email],
          subject,
          html
        })
      });
      if (res.ok) sent += 1;
      else failures.push({ profile_id: r.profile_id, stage: r.stage, status: res.status });
    } catch (e) {
      failures.push({ profile_id: r.profile_id, error: e?.message || String(e) });
    }
  }
  return json(200, { claimed: claimed.length, sent, failures: failures.length });
};
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
