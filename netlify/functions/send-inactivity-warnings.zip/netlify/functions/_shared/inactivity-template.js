var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var inactivity_template_exports = {};
__export(inactivity_template_exports, {
  tplInactivityWarning: () => tplInactivityWarning
});
module.exports = __toCommonJS(inactivity_template_exports);
function esc(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function fmtDMY(d) {
  const s = String(d || "").slice(0, 10);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  return m ? `${m[3]}.${m[2]}.${m[1]}` : s;
}
function pickLocale(input) {
  const raw = String(input || "pl").trim().toLowerCase().split(/[-_]/)[0];
  return raw === "en" ? "en" : "pl";
}
function shell({ title, body, appUrl, locale }) {
  const footerAddr = locale === "en" ? "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Poland" : "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Polska";
  return `<!DOCTYPE html>
<html lang="${locale}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title></head>
<body style="margin:0;padding:0;background:#ececec;font-family:Arial,Helvetica,sans-serif;color:#1a1a1a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ececec;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 18px rgba(15,23,42,0.08);">
      <tr><td style="background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#b91c1c 100%);padding:24px 32px;text-align:center;">
        <div style="color:white;font-weight:800;font-size:20px;letter-spacing:-0.4px;">Fresh Market <span style="color:rgba(255,255,255,0.6);font-weight:600;font-size:12px;">PreConnect</span></div>
      </td></tr>
      ${body}
      <tr><td style="background:#0f172a;padding:18px 28px;text-align:center;">
        <div style="color:rgba(255,255,255,0.92);font-weight:700;font-size:13px;margin-bottom:4px;">Fresh Market PreConnect</div>
        <div style="color:rgba(255,255,255,0.45);font-size:11px;line-height:1.7;">
          ${footerAddr}<br>
          <a href="${esc(appUrl)}" style="color:rgba(255,255,255,0.7);text-decoration:none;">freshmarket.eu</a>
        </div>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;
}
function pBlock(text) {
  return `<p style="margin:0 0 10px;color:#334155;line-height:1.65;font-size:14px;">${text}</p>`;
}
function ctaButton(label, url) {
  return `<div style="margin:18px 0 8px;text-align:center;">
    <a href="${esc(url)}" style="display:inline-block;background:#0d9488;color:white;padding:11px 24px;border-radius:7px;font-weight:700;font-size:13px;text-decoration:none;">${esc(label)}</a>
  </div>`;
}
function tplInactivityWarning({ name, stage, deleteAfter, appUrl, locale }) {
  const lng = pickLocale(locale);
  const days = stage === "7d" ? 7 : 30;
  const date = fmtDMY(deleteAfter);
  const url = `${appUrl || "https://b2b.freshmarket.eu"}/login`;
  if (lng === "en") {
    const subject2 = `Fresh Market \u2013 your account will be removed in ${days} days due to inactivity`;
    const greet2 = name ? `Hello ${esc(name)},` : "Hello,";
    const body2 = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet2)}
  ${pBlock(`your Fresh Market account has been inactive for nearly 24 months. In <strong>${days} days</strong> it may be removed or anonymised in line with our data-retention rules (GDPR).`)}
  <div style="margin:6px 0 4px;padding:12px 16px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;color:#991b1b;font-size:14px;">
    <strong>Account may be removed after: ${esc(date)}</strong>
  </div>
  ${pBlock("To keep your account, simply <strong>sign in</strong> \u2014 that resets the inactivity timer. No other action is required.")}
  ${ctaButton("Sign in to keep my account", url)}
</td></tr>`;
    return { subject: subject2, html: shell({ title: subject2, body: body2, appUrl, locale: "en" }) };
  }
  const subject = `Fresh Market \u2013 konto zostanie usuni\u0119te za ${days} dni z powodu nieaktywno\u015Bci`;
  const greet = name ? `Dzie\u0144 dobry ${esc(name)},` : "Dzie\u0144 dobry,";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`Twoje konto Fresh Market jest nieaktywne od blisko 24 miesi\u0119cy. Za <strong>${days} dni</strong> mo\u017Ce zosta\u0107 usuni\u0119te lub zanonimizowane zgodnie z zasadami retencji danych (RODO).`)}
  <div style="margin:6px 0 4px;padding:12px 16px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;color:#991b1b;font-size:14px;">
    <strong>Konto mo\u017Ce zosta\u0107 usuni\u0119te po: ${esc(date)}</strong>
  </div>
  ${pBlock("Aby zachowa\u0107 konto, wystarczy si\u0119 <strong>zalogowa\u0107</strong> \u2014 to zeruje licznik nieaktywno\u015Bci. Nie trzeba robi\u0107 nic wi\u0119cej.")}
  ${ctaButton("Zaloguj si\u0119, aby zachowa\u0107 konto", url)}
</td></tr>`;
  return { subject, html: shell({ title: subject, body, appUrl, locale: "pl" }) };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  tplInactivityWarning
});
