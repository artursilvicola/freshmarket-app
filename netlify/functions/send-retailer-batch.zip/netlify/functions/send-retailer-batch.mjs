
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/send-retailer-batch.js
import { createClient } from "@supabase/supabase-js";

// netlify/functions/_shared/function-env.js
function getFirstEnv(...keys) {
  for (const key of keys) {
    const value = process.env[key];
    if (value) return value;
  }
  return null;
}
function resolveEnvConfig() {
  const supabaseUrl = getFirstEnv("SUPABASE_URL", "VITE_SUPABASE_URL");
  const supabaseAnonKey = getFirstEnv("SUPABASE_ANON_KEY", "VITE_SUPABASE_ANON_KEY");
  const supabaseServiceRoleKey = getFirstEnv("SUPABASE_SERVICE_ROLE_KEY");
  const resendApiKey = getFirstEnv("RESEND_API_KEY");
  const resendWebhookSecret = getFirstEnv("RESEND_WEBHOOK_SECRET");
  const openAiApiKey = getFirstEnv("OPENAI_API_KEY");
  const openAiModel = getFirstEnv("OPENAI_MODEL") || "gpt-4.1-mini";
  const b2bAppUrl = getFirstEnv("B2B_APP_URL") || "https://b2b.freshmarket.eu";
  const payuEnv = getFirstEnv("PAYU_ENV") || "sandbox";
  const payuPosId = getFirstEnv("PAYU_POS_ID");
  const payuSecondKey = getFirstEnv("PAYU_SECOND_KEY");
  const payuClientId = getFirstEnv("PAYU_OAUTH_CLIENT_ID");
  const payuClientSecret = getFirstEnv("PAYU_OAUTH_CLIENT_SECRET");
  const payuCurrencyCode = (getFirstEnv("PAYU_CURRENCY_CODE") || "EUR").trim().toUpperCase();
  const payuEurToPayuRate = getFirstEnv("PAYU_EUR_TO_PAYU_RATE");
  const payuVatRate = getFirstEnv("PAYU_VAT_RATE") || "23";
  return {
    supabaseUrl,
    supabaseAnonKey,
    supabaseServiceRoleKey,
    resendApiKey,
    resendWebhookSecret,
    openAiApiKey,
    openAiModel,
    b2bAppUrl,
    payuEnv,
    payuPosId,
    payuSecondKey,
    payuClientId,
    payuClientSecret,
    payuCurrencyCode,
    payuEurToPayuRate,
    payuVatRate
  };
}
function missingEnvNames(config, requiredKeys = []) {
  const mapping = {
    supabaseUrl: "SUPABASE_URL (lub VITE_SUPABASE_URL)",
    supabaseAnonKey: "SUPABASE_ANON_KEY (lub VITE_SUPABASE_ANON_KEY)",
    supabaseServiceRoleKey: "SUPABASE_SERVICE_ROLE_KEY",
    resendApiKey: "RESEND_API_KEY",
    resendWebhookSecret: "RESEND_WEBHOOK_SECRET",
    openAiApiKey: "OPENAI_API_KEY",
    openAiModel: "OPENAI_MODEL",
    b2bAppUrl: "B2B_APP_URL",
    payuEnv: "PAYU_ENV",
    payuPosId: "PAYU_POS_ID",
    payuSecondKey: "PAYU_SECOND_KEY",
    payuClientId: "PAYU_OAUTH_CLIENT_ID",
    payuClientSecret: "PAYU_OAUTH_CLIENT_SECRET",
    payuCurrencyCode: "PAYU_CURRENCY_CODE",
    payuEurToPayuRate: "PAYU_EUR_TO_PAYU_RATE",
    payuVatRate: "PAYU_VAT_RATE"
  };
  return requiredKeys.filter((key) => !config[key]).map((key) => mapping[key] || key);
}
function envErrorPayload(scope, missing) {
  return {
    error: `${scope}: brak konfiguracji \u015Brodowiska`,
    missing,
    hint: "Ustaw brakuj\u0105ce zmienne w Netlify -> Site configuration -> Environment variables i zr\xF3b nowy deploy."
  };
}

// src/lib/offer-enums.js
var OFFER_ENUM_KEYS = {
  "offerType": {
    "Program sta\u0142y": "supplier.offer_form.step1.identification.offer_type_options.program",
    "Propozycja sezonowa": "supplier.offer_form.step1.identification.offer_type_options.seasonal",
    "Propozycja pod promocj\u0119": "supplier.offer_form.step1.identification.offer_type_options.promo",
    "Testowy listing": "supplier.offer_form.step1.identification.offer_type_options.test",
    "Dostawa spot / uzupe\u0142nienie brak\xF3w": "supplier.offer_form.step1.identification.offer_type_options.spot"
  },
  "positioning": {
    "Codzienna p\xF3\u0142ka": "supplier.offer_form.step1.identification.positioning_options.daily",
    "Premium": "supplier.offer_form.step1.identification.positioning_options.premium",
    "Promocja": "supplier.offer_form.step1.identification.positioning_options.promo",
    "Bio / ekologiczne": "supplier.offer_form.step1.identification.positioning_options.bio",
    "Lokalne / regionalne": "supplier.offer_form.step1.identification.positioning_options.local",
    "Sezonowe": "supplier.offer_form.step1.identification.positioning_options.seasonal",
    "Wygodne opakowanie / gotowe na p\xF3\u0142k\u0119": "supplier.offer_form.step1.identification.positioning_options.shelf_ready"
  },
  "qualityClass": {
    "Klasa I": "supplier.offer_form.step1.quality_spec.quality_class_options.class1",
    "Klasa Extra": "supplier.offer_form.step1.quality_spec.quality_class_options.extra",
    "Premium": "supplier.offer_form.step1.quality_spec.quality_class_options.premium",
    "A": "supplier.offer_form.step1.quality_spec.quality_class_options.a",
    "Inna": "supplier.offer_form.step1.quality_spec.quality_class_options.other"
  },
  "saleMode": {
    "Bez marki": "supplier.offer_form.step1.quality_spec.sale_mode_options.no_brand",
    "Marka producenta": "supplier.offer_form.step1.quality_spec.sale_mode_options.producer",
    "Marka w\u0142asna sieci (Private label)": "supplier.offer_form.step1.quality_spec.sale_mode_options.private_label",
    "Marka regionalna": "supplier.offer_form.step1.quality_spec.sale_mode_options.regional"
  },
  "availabilityModel": {
    "Ca\u0142orocznie": "supplier.offer_form.step2.availability.model_options.yearly",
    "Sezonowo": "supplier.offer_form.step2.availability.model_options.seasonal",
    "Kr\xF3tkie okno": "supplier.offer_form.step2.availability.model_options.short_window",
    "Tylko promo / spot": "supplier.offer_form.step2.availability.model_options.spot"
  },
  "volumeUnit": {
    "kg": "supplier.offer_form.step2.availability.unit_options.kg",
    "t": "supplier.offer_form.step2.availability.unit_options.t",
    "kartony": "supplier.offer_form.step2.availability.unit_options.cartons",
    "palety": "supplier.offer_form.step2.availability.unit_options.pallets",
    "sztuki": "supplier.offer_form.step2.availability.unit_options.pieces",
    "p\u0119czki": "supplier.offer_form.step2.availability.unit_options.bunches",
    "bukiety": "supplier.offer_form.step2.availability.unit_options.bouquets",
    "wiadra": "supplier.offer_form.step2.availability.unit_options.buckets"
  },
  "deliveryDays": {
    "Pon": "supplier.offer_form.step2.availability.days.mon",
    "Wt": "supplier.offer_form.step2.availability.days.tue",
    "\u015Ar": "supplier.offer_form.step2.availability.days.wed",
    "Czw": "supplier.offer_form.step2.availability.days.thu",
    "Pt": "supplier.offer_form.step2.availability.days.fri",
    "Sob": "supplier.offer_form.step2.availability.days.sat",
    "Nd": "supplier.offer_form.step2.availability.days.sun"
  },
  "packaging": {
    "Luz": "supplier.offer_form.step2.packaging.format_items.luz",
    "Flowpack": "supplier.offer_form.step2.packaging.format_items.flowpack",
    "Punnet": "supplier.offer_form.step2.packaging.format_items.punnet",
    "Clamshell": "supplier.offer_form.step2.packaging.format_items.clamshell",
    "Siatka": "supplier.offer_form.step2.packaging.format_items.siatka",
    "Worek": "supplier.offer_form.step2.packaging.format_items.worek",
    "Karton": "supplier.offer_form.step2.packaging.format_items.karton",
    "IFCO": "supplier.offer_form.step2.packaging.format_items.ifco",
    "SRP": "supplier.offer_form.step2.packaging.format_items.srp",
    "P\u0119czek": "supplier.offer_form.step2.packaging.format_items.peczek",
    "Bukiet": "supplier.offer_form.step2.packaging.format_items.bukiet",
    "Display": "supplier.offer_form.step2.packaging.format_items.display"
  },
  "palletType": {
    "EUR": "supplier.offer_form.step2.packaging.pallet_type_options.eur",
    "CHEP": "supplier.offer_form.step2.packaging.pallet_type_options.chep",
    "IFCO": "supplier.offer_form.step2.packaging.pallet_type_options.ifco",
    "Inna": "supplier.offer_form.step2.packaging.pallet_type_options.other"
  },
  "srp": {
    "Tak": "supplier.offer_form.step2.packaging.srp_options.yes",
    "Nie": "supplier.offer_form.step2.packaging.srp_options.no",
    "Do uzgodnienia": "supplier.offer_form.step2.packaging.srp_options.tbd"
  },
  "deliveryModel": {
    "Centrum dystrybucyjne (CD)": "supplier.offer_form.step2.logistics.delivery_model_options.cd",
    "Cross-dock": "supplier.offer_form.step2.logistics.delivery_model_options.cross_dock",
    "Bezpo\u015Brednio do sklep\xF3w": "supplier.offer_form.step2.logistics.delivery_model_options.direct",
    "EXW": "supplier.offer_form.step2.logistics.delivery_model_options.exw",
    "FCA": "supplier.offer_form.step2.logistics.delivery_model_options.fca",
    "DDP": "supplier.offer_form.step2.logistics.delivery_model_options.ddp"
  },
  "coldChain": {
    "Po stronie dostawcy": "supplier.offer_form.step2.logistics.transport_options.supplier",
    "Po stronie kupca": "supplier.offer_form.step2.logistics.transport_options.buyer",
    "Mo\u017Cliwe oba warianty": "supplier.offer_form.step2.logistics.transport_options.both",
    "Do ustalenia": "supplier.offer_form.step2.logistics.transport_options.tbd",
    "Nie dotyczy": "supplier.offer_form.step2.logistics.transport_options.n_a"
  },
  "priceUnit": {
    "kg": "supplier.offer_form.step2.commercial.price_unit_options.kg",
    "szt.": "supplier.offer_form.step2.commercial.price_unit_options.pcs",
    "karton": "supplier.offer_form.step2.commercial.price_unit_options.carton",
    "paleta": "supplier.offer_form.step2.commercial.price_unit_options.pallet",
    "p\u0119czek": "supplier.offer_form.step2.commercial.price_unit_options.peczek",
    "bukiet": "supplier.offer_form.step2.commercial.price_unit_options.bukiet"
  },
  "incoterm": {
    "EXW": "supplier.offer_form.step2.commercial.incoterm_options.exw",
    "FCA": "supplier.offer_form.step2.commercial.incoterm_options.fca",
    "DDP": "supplier.offer_form.step2.commercial.incoterm_options.ddp",
    "CPT": "supplier.offer_form.step2.commercial.incoterm_options.cpt",
    "Inne": "supplier.offer_form.step2.commercial.incoterm_options.other"
  },
  "samplesAvail": {
    "Tak \u2014 wy\u015Blemy": "supplier.offer_form.step2.commercial.samples_options.yes",
    "Po uzgodnieniu": "supplier.offer_form.step2.commercial.samples_options.tbd",
    "Nie": "supplier.offer_form.step2.commercial.samples_options.no"
  },
  "promoVolume": {
    "Tak": "supplier.offer_form.yes",
    "Nie": "supplier.offer_form.no"
  },
  "traceability": {
    "Tak": "supplier.offer_form.yes",
    "Nie": "supplier.offer_form.no"
  },
  "currentTests": {
    "Tak": "supplier.offer_form.yes",
    "Nie": "supplier.offer_form.no"
  },
  "promoPrice": {
    "Tak": "supplier.offer_form.yes",
    "Nie": "supplier.offer_form.no"
  },
  "contractProgram": {
    "Tak": "supplier.offer_form.yes",
    "Nie": "supplier.offer_form.no"
  },
  "category": {
    "owoce": "common.offer_filters.category_options.owoce",
    "warzywa": "common.offer_filters.category_options.warzywa",
    "kwiaty": "common.offer_filters.category_options.kwiaty",
    "zio\u0142a": "common.offer_filters.category_options.ziola",
    "inne": "common.offer_filters.category_options.inne"
  }
};
function offerEnumLabel(field, value, t) {
  if (value == null || value === "") return value;
  const stored = typeof value === "boolean" ? value ? "Tak" : "Nie" : value;
  const lookup = field === "deliveryDays" && stored === "Pn" ? "Pon" : field === "category" && stored === "ziola" ? "zio\u0142a" : stored;
  const key = Object.hasOwn(OFFER_ENUM_KEYS[field] || {}, lookup) ? OFFER_ENUM_KEYS[field][lookup] : null;
  return key ? t(key, { defaultValue: String(stored) }) : value;
}

// src/i18n/en/legacy.json
var legacy_default = {
  _meta: {
    language: "English",
    namespace: "legacy",
    _note: "Klucze symetryczne z pl/legacy.json. Terminologia v1.1: Submission/Retailer/Admin, sentence case. P2-1 dodaje TYLKO display labels."
  },
  common: {
    status_tips: {
      pending_moderation: "The submission is awaiting admin review before delivery to the buyer.",
      queued: "Submission queued for delivery in the next mailing window.",
      approved: "Submission approved \u2014 it will be delivered on the scheduled date.",
      sent: "Submission delivered to the buyer. Awaiting read confirmation (14 days).",
      read: "The buyer has reviewed the submission.",
      read_manual: "The buyer confirmed reviewing the submission.",
      unread_expired: "The submission was not read within 14 days. The credit was refunded to your wallet.",
      rejected: "The submission was rejected by the admin."
    },
    status_map: {
      queued: "Queued",
      pending_moderation: "Pending moderation",
      approved: "Approved",
      rejected: "Rejected",
      sent: "Delivered, unread",
      opened: "Opened",
      read: "Read",
      read_manual: "Read \u2713",
      unread_expired: "Expired, credit refunded",
      refunded: "Credit refunded"
    },
    cta_map: {
      samples: "Request samples",
      spec: "Request specification",
      rfq: "Ask for price and volume",
      call: "Schedule a call",
      long_term: "Ask about seasonal program",
      meet_fm: "Schedule a Fresh Market meeting"
    },
    type_labels: {
      producent: "\u{1F331} Producer",
      eksporter: "\u2708 Exporter",
      importer: "\u{1F4E5} Importer",
      firma_handlowa: "\u{1F91D} Trading company",
      pakowalnia: "\u{1F4E6} Packing house",
      firma_logistyczna: "\u{1F69B} Logistics company",
      kooperatywa: "\u{1F932} Cooperative",
      agent: "\u{1F50E} Agent / Broker"
    },
    offer_filters: {
      filter_btn: "Filters",
      active_badge: "Active",
      clear_btn: "Clear",
      all_option: "All",
      category_label: "Category",
      category_options: {
        owoce: "Fruits",
        warzywa: "Vegetables",
        kwiaty: "Flowers",
        ziola: "Herbs",
        inne: "Other"
      },
      country_label: "Country",
      cert_label: "Certificate",
      packaging_label: "Packaging",
      volume_min_label: "Min. volume (T)",
      volume_min_placeholder: "e.g. 50",
      starred_label: "Saved"
    },
    company_preview: {
      modal_title: "Company profile preview \u2013 buyer view",
      founded_format: "since {{year}}",
      employees_format: "{{count}} employees",
      no_description: "The company hasn't added a description yet.",
      description_language: "Description language:",
      description_language_pl: "Polish description",
      description_language_en: "English description",
      description_unavailable_pl: "Polish version unavailable",
      description_unavailable_en: "English version unavailable",
      section_offer: "Offer",
      section_markets: "Markets and trade",
      section_ops: "Operational backbone",
      section_certs: "Certifications",
      section_materials: "Materials",
      section_long_desc: "Full description",
      section_pitch: "What the company highlights",
      offer_products_label: "Assortment:",
      offer_year_round_label: "Year-round:",
      offer_seasonal_label: "Seasonal:",
      offer_private_label: "\u2713 Private label",
      markets_export_label: "Export:",
      markets_main_label: "Main markets:",
      markets_markets_label: "Markets:",
      markets_volumes_label: "Volumes:",
      cert_number_prefix_format: "No.: {{number}}",
      cert_valid_prefix_format: "until {{date}}",
      material_pdf_label: "PDF",
      account_operator_title: "Account operator",
      account_operator_missing: "No account operator assigned.",
      account_operator_chat: "Messages",
      contacts_section_title: "Contacts",
      active_offers_section_title: "Active proposals",
      no_retailer_assigned: "No retailer assigned \u2014 proposal preview unavailable.",
      no_active_offers: "No active proposals at the moment.",
      premium_badge: "Premium"
    },
    offer_preview: {
      modal_title: "Proposal preview \u2013 buyer view",
      full_modal_title: "Full proposal preview",
      full_notice: "These are the full saved proposal details. The buyer sees a shorter, organized view.",
      premium_badge: "Premium",
      kv_volume: "Volume",
      kv_min: "Min.",
      kv_season: "Season",
      packaging_label: "PACKAGING:"
    }
  },
  supplier: {
    dashboard: {
      next_step: {
        label: "Your next step"
      },
      pkg_card: {
        header: "PreConnect credits",
        active_package_format: "active package: Standard {{max}}",
        no_active_package: "no active package",
        credits_total_suffix: "/ {{max}} credits",
        placeholder_hint: "Choose a package to start submissions",
        usage_format: "{{used}} used \xB7 {{remaining}} available",
        see_pricing: "See pricing",
        buy_package: "Buy package"
      },
      next_window: {
        header: "Next submission window",
        see_schedule: "See schedule"
      },
      kpi_row: {
        waiting_label: "Waiting",
        waiting_meta: "waiting to be opened or auto-refunded",
        seen_label: "Seen / settled",
        seen_meta: "buyer opened, credit charged",
        expired_label: "Expired",
        expired_meta: "unopened in 14 days \xB7 credit refunded",
        rate_label: "Seen rate",
        rate_meta: "seen out of completed submissions",
        placeholder_dash: "\u2014",
        placeholder_hint: "no submissions"
      },
      help_strip: {
        toggle_label: "How does it work? \u2014 PreConnect and FM 2026 Meetings flow",
        preconnect_section_title: "PreConnect module (year-round)",
        preconnect_li_1_strong: "Product submissions",
        preconnect_li_1_rest: " are created in the ",
        preconnect_li_1_em: "My submissions",
        preconnect_li_1_end: " tab. After moderation approval they are ready for submission.",
        preconnect_li_2_strong: "Submissions",
        preconnect_li_2_rest: " go out on the first Tuesday of each month. Each submission to a retailer = 1 credit from the package.",
        preconnect_li_3_strong: "The 14-day rule:",
        preconnect_li_3_rest: " if the buyer doesn't open the submission within 14 days, the credit returns to your package automatically.",
        fm_section_title: "FM 2026 Meetings module (trade show)",
        fm_li_1_strong: "Preferences",
        fm_li_1_rest: " (1\u201316 September): you choose 5 priority retailers per Business package (min. 5) + any number of backup ones.",
        fm_li_2_strong: "Algorithm + corrections",
        fm_li_2_rest: " (17\u201322 September): matching retailer \u2194 supplier pairs.",
        fm_li_3_strong: "Plan",
        fm_li_3_rest: " (from 22 September): you receive a list with meeting numbers. Details (times, locations) at event-day registration.",
        fm_li_4: "Have a question? Message the admin via the chat in the bottom-right corner."
      },
      time: {
        in_days_one: "in {{count}} day",
        in_days_few: "in {{count}} days",
        in_days_many: "in {{count}} days",
        in_days_other: "in {{count}} days"
      },
      next_step_variants: {
        pending_review: {
          title: "Complete your company profile to speed up approval",
          desc: "Admins approve accounts faster when they have complete data: company description, logo, certificates, and at least 1 submission in the catalog.",
          cta: "Open company profile"
        },
        no_package: {
          title: "Choose a submission package to start",
          desc: "Without credits you can't submit proposals to retailers. Packages start from 1 submission upwards.",
          cta: "Choose package"
        },
        no_offers: {
          title: "Add your first product submission",
          desc: "Product + brief specification + photos. After moderation approval you can submit to retailers.",
          cta: "Add submission"
        },
        refunds: {
          title_one: "You have 1 credit refund to review{{totalSuffix}}",
          title_few: "You have {{count}} credit refunds to review{{totalSuffix}}",
          title_many: "You have {{count}} credit refunds to review{{totalSuffix}}",
          title_other: "You have {{count}} credit refunds to review{{totalSuffix}}",
          total_suffix_format: " \u2014 {{total}} \u20AC",
          desc: "Buyers didn't open your submissions within the 14-day window. Credits returned to your package automatically.",
          cta: "See refunds"
        },
        no_recent_sends: {
          title_one: "You have {{count}} active product proposal ready for submission",
          title_few: "You have {{count}} active product proposals ready for submission",
          title_many: "You have {{count}} active product proposals ready for submission",
          title_other: "You have {{count}} active product proposals ready for submission",
          desc: "Use the credits from your package. Choose retailers and prepare a submission for the next window.",
          cta: "Prepare submission"
        },
        package_low: {
          title: "Package running low \u2014 buy a top-up",
          desc: "Used: {{used}}, reserved: {{reserved}}. {{remaining}} credits remain available for new submissions.",
          cta: "Buy package"
        },
        default: {
          title: "All set \u2014 keep submitting",
          desc: "You have {{credits}} credits available. Next window: {{date}}.",
          cta: "Prepare submission"
        }
      },
      activity: {
        buyer_viewed: {
          body_with_title: "<strong>The buyer viewed</strong> <em>\u201C{{title}}\u201D</em>",
          body_no_title: "<strong>The buyer viewed</strong> a product proposal",
          sub: "credit charged from the package"
        },
        sent: {
          body_with_title: "<strong>Submitted</strong> <em>\u201C{{title}}\u201D</em>",
          body_no_title: "<strong>Submitted</strong> a product proposal",
          sub: "awaiting open (max 14 days)"
        },
        expired: {
          body_with_title: "<strong>Product proposal expired</strong> <em>\u201C{{title}}\u201D</em>",
          body_no_title: "<strong>Product proposal expired</strong>",
          sub: "credit refunded to the package"
        },
        approved: {
          body_with_title: "<strong>Product proposal approved</strong> <em>\u201C{{title}}\u201D</em>",
          body_no_title: "<strong>Product proposal approved</strong>",
          sub: "ready for submission"
        },
        added: {
          body_with_title: "<strong>Product proposal added</strong> <em>\u201C{{title}}\u201D</em>",
          body_no_title: "<strong>Product proposal added</strong>",
          sub: "status: draft"
        },
        refund: {
          body_with_amount: "<strong>Credit refund</strong> (+{{amount}} \u20AC)",
          body_no_amount: "<strong>Credit refund</strong>",
          sub_default: "submission expired unopened"
        }
      },
      refunds_strip: {
        label_one: "1 credit refund{{totalSuffix}} this month \u2014 buyers didn't open in time. Credits returned to your package automatically.",
        label_few: "{{count}} credit refunds{{totalSuffix}} this month \u2014 buyers didn't open in time. Credits returned to your package automatically.",
        label_many: "{{count}} credit refunds{{totalSuffix}} this month \u2014 buyers didn't open in time. Credits returned to your package automatically.",
        label_other: "{{count}} credit refunds{{totalSuffix}} this month \u2014 buyers didn't open in time. Credits returned to your package automatically.",
        total_suffix_format: " ({{total}} \u20AC)",
        see_button: "See"
      },
      kpi_section: {
        header: "PreConnect submissions \u2014 last 30 days",
        no_data: "no data",
        total_one: "1 submission total",
        total_few: "{{count}} submissions total",
        total_many: "{{count}} submissions total",
        total_other: "{{count}} submissions total"
      },
      activity_card: {
        header: "Last activity",
        empty_meta: "no events",
        total_one: "{{count}} event",
        total_few: "{{count}} events",
        total_many: "{{count}} events",
        total_other: "{{count}} events",
        empty_body: "Prepare your first submission to see history here."
      },
      time_rel: {
        just_now: "just now",
        hours_ago_one: "{{count}} hour ago",
        hours_ago_few: "{{count}} hours ago",
        hours_ago_many: "{{count}} hours ago",
        hours_ago_other: "{{count}} hours ago",
        days_ago_one: "{{count}} day ago",
        days_ago_few: "{{count}} days ago",
        days_ago_many: "{{count}} days ago",
        days_ago_other: "{{count}} days ago"
      },
      fm_compact: {
        header: "FM 2026 Meetings",
        phase_published: "Plan published",
        phase_open: "Selection active",
        phase_soon: "Coming soon",
        main_published: "Schedule ready \u2014 see your meeting numbers.",
        main_open: "Selection open \u2014 go to FM 2026.",
        main_soon_pre: "Selection opens \xB7 ",
        main_soon_date: "1 September",
        step_soon: "Soon",
        step_choice: "Selection",
        step_algo: "Algorithm",
        step_plan: "Plan",
        btn_published: "See meetings \u2192",
        btn_open: "Open selection \u2192",
        btn_soon: "See FM schedule \u2192"
      },
      onboarding: {
        header_label: "Start here",
        header_progress: "({{done}}/{{total}})",
        step_profile_label: "Complete company details",
        step_profile_hint: "Name, Tax ID, country, short description \u2014 minimum so the buyer knows who the submission is from.",
        step_profile_cta: "Open profile",
        step_logo_label: "Upload company logo",
        step_logo_hint: "Shown in the email to the buyer and next to submissions. PNG/JPG, ~400\xD7400 px.",
        step_logo_cta: "Upload logo",
        step_offer_label: "Add your first product submission",
        step_offer_hint: "Product + brief specification + 1\u20133 photos.",
        step_offer_cta: "Add submission",
        step_package_label: "Package unlocks after account approval",
        step_package_hint: "Pricing visible for preview. Purchase will be available right after admin approval.",
        step_package_cta: "See pricing",
        step_send_label: "Submit to retailers",
        step_send_hint: "First submission after account activation."
      }
    },
    offers: {
      header_label: "PreConnect",
      title: "My product proposals",
      desc_pre: "List of your product proposals. Each one shows specific products to buyers \u2014 this is not classic price quoting, so ",
      desc_strong: "price is optional",
      desc_post: ".",
      add_button: "Add product proposal",
      empty: "No proposals. Click \u201CAdd product proposal\u201D to add the first one.",
      filters: {
        summary_all: "All",
        summary_ready: "Ready",
        summary_draft: "Drafts",
        summary_sent: "Submitted",
        summary_unsent: "Not submitted",
        summary_read: "Read",
        search_placeholder: "Search: product, variety, country...",
        category_all: "Categories: all",
        country_all: "Countries: all",
        sort_newest: "Sort: newest",
        sort_name: "Sort: name A-Z",
        sort_sent: "Sort: most retailers",
        sort_read: "Sort: most reads",
        sort_status: "Sort: ready first",
        results_format: "Results: {{count}} of {{total}} proposals",
        clear: "Clear filters",
        empty_filtered: "No proposals match these filters. Clear filters or change the search phrase.",
        per_page: "Per page:",
        page_status_format: "{{from}}-{{to}} of {{total}}",
        page_prev: "Previous",
        page_next: "Next"
      },
      card: {
        only_you_badge: "Only you",
        for_buyer_badge: "For the buyer",
        status_published: "Ready to submit",
        status_draft: "Draft",
        premium_badge: "Premium",
        kpi_retailers: "Retailers",
        kpi_read: "Read",
        btn_edit: "Edit",
        btn_edit_locked: "Editing locked",
        btn_edit_locked_tooltip: "A ready proposal cannot be edited. Duplicate it and create a new version.",
        btn_preview: "Preview",
        btn_duplicate: "Duplicate",
        btn_duplicate_tooltip: "Duplicate proposal \u2014 speeds up adding similar products",
        btn_send: "Submit",
        btn_delete: "Delete",
        btn_delete_tooltip_can: "Delete proposal (irreversible)",
        btn_delete_tooltip_locked_one: "Cannot delete \u2014 proposal submitted to {{count}} retailer. After submission it lives in the admin pipeline.",
        btn_delete_tooltip_locked_few: "Cannot delete \u2014 proposal submitted to {{count}} retailers. After submission it lives in the admin pipeline.",
        btn_delete_tooltip_locked_many: "Cannot delete \u2014 proposal submitted to {{count}} retailers. After submission it lives in the admin pipeline.",
        btn_delete_tooltip_locked_other: "Cannot delete \u2014 proposal submitted to {{count}} retailers. After submission it lives in the admin pipeline."
      },
      delete_modal: {
        title: "Delete proposal?",
        body_html: "Are you sure you want to delete proposal <strong>\u201C{{title}}\u201D</strong>?",
        warn_html: "This operation is <strong>irreversible</strong>. The proposal will be removed from the database. If you just want to hide it from buyers, you can change its status to \u201CDraft\u201D in edit mode instead.",
        cancel: "Cancel",
        confirm: "Yes, delete"
      },
      deleted_flash: "Proposal \u201C{{title}}\u201D deleted.",
      deleted_fallback_title: "(no title)"
    },
    offer_form: {
      copy_suffix: " (Copy)",
      select_empty: "\u2014 select \u2014",
      select_dash: "\u2014",
      yes: "Yes",
      no: "No",
      nav: {
        back: "Back",
        cancel: "Cancel",
        preview_buyer: "Buyer preview",
        next: "Next",
        preview: "Preview",
        save_draft: "Save draft",
        publish: "Save as ready"
      },
      steps: {
        "1": {
          title: "Product",
          sub: "Identification and specification",
          items: {
            a: "A. Product identification",
            b: "B. Quality specification (optional)",
            c: "C. Flower fields",
            d: "D. Photos"
          }
        },
        "2": {
          title: "Details",
          sub: "Volume, packaging, logistics, indicative price",
          items: {
            a: "A. Availability and volume",
            b: "B. Packaging and palletization",
            c: "C. Logistics",
            d: "D. Certifications",
            e: "E. Indicative price (optional)"
          }
        },
        "3": {
          title: "Presentation",
          sub: "What sets you apart + proposal title",
          items: {
            a: "A. What sets you apart?",
            b: "B. Risk mitigation",
            c: "C. Possible buyer actions"
          }
        }
      },
      validation: {
        field_required_msg: "This field is required",
        error_banner_step1_prefix: "Fill in the required fields:",
        error_banner_step2_html: "<strong>Fill in the required fields</strong> \u2014 highlighted in red above."
      },
      step1: {
        identification: {
          card_title: "A. Product identification",
          product_label: "Product name",
          product_placeholder: "e.g. apples, raspberry tomato, rose",
          variety_label: "Variety",
          variety_placeholder: "e.g. Gala, Red Naomi, Malinowy",
          category_label: "Category",
          subcategory_label: "Subcategory",
          subcategory_placeholder: "e.g. apples, blueberries, lettuce, tulips...",
          origin_label: "Country of origin",
          region_label: "Region / locality",
          region_placeholder: "e.g. Mazovia, Almer\xEDa, Naivasha",
          offer_type_label: "Proposal type",
          offer_type_hint: "Year-round program = continuous availability. Seasonal = narrow window. Promo listing = one-off listing with a better price. Spot = production surplus.",
          offer_type_options: {
            program: "Year-round program",
            seasonal: "Seasonal proposal",
            promo: "Promo listing proposal",
            test: "Test listing",
            spot: "Spot delivery / stock gap fill"
          },
          positioning_label: "Role of the product on the shelf",
          positioning_hint: "Everyday = mainstream. Premium = higher price and quality. Promo = low price with label. Bio = certified. Local = from retailer's country. Shelf-ready = in RSP packaging.",
          positioning_options: {
            daily: "Everyday shelf",
            premium: "Premium",
            promo: "Promo",
            bio: "Bio / organic",
            local: "Local / regional",
            seasonal: "Seasonal",
            shelf_ready: "Convenient packaging / shelf-ready"
          }
        },
        quality_spec: {
          card_title: "B. Quality specification",
          info_alert_html: "Fields in this section are optional \u2014 fill them in only if relevant to your product and the buyer. <strong>We focus on the basic specification</strong>; commercial details will be agreed after contact.",
          size_label: "Caliber / size",
          size_placeholder: "e.g. apples 70-80 mm \xB7 blueberries 12+ mm \xB7 citrus 6 (cal.) \xB7 roses 50-60 cm",
          size_hint: "Industry standard or the measure you use to indicate product size.",
          quality_class_label: "Quality class",
          quality_class_hint: "Class I = EU standard (most of trade). Extra = top EU. Premium/A = retailer's own classes. Other = industry certifications (e.g. GlobalGAP grade).",
          quality_class_options: {
            class1: "Class I",
            extra: "Class Extra",
            premium: "Premium",
            a: "A",
            other: "Other"
          },
          quality_spec_label: "Short quality specification",
          quality_spec_placeholder: "uniform caliber, good firmness, no mechanical damage, stable batch throughout the program",
          brand_label: "Brand",
          brand_placeholder: "e.g. Granny Green, FreshPol",
          brand_hint: "optional \u2014 brand name",
          sale_mode_label: "Sale mode",
          sale_mode_options: {
            no_brand: "No brand",
            producer: "Producer's brand",
            private_label: "Retailer's private label",
            regional: "Regional brand"
          },
          bio_toggle_label: "Product has an organic / Bio certificate",
          brix_label: "Brix",
          brix_placeholder: "e.g. min. 12\xB0Bx",
          color_spec_label: "Color / coloration",
          color_spec_placeholder: "e.g. min. 75% red color"
        },
        flowers: {
          card_title: "C. Flower parameters",
          stem_length_label: "Stem length",
          stem_length_placeholder: "e.g. 50 cm, 60 cm",
          opening_phase_label: "Opening phase",
          opening_phase_placeholder: "e.g. closed bud (stage 1), half-open (stage 3), full (stage 5)",
          opening_phase_hint: "Flower development stage at harvest. You can enter the value in your own words.",
          bouquet_count_label: "Stems per bunch / bouquet",
          bouquet_count_placeholder: "e.g. 10",
          vase_life_label: "Declared vase life",
          vase_life_placeholder: "e.g. 7\u201310 days",
          flower_color_label: "Color / color mix",
          flower_color_placeholder: "e.g. red, spring mix, white and pink"
        },
        photos: {
          card_title: "D. Product photos (max 3)",
          info_alert: "The first photo (main) goes into the header of the buyer's email. A photo of the trade packaging is required \u2014 the buyer and logistics must see exactly what they get.",
          uploader_label: "Click or drag product photos here",
          hint: "The first photo will be the main one in the buyer's email. Photos are stored in the cloud and visible to all users."
        }
      },
      step2: {
        availability: {
          card_title: "A. Availability and volume",
          from_label: "Available from",
          to_label: "Available to",
          model_label: "Availability model",
          model_hint: "Year-round = stable delivery 12 months. Seasonal = product in a defined window (e.g. strawberries V-VII). Short window = a few weeks. Spot = one-off batch, no continuation.",
          model_options: {
            yearly: "Year-round",
            seasonal: "Seasonal",
            short_window: "Short window",
            spot: "Promo / spot only"
          },
          vol_min_label: "Min. volume / week",
          vol_min_placeholder: "e.g. 200",
          vol_max_label: "Max. volume / week",
          vol_max_placeholder: "e.g. 500",
          unit_label: "Unit",
          unit_options: {
            kg: "kg",
            t: "t",
            cartons: "cartons",
            pallets: "pallets",
            pieces: "pieces",
            bunches: "bunches",
            bouquets: "bouquets",
            buckets: "buckets"
          },
          moq_label: "Minimum order / MOQ",
          moq_placeholder: "e.g. 1 pallet, 200 cartons",
          lead_time_label: "Lead time",
          lead_time_placeholder: "e.g. 24 h, 48 h, 3 days",
          promo_vol_label: "Can the volume be increased for promo?",
          promo_pct_label: "By how much % (for promo)",
          promo_pct_placeholder: "e.g. 30%",
          days_label: "Delivery days",
          days_optional: "optional",
          days: {
            mon: "Mon",
            tue: "Tue",
            wed: "Wed",
            thu: "Thu",
            fri: "Fri",
            sat: "Sat",
            sun: "Sun"
          }
        },
        packaging: {
          card_title: "B. Packaging and palletization",
          success_alert: "The buyer and warehouse assess whether the product can be implemented before the conversation begins. Pallet dimensions, carton counts and SRP are often entry conditions.",
          format_label: "Trade format",
          format_items: {
            luz: "Bulk",
            flowpack: "Flowpack",
            punnet: "Punnet",
            clamshell: "Clamshell",
            siatka: "Net",
            worek: "Bag",
            karton: "Carton",
            ifco: "IFCO",
            srp: "SRP",
            peczek: "Bunch",
            bukiet: "Bouquet",
            display: "Display"
          },
          custom_packaging_label: "Other packaging",
          custom_packaging_hint: "e.g. Big Bag, Mesh Bag, Tray, Sleeve...",
          desc_label: "Trade packaging description",
          desc_placeholder: "e.g. 12 x 125 g, 10 kg bulk, 20 bunches of 10 pcs.",
          palletizing_label: "Palletization",
          palletizing_optional: "(optional)",
          pallet_type_label: "Pallet type",
          pallet_type_options: {
            eur: "EUR",
            chep: "CHEP",
            ifco: "IFCO",
            other: "Other"
          },
          pallet_height_label: "Pallet height",
          pallet_height_placeholder: "e.g. 180 cm",
          cartons_per_layer_label: "Cartons per layer",
          cartons_per_layer_placeholder: "e.g. 6",
          layers_per_pallet_label: "Layers per pallet",
          layers_per_pallet_placeholder: "e.g. 8",
          units_per_pallet_label: "Trade units per pallet",
          units_per_pallet_placeholder: "e.g. 576",
          srp_label: "Shelf-ready (SRP) available?",
          srp_options: {
            yes: "Yes",
            no: "No",
            tbd: "To be agreed"
          }
        },
        logistics: {
          card_title: "C. Logistics and claims",
          delivery_model_label: "Delivery model",
          delivery_model_options: {
            cd: "Distribution center (DC)",
            cross_dock: "Cross-dock",
            direct: "Direct to stores",
            exw: "EXW",
            fca: "FCA",
            ddp: "DDP"
          },
          loading_point_label: "Loading point",
          loading_point_placeholder: "e.g. Recz, Mazovia, Almer\xEDa",
          regions_label: "Serviced countries / delivery regions",
          regions_placeholder: "e.g. PL, DE, CZ, NL \u2014 all of CEE",
          transport_label: "Transport",
          transport_hint: "Indicate who organizes transport. It can be your company, a courier company or the buyer.",
          transport_options: {
            supplier: "On the supplier's side",
            buyer: "On the buyer's side",
            both: "Both options possible",
            tbd: "To be agreed",
            n_a: "Not applicable"
          },
          temp_label: "Transport temperature",
          temp_placeholder: "e.g. 2\u20136\xB0C, 8\u201310\xB0C (flowers)",
          temp_hint: "optional \u2014 often depends on the route"
        },
        certs: {
          card_title: "D. Certifications and traceability",
          traceability_label: "Full batch traceability",
          certs_label: "Certifications",
          cert_items: {
            globalgap: "GlobalG.A.P.",
            grasp: "GRASP",
            bio: "EU Organic / Bio",
            rainforest: "Rainforest Alliance",
            fairtrade: "Fairtrade",
            smeta: "SMETA",
            haccp: "HACCP",
            brc: "IFS / BRCGS",
            mps_abc: "MPS-ABC",
            mps_gap: "MPS-GAP"
          },
          custom_cert_label: "Other certificate",
          custom_cert_hint: "e.g. USDA Organic, Tesco Nurture...",
          cert_number_label: "Certificate number",
          cert_number_placeholder: "e.g. 4056186695431",
          cert_valid_label: "Valid until",
          tests_label: "Current tests?"
        },
        commercial: {
          card_title: "E. Commercial terms and indicative price",
          info_alert_html: "<strong>Price is optional and indicative.</strong> Preconnect is a system for product proposals, not classic price quoting. You can list an indicative price, a range, or leave the field empty \u2014 the buyer will ask for the price after contact. Any price shown to the buyer will include the note: <em>\u201CPrice is indicative and requires confirmation from the supplier.\u201D</em>",
          currency_label: "Currency",
          currency_options: {
            pln: "PLN",
            eur: "EUR",
            usd: "USD"
          },
          price_label: "Indicative price",
          price_placeholder: "e.g. 2.40 \u2014 min. price from the previous week",
          price_hint: "Optional. Shows the buyer the order of magnitude \u2014 the final price will be agreed bilaterally. INCOTERMS impact: DAP/DDP usually higher, EXW lower.",
          price_unit_label: "Price unit",
          price_unit_options: {
            kg: "kg",
            pcs: "pcs.",
            carton: "carton",
            pallet: "pallet",
            peczek: "bunch",
            bukiet: "bouquet"
          },
          incoterm_label: "Price basis / Incoterm",
          incoterm_options: {
            exw: "EXW",
            fca: "FCA",
            ddp: "DDP",
            cpt: "CPT",
            other: "Other"
          },
          price_range_label: "Price valid from \u2014 to",
          promo_price_label: "Promo price possible?",
          contract_label: "Seasonal / contract program?",
          samples_label: "Sample availability",
          samples_options: {
            yes: "Yes \u2014 we'll send",
            tbd: "After agreement",
            no: "No"
          }
        }
      },
      step3: {
        warning_alert_html: "<strong>Don't write:</strong> high quality \xB7 competitive price \xB7 individual approach \xB7 many years of experience.<br/><strong>Be specific:</strong> batch standard, volume, logistics, price, response time, benefit for the buyer.",
        example: {
          summary: "\u{1F4CB} Show an example of a good proposal (1 sentence)",
          quote: "\u201CGala apples 70-80 mm, class I, 100 t/month, DAP delivery to distribution center\u201D",
          explanation_html: "Every field is specific and measurable: <strong>product + variety + caliber + class + volume + logistics</strong>. The buyer immediately knows what to expect. Keep the same spirit in the 3 questions below \u2014 operational, in numbers."
        },
        benefits: {
          card_title: "A. What sets you apart?",
          success_alert_html: "<strong>This is the most important section \u2014 more important than price.</strong> Answer the 3 questions specifically: why should the buyer choose your proposal? Don't write clich\xE9s \u2014 write operational, measurable facts.",
          inspirations_label: "Inspiration \u2014 click to add",
          chips: {
            repeatable_quality: "repeatable quality",
            stable_supply: "stable supply",
            low_shrink: "low shrink",
            fast_claim: "fast claim handling",
            promo_ready: "promo-ready",
            shelf_ready_pkg: "shelf-ready packaging",
            private_label: "private label",
            marketing_support: "marketing support",
            sales_support: "sales support",
            batch_traceability: "batch traceability",
            tests_docs: "tests and documentation",
            local_regional: "local / regional",
            shop_convenience: "shop convenience",
            shopper_convenience: "shopper convenience"
          },
          required_label: "required",
          optional_label: "optional",
          q1: "Why should the buyer be interested in this product?",
          q1_placeholder: "e.g. repeatable batch quality throughout the program \u2014 optical sorter, class I guaranteed",
          q2: "What do you do better or differently than other suppliers?",
          q2_placeholder: "e.g. stable supply of 200\u2013500 t/month from our own CA cold storage \u2014 independent of purchase market",
          q3: "How do you reduce risk for the buyer?",
          q3_placeholder: "e.g. claims handled the same day, plan B: 2 packhouses + 5 partner farms",
          shop_benefit_label: "How will this product help the retailer sell more or better?",
          shop_benefit_placeholder: "shelf-friendly format, low waste, room for a seasonal campaign, POS material support, ready for display"
        },
        risk: {
          card_title: "B. Cooperation safety",
          optional_label: "optional",
          mitigation_label: "How do you safeguard quality and supply continuity?",
          mitigation_placeholder: "batch quality monitoring, same-day claim response, full traceability from field to delivery, online documentation, contingency plan: 2 packhouses + 5 partner farms",
          proof_label: "What confirms your credibility?",
          proof_placeholder: "markets served: PL/DE/CZ, stable volumes since 2019, retail references (on request), process photos, current GlobalGAP tests",
          now_label: "Why is it worth talking now?",
          now_placeholder: "e.g. start of autumn season \u2014 Class Extra apples available from September, high availability from CA cold storage, window before holiday promo"
        },
        actions: {
          card_title: "C. Possible buyer actions",
          info_alert_html: "<strong>Save draft</strong> if you still want to edit the proposal. <strong>Save as ready</strong> when this is the final version. A ready proposal cannot be edited \u2014 duplicate it to prepare a new version. A ready proposal is not sent to retailers yet; you will submit it later from the Submissions tab, and the administrator will review it before forwarding it to the buyer."
        },
        title_card: {
          card_title: "Proposal title for the buyer",
          info_alert_html: "<strong>This is your proposal title visible to the buyer on the proposal list.</strong> It should immediately tell what you offer and why it's worth clicking for details. Enter the product, country or region of origin, and one strongest differentiator \u2014 e.g. season, caliber, availability, certification, or packaging format.",
          title_label: "Proposal title for the buyer",
          title_placeholder: "e.g. Table grapes Murcia \u2014 seedless, AA caliber, season VII\u2013X",
          internal_title_label: "Your own proposal name",
          internal_title_placeholder: "e.g. Gala premium \u2014 variant for large retailers",
          internal_title_hint: "Not visible to the buyer",
          internal_title_description: "This is a working name just for you. The buyer won't see it. Use it to easily distinguish similar proposals in your panel \u2014 e.g. a variant for large retailers, a seasonal proposal, or a premium variant."
        }
      },
      save_flash: {
        published: "Proposal saved as ready to submit.",
        draft_saved: "Draft saved.",
        error_prefix: "Save error: {{message}}",
        error_fallback: "please try again"
      },
      locked: {
        title: "Ready proposal is locked",
        body: "This proposal can no longer be edited because it has been saved as ready to submit. Duplicate it and prepare a new version if you need changes.",
        back_btn: "Back to proposals",
        duplicate_btn: "Duplicate and edit new",
        saved_offer_error: "A ready proposal cannot be edited. Duplicate it and create a new version."
      }
    },
    wysylki: {
      tabs: {
        sieci: "Retailers",
        history_format: "History ({{count}})"
      },
      pkg_bar: {
        fallback_label: "Standard 10 submissions",
        usage_format: "{{used}}/{{max}} submissions",
        wallet_balance_format: "Wallet: {{balance}} EUR",
        no_credits_badge: "No submissions left \u2014 buy a package"
      },
      sieci: {
        header_format: "Retailers ({{count}})",
        stats_format: "{{sent}} submitted \xB7 {{read}} read",
        search_placeholder: "Search retailers...",
        sent_badge_format: "{{count}} submitted",
        mailing_label: "Submission window: {{date}}",
        buyer_cats_label: "Buyer categories: {{cats}}",
        read_count_format: "{{read}}/{{total}} proposals read",
        send_to_button_format: "Submit proposal to {{name}}"
      },
      new: {
        card_title: "Submit proposal to a retailer",
        cancel: "Cancel",
        guarantee_alert: "14-day guarantee \u2014 if the buyer doesn't open the proposal, the credit automatically returns to your wallet.",
        offer_label: "Proposal",
        select_empty: "\u2014 select \u2014",
        no_offers_warning_pre: "No active proposals. ",
        no_offers_warning_cta: "Add proposal \u2192",
        retailer_label: "Retailer",
        internal_title_label: "\u{1F512} Your own:",
        public_title_label: "\u{1F310} For the buyer:",
        next_send_format: "Submission window: {{date}}",
        send_button: "Submit proposal",
        cost_info_format: "Cost: {{cost}} EUR \xB7 1 submission from the package",
        req_title: "Important information about this retailer's requirements",
        req_checkbox: "I confirm that I have read this retailer's requirements before sending the offer.",
        req_error: "Before sending the offer you must confirm that you have read this retailer's requirements."
      },
      history: {
        tabs: {
          all: "All",
          sent: "Submitted",
          pending: "Queue",
          expired: "Expired"
        },
        empty_title: "No submissions in this category",
        empty_cta: "Submit your first proposal \u2192",
        days_left_format: "{{count}}d"
      },
      confirm_modal: {
        title: "Confirm submission",
        subtitle: "We're about to charge 1 submission from your package",
        row_offer: "Proposal",
        row_retailer: "Retailer",
        row_cost: "Submission cost",
        row_remaining: "Remaining after submission",
        cost_value_format: "1 submission ({{perSend}} EUR)",
        remaining_value_format: "{{remaining}}/{{max}} submissions",
        rule_html: "<strong>\u2B50 The 14-day rule:</strong> if the buyer doesn't open the proposal within 14 days, the credit automatically returns to your wallet.",
        cancel: "Cancel",
        confirm: "Submit proposal"
      },
      toasts: {
        pending_review: "Account is awaiting admin approval. Once activated, we'll unlock proposal submissions.",
        account_inactive: "The account is currently inactive. Please contact newsletter@freshmarket.eu.",
        preconnect_disabled: "PreConnect is not yet active for your company. The admin enables the module individually.",
        no_credits_format: "No credits available in the package ({{used}}/{{max}} used). Top up the package in \u201CFinance\u201D.",
        send_error_format: "Submission error: {{message}}",
        send_error_fallback: "please try again",
        queued_success: "Proposal added to the moderation queue."
      }
    },
    profile: {
      page_title: "My profile",
      card_data_title: "Account data",
      labels: {
        name: "Full name",
        position: "Position",
        company: "Company",
        email_admin_change: "Email (changed by admin)",
        phone: "Phone"
      },
      admin_notice: "Email and company data are managed by the Fresh Market admin. You can change your name, position, phone, and password yourself.",
      save_button: "Save",
      saving: "Saving...",
      toasts: {
        missing_id: "Missing user ID \u2014 please sign in again.",
        name_required: "Full name is required.",
        saved: "Profile saved.",
        save_error_format: "Save error: {{message}}",
        save_error_fallback: "unknown"
      }
    },
    finance: {
      pools: {
        card_title: "Your PreConnect credits",
        available_format: "Available for new submissions: {{count}}",
        awaiting_format: "credits reserved by proposals: {{count}}",
        nearest_expiry_one_format: "{{count}} credit expires {{date}}",
        nearest_expiry_few_format: "{{count}} credits expire {{date}}",
        nearest_expiry_many_format: "{{count}} credits expire {{date}}",
        nearest_expiry_other_format: "{{count}} credits expire {{date}}",
        no_expiry_format: "{{count}} without expiry",
        free_label: "Free from the organiser",
        paid_label: "Purchased",
        legacy_label: "Historical packages (source not determined)",
        remaining_format: "{{remaining}} of {{total}}",
        remaining_unit: "remaining",
        valid_until_format: "valid until {{date}}",
        none: "none",
        order_hint: "A credit is taken from a pool only when a retailer reads your proposal \u2014 free credits first, then purchased ones. Proposals awaiting moderation, sending or a read reserve credits. Rejection or expiry without a read releases the reservation.",
        buy_btn: "Buy more credits",
        granted_on_format: "granted {{date}}",
        reason_promotion: "promotion",
        reason_compensation: "compensation",
        reason_gift: "gift",
        reason_other: "from the organiser",
        history_grant_label: "Free credits from the organiser",
        history_purchase_label: "Purchased",
        history_legacy_label: "Historical package \u2014 source not determined",
        history_prior_registration_one_format: "Fresh Market registration gift \u2014 {{count}} credit granted previously",
        history_prior_registration_few_format: "Fresh Market registration gift \u2014 {{count}} credits granted previously",
        history_prior_registration_many_format: "Fresh Market registration gift \u2014 {{count}} credits granted previously",
        history_prior_registration_other_format: "Fresh Market registration gift \u2014 {{count}} credits granted previously",
        history_prior_other_one_format: "Free credits from the organiser ({{reason}}) \u2014 {{count}} credit granted previously",
        history_prior_other_few_format: "Free credits from the organiser ({{reason}}) \u2014 {{count}} credits granted previously",
        history_prior_other_many_format: "Free credits from the organiser ({{reason}}) \u2014 {{count}} credits granted previously",
        history_prior_other_other_format: "Free credits from the organiser ({{reason}}) \u2014 {{count}} credits granted previously",
        reason_registration: "registration gift",
        legacy_note_format: "including {{count}} from historical packages (source not determined)"
      },
      tabs: {
        saldo: "Balance and package",
        historia: "Submission history",
        pakiety: "Pricing and packages"
      },
      credits: {
        bar_free_format: "unsettled in pools: free {{free}}, purchased {{paid}} \xB7 reserved by proposals: {{awaiting}}",
        bar_legacy_format: "not determined {{legacy}}",
        balance_label: "PreConnect Credits",
        amount_one_format: "{{count}} credit",
        amount_few_format: "{{count}} credits",
        amount_many_format: "{{count}} credits",
        amount_other_format: "{{count}} credits",
        funds_info: "1 credit = 1 submission to one retailer",
        of_total_format: "{{rem}} of {{max}} credits available",
        cost_info: "Uses 1 credit",
        cost_modal: "1 submission = 1 credit",
        refund_one_format: "+{{count}} credit",
        refund_few_format: "+{{count}} credits",
        refund_many_format: "+{{count}} credits",
        refund_other_format: "+{{count}} credits",
        refund_pending: "Credit returns to your account",
        bar_format: "PreConnect Credits: {{rem}} of {{max}}",
        used_format: "Used: {{used}}/{{max}} credits",
        usage_format: "{{used}}/{{max}} credits",
        used_hint: "1 credit = 1 proposal submission to one retailer.",
        stat_used_one_format: "{{count}} used credit",
        stat_used_few_format: "{{count}} used credits",
        stat_used_many_format: "{{count}} used credits",
        stat_used_other_format: "{{count}} used credits",
        stat_used_label: "Used",
        stat_used_unit: "used credits",
        col_settlement: "Settlement",
        hist_used: "Used 1 credit",
        hist_refund_done: "Refund +1 credit",
        hist_refund_pending: "Refund pending",
        hist_awaiting: "Awaiting",
        no_credits: "No credits \u2014 buy a package",
        refund_alert_one_html: "<strong>Refund +{{count}} credit</strong> \u2014 the proposal wasn't read, the credit returned to your account. You can use it for submissions to other retailers.",
        refund_alert_few_html: "<strong>Refund +{{count}} credits</strong> \u2014 the proposals weren't read, the credits returned to your account. You can use them for submissions to other retailers.",
        refund_alert_many_html: "<strong>Refund +{{count}} credits</strong> \u2014 the proposals weren't read, the credits returned to your account. You can use them for submissions to other retailers.",
        refund_alert_other_html: "<strong>Refund +{{count}} credits</strong> \u2014 the proposals weren't read, the credits returned to your account. You can use them for submissions to other retailers.",
        usage_split: "Used: {{used}} \xB7 Reserved: {{reserved}}",
        reserved_label: "Reserved",
        released_label: "Released reservations",
        released_hint: "Submissions expired unread. No credit was charged.",
        hist_released: "Reservation released \u2014 no credit charged"
      },
      wallet: {
        balance_label: "Wallet balance",
        funds_info_format: "Funds for further submissions \u2014 {{perSend}} EUR each",
        send_button: "Submit proposal",
        stats: {
          total_sent_label: "Total submitted",
          total_sent_unit: "mailings",
          seen_label: "Confirmed reads",
          seen_unit: "proposals",
          refunds_label: "Refunds",
          refunds_unit: "proposals"
        }
      },
      kpi: {
        effective_cost_label: "Effective cost",
        effective_cost_value_format: "{{amount}} EUR",
        effective_cost_sub: "after refunds",
        refunds_label: "Refunds",
        refunds_value_format: "+{{amount}} EUR",
        refunds_sub_pending: "booked / pending",
        refunds_sub_done: "to wallet",
        open_rate_label: "Open rate",
        open_rate_sub: "confirmed"
      },
      active_pkg: {
        card_title: "Active package",
        pkg_badge: "PACKAGE",
        per_send_format: "{{perSend}} EUR each",
        used_format: "Used: {{used}}/{{max}} submissions",
        price_label: "Package price",
        price_value_format: "{{price}} EUR",
        valid_until_label: "Valid until",
        change_btn: "Change package"
      },
      refunds_done: {
        card_title: "Refunds for unread submissions",
        alert_html: "<strong>{{count}} refunds = +{{total}} EUR</strong> returned to your wallet. You can use them for submissions to other retailers.",
        row_amount_format: "+{{amount}} EUR"
      },
      refunds_pending: {
        card_title: "Refunds in progress",
        alert_html_one: "<strong>1 refund is in progress.</strong> The proposal status has already expired, but the refund record is still posting to the wallet.",
        alert_html_other: "<strong>{{count}} refunds are in progress.</strong> The proposal status has already expired, but the refund record is still posting to the wallet.",
        row_label: "refund in progress"
      },
      recent_tx: {
        card_title: "Recent transactions",
        amount_format: "{{sign}}{{amount}} EUR"
      },
      history: {
        card_title: "Submission history",
        headers: {
          offer: "Proposal",
          retailer: "Retailer",
          tier: "Tier",
          date: "Date",
          status: "Status",
          amount: "Amount"
        },
        tier_premium: "Premium",
        tier_standard: "Standard",
        amount_eur_format: "{{amount}} EUR",
        refund_done_format: "+{{amount}} EUR",
        refund_pending: "refund in progress",
        awaiting: "pending",
        empty: "No submissions.",
        scheduled_mailing_format: "Scheduled for mailing \u2014 {{date}}"
      },
      pakiety: {
        payment_modal: {
          success_title: "Payment confirmed!",
          success_body_html: "Package <strong>{{pkgLabel}}</strong> has been activated.<br/>Added <strong>+{{qty}} submissions</strong> to your account.",
          success_body_credits_html: "Package <strong>{{pkgLabel}}</strong> has been activated.<br/>Added <strong>+{{qty}} credits</strong> to your account.",
          success_state_html: "Current balance: <strong>{{total}} submissions total</strong>",
          success_state_credits_html: "Current total: <strong>{{total}} credits</strong>",
          valid_until_html: "Your credits are valid until: <strong>{{date}}</strong>",
          pkg_label_premium_one: "Premium {{qty}} submission",
          pkg_label_premium_other: "Premium {{qty}} submissions",
          pkg_label_standard_one: "Standard {{qty}} submission",
          pkg_label_standard_other: "Standard {{qty}} submissions",
          pkg_label_credits_premium_one_format: "Premium {{qty}} credit",
          pkg_label_credits_premium_few_format: "Premium {{qty}} credits",
          pkg_label_credits_premium_many_format: "Premium {{qty}} credits",
          pkg_label_credits_premium_other_format: "Premium {{qty}} credits",
          pkg_label_credits_standard_one_format: "Standard {{qty}} credit",
          pkg_label_credits_standard_few_format: "Standard {{qty}} credits",
          pkg_label_credits_standard_many_format: "Standard {{qty}} credits",
          pkg_label_credits_standard_other_format: "Standard {{qty}} credits",
          title: "Confirm order",
          subtitle: "VAT invoice will be sent to your email",
          summary_pkg_label: "Package",
          summary_pkg_premium_one: "\u2B50 Premium \xB7 {{qty}} submission",
          summary_pkg_premium_other: "\u2B50 Premium \xB7 {{qty}} submissions",
          summary_pkg_standard_one: "Standard \xB7 {{qty}} submission",
          summary_pkg_standard_other: "Standard \xB7 {{qty}} submissions",
          summary_pkg_credits_premium_one_format: "\u2B50 Premium \xB7 {{qty}} credit",
          summary_pkg_credits_premium_few_format: "\u2B50 Premium \xB7 {{qty}} credits",
          summary_pkg_credits_premium_many_format: "\u2B50 Premium \xB7 {{qty}} credits",
          summary_pkg_credits_premium_other_format: "\u2B50 Premium \xB7 {{qty}} credits",
          summary_pkg_credits_standard_one_format: "Standard \xB7 {{qty}} credit",
          summary_pkg_credits_standard_few_format: "Standard \xB7 {{qty}} credits",
          summary_pkg_credits_standard_many_format: "Standard \xB7 {{qty}} credits",
          summary_pkg_credits_standard_other_format: "Standard \xB7 {{qty}} credits",
          summary_per_send_label: "Price each",
          summary_per_credit_label: "Price per credit",
          summary_per_send_format: "{{perSend}} EUR",
          summary_discount_label: "Discount",
          summary_discount_value_format: "\u2212{{percent}}% vs base price",
          summary_net_label: "Net",
          summary_net_format: "{{price}} EUR",
          summary_vat_label: "VAT 23%",
          summary_vat_format: "+{{amount}} EUR",
          summary_gross_label: "Gross",
          summary_gross_format: "{{amount}} EUR",
          pay_method_label: "Payment method",
          pay_card_label: "PayU online",
          pay_bank_label: "Bank transfer",
          pay_wallet_label_format: "From wallet ({{balance}} EUR)",
          pay_insufficient_funds_short: "Insufficient funds",
          wallet_insufficient_warn_format: "Missing {{missing}} EUR \u2014 top up the wallet or choose another method.",
          payu_online_title: "Online payment via PayU",
          payu_online_info: "After clicking the button, the system will redirect you to the secure PayU checkout. Card or transfer details are entered on PayU's side.",
          card_form_title: "Payment details",
          card_form_number_placeholder: "1234 5678 9012 3456",
          card_form_expiry_placeholder: "MM/YY",
          card_form_cvv_placeholder: "CVV",
          card_form_name_placeholder: "Cardholder name",
          bank_form_title: "Transfer details:",
          bank_form_beneficiary: "KJOW Sp. z o.o. \xB7 PKO BP",
          bank_form_iban: "PL 12 1440 1101 0000 0000 1234 5678",
          bank_form_title_label: "Title:",
          bank_form_title_value_format: "FM-{{plan}}-{{year}}",
          bank_form_info: "Once posted (1\u20132 business days) submissions will be added automatically.",
          cancel: "Cancel",
          processing: "Processing\u2026",
          pay_button_format: "Pay {{gross}} EUR (incl. VAT)",
          payment_init_error_format: "Payment initialization error: {{message}}",
          payment_init_error_fallback: "please try again",
          nip_required: "Provide the company Tax ID. This field is required for registration and billing.",
          no_redirect_error: "PayU did not return a redirect URL"
        },
        pkg_stats: {
          total_label: "Total in packages",
          used_label: "Used",
          remaining_label: "Remaining",
          unit: "submissions"
        },
        guarantee: "14-day guarantee \u2014 no buyer read = automatic credit refund to wallet. You buy submissions, not risk.",
        validity_info: "Purchased credits are valid for 12 months from the purchase date.",
        compare: {
          standard_badge: "STANDARD",
          standard_price_range: "40-30 EUR / submission",
          standard_b1_html: "<strong>Middle position</strong> in the buyer newsletter",
          standard_b2: "Full proposal content + your photos and logo",
          standard_b3: "Moderation before delivery (24h SLA)",
          standard_b4: "14-day guarantee \u2014 refund on no read",
          standard_when_html: "<strong>When to choose:</strong> you want many submissions at a lower price each \u2014 best for volume suppliers.",
          premium_top: "\u2B50 TOP POSITION",
          premium_badge: "PREMIUM",
          premium_price_range: "80-45 EUR / submission",
          premium_b1_html: "<strong>Your proposal first</strong> in the newsletter",
          premium_b2_html: "<em>Premium</em> mark in the email \u2014 visual distinction",
          premium_b3: "Full content + photos + logo (same as Standard)",
          premium_b4: "14-day guarantee \u2014 refund on no read",
          premium_when_html: "<strong>When to choose:</strong> you prioritize visibility and want the buyer to see you first \u2014 best for premium products, categories new to the retailer, key seasonal windows."
        },
        table: {
          std_subtitle: "Middle position in the newsletter",
          prem_subtitle: "TOP position \u2014 your proposal first in the newsletter",
          header_package: "Package",
          header_price: "Price",
          header_per_send: "Price each",
          header_per_credit: "Price per credit",
          header_discount: "Discount",
          popular_badge: "Popular",
          qty_one: "{{count}} submission",
          qty_other: "{{count}} submissions",
          qty_credits_one: "{{count}} credit",
          qty_credits_few: "{{count}} credits",
          qty_credits_many: "{{count}} credits",
          qty_credits_other: "{{count}} credits",
          credit_hint: "1 credit = 1 proposal submission to one retailer",
          price_eur_format: "{{amount}} EUR",
          discount_value_format: "\u2212{{percent}}%",
          base_label: "base",
          selected_badge: "Selected"
        },
        cta: {
          pkg_premium_one_format: "\u2B50 Premium \xB7 {{qty}} submission",
          pkg_premium_other_format: "\u2B50 Premium \xB7 {{qty}} submissions",
          pkg_standard_one_format: "Standard \xB7 {{qty}} submission",
          pkg_standard_other_format: "Standard \xB7 {{qty}} submissions",
          pkg_credits_premium_one_format: "\u2B50 Premium \xB7 {{qty}} credit",
          pkg_credits_premium_few_format: "\u2B50 Premium \xB7 {{qty}} credits",
          pkg_credits_premium_many_format: "\u2B50 Premium \xB7 {{qty}} credits",
          pkg_credits_premium_other_format: "\u2B50 Premium \xB7 {{qty}} credits",
          pkg_credits_standard_one_format: "Standard \xB7 {{qty}} credit",
          pkg_credits_standard_few_format: "Standard \xB7 {{qty}} credits",
          pkg_credits_standard_many_format: "Standard \xB7 {{qty}} credits",
          pkg_credits_standard_other_format: "Standard \xB7 {{qty}} credits",
          sub_format: "{{price}} EUR net \xB7 {{perSend}} EUR each",
          sub_with_discount_format: "{{price}} EUR net \xB7 {{perSend}} EUR each \xB7 \u2013{{discount}}% discount",
          sub_credits_format: "{{price}} EUR net \xB7 {{perSend}} EUR per credit",
          sub_credits_with_discount_format: "{{price}} EUR net \xB7 {{perSend}} EUR per credit \xB7 \u2013{{discount}}% discount",
          order_button: "Order package"
        },
        order_history: {
          card_title: "Order history",
          method_card: "\u{1F4B3} Card",
          method_bank: "\u{1F3E6} Transfer",
          method_wallet: "\u{1F4B0} Wallet",
          qty_added_format: "+{{qty}} submissions",
          qty_added_credits_one_format: "+{{qty}} credit",
          qty_added_credits_few_format: "+{{qty}} credits",
          qty_added_credits_many_format: "+{{qty}} credits",
          qty_added_credits_other_format: "+{{qty}} credits",
          price_format: "\u2212{{price}} EUR",
          paid_badge: "Paid"
        },
        proforma: {
          generate_button: "Generate proforma",
          title: "Proforma generated",
          subtitle_html: "Number: <strong>{{number}}</strong>. We have emailed it to you.",
          pay_info: "Pay by bank transfer using the details in the proforma. The credit package will be activated once the payment is posted.",
          download: "Download proforma",
          download_short: "Download",
          history_title: "Proformas (bank transfer)",
          status_pending: "Awaiting payment",
          status_paid: "Paid",
          status_cancelled: "Cancelled",
          error: "Could not generate the proforma."
        },
        credit_history: {
          card_title: "Credit package history",
          status_active: "Active",
          status_expired: "Expired",
          remaining_format: "{{remaining}}/{{total}} credits",
          valid_until_format: "valid until {{date}}",
          expired_on_format: "expired {{date}}"
        }
      }
    },
    company: {
      ai_banner: {
        strong: "AI Auto-fill",
        body: " \u2014 AI will generate a short and standard company description based on your data, materials, and website. The more fields you fill in below (operations, markets, certifications), the richer the profile.",
        generate_btn: "Generate AI",
        preview_btn: "Preview"
      },
      ai_modal: {
        title: "AI Auto-fill",
        description: "AI uses your profile data, extended profile, and the content of your website to propose two descriptions: short (for preview) and standard (main profile description).",
        website_label: "Website",
        analyzing: "Analyzing the website and preparing descriptions...",
        generate_btn: "Generate",
        cancel: "Cancel"
      },
      completeness_label: "Profile completeness",
      logo: {
        card_title: "Logo",
        upload_change: "Click to change logo",
        upload_new: "Click to upload company logo",
        required_for_publish: "Required for publishing"
      },
      basics: {
        card_title: "Basic data",
        name_label: "Company name",
        nip_label: "VAT ID",
        country_label: "Country",
        country_dash: "\u2014",
        city_label: "City",
        website_label: "Website",
        phone_label: "Phone"
      },
      visibility: {
        card_title: "Profile visibility in the buyer catalog",
        intro: "By default, your company profile is visible to all active retailers in the catalog. Select retailers you want to hide your profile from.",
        retailer_list_label: "Hide profile from selected retailers",
        visible_all: "Visible to all active retailers",
        hidden_count_format: "Hidden from {{count}} retailers",
        empty_retailers: "No active retailers to choose from.",
        visible_badge: "visible",
        hidden_badge: "hidden",
        save_btn: "Save visibility",
        saving: "Saving...",
        saved: "Profile visibility saved.",
        save_error_format: "Could not save visibility: {{message}}"
      },
      desc: {
        card_title: "Company description",
        ready_badge: "Ready to display",
        edited_badge: "Edited",
        review_badge: "Awaiting review",
        short_label: "Short description \u2014 Polish version (PL), 2\u20133 sentences, ~200\u2013300 chars",
        short_hint: "Shown on the company card to the buyer and in the preview. Don't repeat the company name \u2014 the buyer already sees it.",
        standard_label: "Standard description \u2014 Polish version (PL), 4\u20136 sentences, ~450\u2013700 chars",
        standard_hint: "Main profile description. Generated by AI from your data \u2014 you can edit it manually.",
        en_intro: "English version \u2014 shown to buyers who use the app in English. Buyers with the Polish interface see the Polish fields above. Do not put English text into the Polish fields.",
        short_en_label: "Short description \u2014 English version (EN)",
        standard_en_label: "Standard description \u2014 English version (EN)",
        en_hint: "If both English fields are left empty, buyers with the English interface will see the Polish version."
      },
      types: {
        card_title: "Company type and categories",
        types_label: "Company type",
        types_label_note: "(visible to buyers)",
        categories_label: "Product categories",
        products_label: "Products",
        markets_label: "Sales markets",
        company_type_options: {
          producent: "Producer",
          eksporter: "Exporter",
          importer: "Importer",
          firma_handlowa: "Trading company",
          pakowalnia: "Packing house",
          firma_logistyczna: "Logistics company",
          kooperatywa: "Cooperative",
          agent: "Agent / Broker"
        },
        category_options: {
          owoce: "Fruits",
          warzywa: "Vegetables",
          kwiaty: "Flowers",
          ziola: "Herbs",
          inne: "Other"
        }
      },
      ext_basics: {
        card_title: "Extended profile \u2014 basics",
        info: "Optional fields. The more you fill in, the richer the profile for the buyer.",
        founded_year_label: "Year founded",
        employees_label: "Number of employees",
        employees_options: {
          empty: "\u2014",
          "1_10": "1\u201310",
          "11_50": "11\u201350",
          "51_200": "51\u2013200",
          "201_500": "201\u2013500",
          "500_plus": "500+"
        }
      },
      ext_offer: {
        card_title: "Extended profile \u2014 offer",
        year_round_label: "Year-round products",
        year_round_hint: "e.g. apples, pears, cabbage",
        seasonal_label: "Seasonal products",
        seasonal_hint: "e.g. strawberries (V\u2013VII), cherries (VI\u2013VII)",
        customer_types_label: "Types of customers served",
        customer_type_options: {
          retail: "Retail",
          wholesale: "Wholesale",
          horeca: "HoReCa",
          processing: "Processing",
          export: "Export"
        },
        private_label_toggle: "We offer private label"
      },
      ext_trade: {
        card_title: "Extended profile \u2014 trade and markets",
        export_countries_label: "Export countries (ISO codes separated by commas)",
        export_countries_hint: "e.g. DE, CZ, SK, FR, NL",
        main_markets_label: "Main markets (descriptive)",
        main_markets_hint: "e.g. Central EU, DACH countries, domestic market",
        partnership_label: "Partnership types",
        partnership_options: {
          programy_stale: "Year-round programs",
          spot: "Spot",
          promocje: "Promotions",
          sezonowe_akcje: "Seasonal campaigns"
        },
        typical_volumes_label: "Typical volumes",
        typical_volumes_hint: "e.g. 10\u201350 tons per week, 1\u20132 trucks per day"
      },
      ext_ops: {
        card_title: "Extended profile \u2014 operational backbone",
        info: "Check what you have available or what you can offer.",
        capability_options: {
          sortownia: "Sorting line",
          pakowalnia: "Packing house",
          chlodnia: "Cold storage",
          linia_optyczna: "Optical line",
          etykietowanie: "Labeling",
          konfekcjonowanie: "Packaging",
          retail_ready: "Retail-ready preparation",
          wlasna_logistyka: "Own logistics",
          partner_logistyczny: "Logistics partner"
        }
      },
      materials: {
        card_title: "Materials (PDF, catalogs, photos)",
        info: "Upload a trade catalog, brochure, photos of the facility / packing / products. The buyer will see them in the profile preview.",
        uploader_label: "Click or drag a PDF / photo",
        saved_toast: "\u2713 Material uploaded and saved.",
        save_failed: "File uploaded, but the list could not be saved \u2014 please click \u201CSave profile\u201D."
      },
      pitch: {
        card_title: "What do you want to highlight to the buyer?",
        hint: "Free text \u2014 AI will use it as a signal for your trade priorities. It won't copy it verbatim."
      },
      certs: {
        card_title: "Certifications",
        info: "Select the certifications you want to show to buyers. The profile displays certification names only.",
        popular_label: "Common certifications",
        custom_label: "Other certifications",
        custom_placeholder: "e.g. Organic, IFS Food, HACCP",
        custom_hint: "If you have more than one, separate them with commas.",
        number_prefix_format: "No.: {{number}}",
        valid_prefix_format: "until {{date}}"
      },
      contacts: {
        card_title: "Contacts",
        add_btn: "Add contact",
        empty_info: "Add a contact person visible to buyers.",
        add_first_btn: "Add first contact",
        remove_title: "Remove contact",
        role_label: "Role",
        name_label: "Full name",
        position_label: "Position",
        phone_label: "Phone",
        email_label: "Email",
        role_options: {
          sales: "Sales",
          quality: "Quality",
          logistics: "Logistics",
          management: "Management",
          other: "Other"
        }
      },
      actions: {
        preview_buyer: "Buyer preview",
        save_btn: "Save profile",
        incomplete_notice: "The profile will be saved, but it is not complete yet. Add {{missing}}.",
        saving: "Saving..."
      },
      gaps: {
        logo: "the company logo",
        nip: "the Tax ID",
        joiner: " and "
      },
      toasts: {
        logo_required: "Upload the company logo.",
        nip_required: "Provide the company Tax ID. This field is required for registration and billing.",
        saved: "Profile saved.",
        saved_incomplete: "Profile saved. It is not complete yet \u2014 add {{missing}}.",
        saved_newer_draft: "The earlier version of the profile was saved. You made new changes while it was saving \u2014 they are an unsaved draft, click \u201CSave profile\u201D again.",
        contacts_error_format: "Failed to save contacts: {{message}}"
      }
    }
  },
  buyer: {
    profile: {
      page_title: "My profile",
      card_data_title: "Details",
      labels: {
        name: "Full name",
        position: "Position",
        retailer: "Retailer",
        email_admin_change: "Email (admin-managed)",
        phone: "Phone"
      },
      subscription_card_title: "Email subscription",
      subscription_consent_label: "Consent to PreConnect mailing",
      subscription_consent_hint: "PreConnect mailing is sent once a month, on the first Tuesday of the month. You can withdraw consent at any time.",
      subscription_active_notice: "Subscription active \xB7 Next mailing: {{date}}",
      save_button: "Save",
      saved_flash: "Profile saved."
    },
    password: {
      card_title: "Change password",
      notice: "Enter your current password and a new one (minimum 8 characters). You will stay signed in on this device after the change.",
      no_current_link: "Don't know your current password? Set a new one",
      have_current_link: "\u2190 Back to change with current password",
      no_current_notice: "You are setting a new password without entering the current one \u2014 possible because you signed in via a secure email link. The new password works immediately.",
      labels: {
        current: "Current password",
        new: "New password (min. 8 characters)",
        repeat: "Repeat new password"
      },
      show: "show",
      hide: "hide",
      show_title: "Show password",
      hide_title: "Hide password",
      submit_button: "Change password",
      submitting: "Changing...",
      errors: {
        empty_fields: "Please fill in all fields.",
        length: "New password must be at least 8 characters.",
        mismatch: "New password and confirmation don't match.",
        default_prefix: "Error: ",
        default_fallback: "failed to change password"
      },
      success: "Password changed successfully."
    },
    dashboard: {
      how_it_works: {
        toggle_title: "How does it work?",
        expand: "Expand \u25BC",
        collapse: "Collapse \u25B2",
        intro_pre_link: "Welcome to the Fresh Market buyer panel. This panel serves two purposes: reviewing ",
        intro_offers: "product submissions from suppliers",
        intro_middle: " in the PreConnect module, and ",
        intro_meetings: "choosing companies for meetings",
        intro_post: " during Fresh Market 2026.",
        preconnect_section_title: "PreConnect module",
        preconnect_li_1_title: "Product submissions:",
        preconnect_li_1_text: " In this section you receive submissions from suppliers matched to your retailer.",
        preconnect_li_2_title: "Submission review:",
        preconnect_li_2_text: " You can open product details and check parameters, logistics, certificates and supporting materials.",
        preconnect_li_3_title: "Saved:",
        preconnect_li_3_text: " If a submission is interesting, you can save it for later review.",
        preconnect_li_4_title: "Read status:",
        preconnect_li_4_text: " Opening details means the submission has been read by the buyer.",
        fm_section_title: "B2B Meetings \u2014 Fresh Market 2026",
        fm_li_1_title: "Choosing suppliers:",
        fm_li_1_text: " In this section you see companies that want to meet with your retailer during Fresh Market 2026.",
        fm_li_2_title: "Your decision:",
        fm_li_2_text_pre: " You can mark a supplier as: ",
        fm_li_2_em1: "Interested",
        fm_li_2_text_mid1: ", ",
        fm_li_2_em2: "Maybe",
        fm_li_2_text_mid2: " or ",
        fm_li_2_em3: "Not interested",
        fm_li_2_text_post: ".",
        fm_li_3_title: "Meeting plan:",
        fm_li_3_text: " Based on buyer decisions and supplier choices, the system prepares a proposed meeting schedule.",
        fm_li_4_title: "Final results:",
        fm_li_4_text: " The final meeting schedule will appear in the panel after the organiser confirms it.",
        help_section_title: "Help",
        help_text: "If you have questions or notice incorrect data, contact the organiser via chat or the contact details in the panel."
      },
      preconnect_block: {
        title: "PreConnect",
        desc_strong: "Browse submissions from suppliers",
        desc_post: " matched to your retailer.",
        desc_line2: "Open details, compare products and save the most interesting submissions.",
        unread_one: "{{count}} new submission waiting to be read",
        unread_many: "{{count}} new submissions waiting to be read",
        see_offers_title: "See submissions",
        see_offers_sub: "Product submissions from suppliers",
        supplier_base_title: "Supplier directory",
        supplier_base_sub: "Company profiles and certificates"
      },
      fm_block: {
        title: "Fresh Market 2026",
        badge_active: "\u25CF ACTIVE",
        badge_closed: "\u{1F512} CLOSED",
        desc_strong: "Choose suppliers you want to meet during the event.",
        desc_post_pre_em1: " Mark companies as ",
        desc_em1: "Interested",
        desc_post_em1: ", ",
        desc_em2: "Maybe",
        desc_post_em2: " or ",
        desc_em3: "Not interested",
        desc_post_em3: ", and the system will prepare the meeting plan.",
        deadline_open_pre: "Submit your choices by ",
        deadline_open_date1: "16 September",
        deadline_open_mid: ". Final schedule: ",
        deadline_open_date2: "22 September",
        deadline_open_dot: ".",
        deadline_closed_pre: "Registration will open soon. Choices: by ",
        deadline_closed_date1: "16 September 2026",
        deadline_closed_mid: ". Final schedule: ",
        deadline_closed_date2: "22 September",
        deadline_closed_dot: ".",
        phase_until_16_label: "by 16 September",
        phase_until_16_sub: "You indicate companies you want to meet",
        phase_close_label: "16 September",
        phase_close_sub: "Choices close \u2014 further changes by admin only",
        phase_algo_label: "17\u201322 September",
        phase_algo_sub: "Algorithm + manual admin corrections",
        phase_publish_label: "22 September",
        phase_publish_sub: "Publication of the final schedule and numbers",
        phase_event_label: "24 September",
        phase_event_sub: "Event \u2014 Fresh Market 2026",
        btn_goto_fm: "Go to FM 2026 Meetings",
        btn_see_meetings: "See meetings",
        contact_pre: "Questions? Contact: ",
        contact_name: "Oksana Koz\u0142owska",
        contact_post: " \xB7 oksana@freshmarket.eu \xB7 +48 509 086 949"
      }
    },
    offers: {
      header_label_saved: "Saved",
      header_label_preconnect: "PreConnect",
      title_saved: "Saved submissions",
      title_preconnect: "Product submissions",
      subtitle_saved: "Submissions you've marked as interesting.",
      subtitle_preconnect_pre: "Specific products from verified suppliers. ",
      subtitle_preconnect_post: "Each submission shows who's behind it \u2014 company type, country, certificates.",
      stats: {
        offers_label: "Submissions",
        offers_sub: "{{premium}} Premium \xB7 {{standard}} Standard",
        saved_label: "Saved",
        saved_sub: "marked"
      },
      filters: {
        verified: "With certificates",
        with_photos: "With photos",
        starred: "Saved",
        company_type_all: "Company type: all"
      },
      empty_starred: "No submissions marked as saved.",
      empty_no_match: "No submissions match the criteria.",
      card: {
        supplier_fallback: "Supplier",
        certs_present: "Certificates provided",
        certs_missing: "No certificates provided",
        premium_badge: "Premium",
        new_badge: "New",
        bio_badge: "\u{1F33F} Bio",
        star_add: "Save",
        star_remove: "Remove from saved",
        details_button: "Details",
        no_photos_label: "no photos",
        moq_label: "Min. order",
        lead_time_label: "Lead time",
        delivery_regions_prefix: "\u{1F4CD} ",
        price_disclaimer: "indicative price \xB7 to be confirmed",
        warn_no_certs: "\u26A0 no certificates provided",
        warn_no_photos: "\u26A0 no product photos"
      }
    },
    catalog: {
      header_label: "Reference base",
      title: "Suppliers",
      subtitle_pre: "Complete database of verified companies \u2014 certificates, countries, products and history. ",
      subtitle_post: "For the main product submissions, go back to the ",
      subtitle_link: "Product submissions",
      summary: "{{total}} verified companies \xB7 {{withOffers}} have active submissions",
      search_placeholder: "Search supplier...",
      country_filter_all: "All countries",
      category_filter_all: "All categories",
      category_options: {
        owoce: "\u{1F34E} Fruits",
        warzywa: "\u{1F955} Vegetables",
        kwiaty: "\u{1F338} Flowers"
      },
      empty_no_match: "No suppliers match the criteria.",
      card: {
        active_offers_one: "{{count}} active submission",
        active_offers_few: "{{count}} active submissions",
        active_offers_many: "{{count}} active submissions",
        no_offers: "No submissions",
        see_profile: "See profile"
      }
    },
    detail: {
      top: {
        back_short: "Back",
        back_to_offers: "Back to submissions",
        save_saved: "Saved \u2713",
        save_unsaved: "Save submission"
      },
      hero: {
        kv_volume: "Volume",
        kv_moq: "Min. order",
        kv_lead_time: "Lead time",
        kv_season: "Season"
      },
      sections: {
        identification: "Product identification",
        what_distinguishes: "What sets this supplier apart?",
        shop_benefit_label: "How it helps in-store sales",
        photos_format: "Product photos ({{count}})",
        photo_alt_format: "Photo {{n}}",
        photo_main: "Main",
        photos_click_hint: "Click a photo to open it in full size.",
        quality_spec: "Quality specification",
        flower_params: "Flower parameters",
        availability: "Availability and volume",
        packaging: "Packaging and palletisation",
        logistics: "Logistics and complaints",
        certs: "Certificates and traceability",
        price_terms: "Indicative price and commercial terms",
        price_indicative_badge: "Indicative price",
        price_current_format: "Current: {{from}} \u2013 {{to}}",
        price_disclaimer: "\u24D8 The price is indicative and requires confirmation with the supplier. You will receive the current price and terms after contacting them.",
        risks: "Cooperation safety",
        risk_mitigation_label: "How the supplier secures the cooperation",
        risk_proof_label: "Credibility confirmation",
        risk_now_label: "Why now?",
        description_fallback: "Submission description"
      },
      kv: {
        name: "Name",
        variety: "Variety",
        category: "Category",
        subcategory: "Subcategory",
        country: "Country",
        region: "Region",
        offer_type: "Submission type",
        positioning: "Positioning",
        size: "Calibre / size",
        quality_class: "Quality class",
        brand: "Brand",
        sale_mode: "Sale mode",
        brix: "Brix",
        color_spec: "Colour / coloration",
        bio_organic: "Bio / Organic",
        bio_yes: "Yes",
        stem_length: "Stem length",
        opening_phase: "Opening phase",
        bouquet_count: "Stems per bouquet",
        vase_life: "Vase life",
        flower_color: "Colour / mix",
        availability_from: "Available from",
        availability_to: "Available to",
        availability_model: "Availability model",
        volume_min: "Volume min.",
        volume_max: "Volume max.",
        moq: "Min. order",
        lead_time: "Lead time",
        promo_volume: "Promo +%",
        packaging_desc: "Packaging description",
        pallet_type: "Pallet type",
        pallet_height: "Pallet height",
        cartons_per_layer: "Cartons per layer",
        layers_per_pallet: "Layers per pallet",
        units_per_pallet: "Units per pallet",
        srp: "Shelf-ready (SRP)",
        delivery_model: "Delivery model",
        loading_point: "Loading point",
        delivery_regions: "Delivery regions",
        cold_chain: "Transport setup",
        temp_transport: "Temperature",
        traceability: "Traceability",
        cert_number: "Certificate number",
        cert_valid: "Valid until",
        current_tests: "Current tests",
        promo_price: "Promo price available",
        contract_program: "Contract programme",
        samples_avail: "Samples"
      },
      cta: {
        section_label: "Possible actions",
        section_intro: "Contact the supplier \u2014 you can request a sample, ask about the current price, request a specification, or schedule a call.",
        subject_fallback: "PreConnect \u2013 inquiry",
        subjects: {
          samples: "PreConnect \u2013 sample request: {{product}}",
          spec: "PreConnect \u2013 specification request: {{product}}",
          rfq: "PreConnect \u2013 price and volume inquiry: {{product}}",
          call: "PreConnect \u2013 call request: {{product}}",
          long_term: "PreConnect \u2013 seasonal program: {{product}}",
          meet_fm: "PreConnect \u2013 Fresh Market 2026 meeting: {{product}}"
        },
        bodies: {
          samples: 'Hello,\n\nRegarding the PreConnect submission for Fresh Market 2026 titled "{{product}}", I would like to request a product sample.\n\nPlease contact me to arrange the details.\n\nKind regards',
          spec: 'Hello,\n\nRegarding the PreConnect submission for Fresh Market 2026 titled "{{product}}", please send the full technical specification and quality documentation.\n\nKind regards',
          rfq: 'Hello,\n\nRegarding the PreConnect submission for Fresh Market 2026 titled "{{product}}", I would like to ask about the current price and available volumes.\n\nPlease send the current price, available volumes, and delivery terms.\n\nKind regards',
          call: 'Hello,\n\nRegarding the PreConnect submission for Fresh Market 2026 titled "{{product}}", I would like to schedule a phone call.\n\nCould you propose a time?\n\nKind regards',
          long_term: 'Hello,\n\nRegarding the PreConnect submission for Fresh Market 2026 titled "{{product}}", I would like to ask about the possibility of starting a seasonal program / long-term contract.\n\nPlease contact me to discuss the details.\n\nKind regards',
          meet_fm: 'Hello,\n\nRegarding the PreConnect submission for Fresh Market 2026 titled "{{product}}", I would like to schedule a meeting at the Fresh Market 2026 fair (24 September, O\u017Car\xF3w Mazowiecki).\n\nIs that possible?\n\nKind regards'
        }
      },
      supplier_card: {
        title: "Supplier",
        certs_present: "Certificates provided",
        certs_missing: "No certificates provided",
        full_profile_button: "Full supplier profile"
      },
      contact_card: {
        title: "Contact the supplier",
        notice: "You can contact them directly"
      }
    }
  },
  admin: {
    proformas: {
      card_title: "Proformas awaiting payment (bank transfer)",
      mark_paid: "Mark paid \u2192 activate package",
      marking: "Activating\u2026",
      paid_toast: "Proforma {{number}} paid \u2014 package activated.",
      error: "Could not mark the proforma as paid.",
      empty: "Proformas will appear here only after a supplier generates them (bank-transfer payment)."
    },
    settlements: {
      title: "Supplier settlements",
      subtitle: "Proformas, credit packages, and supplier payments.",
      revenue_label: "Confirmed revenue (legacy/estimate)",
      revenue_hint: "Legacy-model estimate: confirmed submissions \xD7 40 EUR.",
      filter_company_ph: "Search company / Tax ID\u2026",
      pf_filter_all: "Proformas: all",
      pf_filter_pending: "Proformas: pending",
      pf_filter_paid: "Proformas: paid",
      pf_filter_cancelled: "Proformas: cancelled",
      payu_filter_relevant: "PayU: paid/pending",
      payu_filter_all: "PayU: all",
      payu_filter_completed: "PayU: paid",
      payu_filter_pending: "PayU: pending",
      payu_filter_failed: "PayU: errors",
      pkg_filter_all: "Packages: all",
      pkg_filter_active: "Packages: active",
      pkg_filter_expired: "Packages: expired",
      loading: "Loading settlements\u2026",
      proformas_title: "Proformas",
      proformas_empty: "No proformas matching the filters.",
      payu_title: "Online PayU payments",
      payu_empty: "No PayU payments matching the filters.",
      packages_title: "Supplier credits",
      packages_empty: "No supplier has purchased packages yet.",
      net: "Net",
      gross: "Gross",
      col_bought: "Bought",
      col_used: "Used",
      col_remaining: "Remaining",
      col_valid_until: "Valid until",
      status_active: "Active",
      status_expired: "Expired",
      pf_status_pending: "Awaiting payment",
      pf_status_paid: "Paid",
      pf_status_cancelled: "Cancelled",
      payu_status_created: "Created",
      payu_status_pending: "Pending",
      payu_status_completed: "Paid",
      payu_status_canceled: "Cancelled",
      payu_status_rejected: "Rejected",
      payu_status_failed: "Failed"
    },
    common: {
      save_changes_btn: "\u{1F4BE} Save changes",
      saving: "Saving...",
      saved_indicator: "\u2713 Saved",
      save_error_prefix: "Save error: ",
      cancel: "Cancel",
      delete: "Delete",
      add: "Add",
      edit: "Edit",
      active_badge: "Active",
      inactive_badge: "Inactive"
    },
    dash: {
      urgent_title: "Action required",
      urgent_proposals_html_one: "<strong>{{count}}</strong> proposal awaiting moderation",
      urgent_proposals_html_few: "<strong>{{count}}</strong> proposals awaiting moderation",
      urgent_proposals_html_many: "<strong>{{count}}</strong> proposals awaiting moderation",
      urgent_proposals_html_other: "<strong>{{count}}</strong> proposals awaiting moderation",
      urgent_firms_html_one: "<strong>{{count}}</strong> company awaiting account activation",
      urgent_firms_html_few: "<strong>{{count}}</strong> companies awaiting account activation",
      urgent_firms_html_many: "<strong>{{count}}</strong> companies awaiting account activation",
      urgent_firms_html_other: "<strong>{{count}}</strong> companies awaiting account activation",
      urgent_separator: " \xB7 ",
      urgent_btn_pipeline: "Open Pipeline \u2192",
      urgent_btn_firmy: "Open Companies \u2192",
      kpi_revenue_label: "Revenue (confirmed)",
      kpi_revenue_value_format: "{{amount}} EUR",
      settlements_nav_sub: "Supplier finances: proformas, credits, payments",
      kpi_moderation_label_format: "Awaiting moderation ({{count}})",
      kpi_moderation_value_action: "Action required",
      kpi_moderation_value_ok: "OK",
      kpi_approved_label_format: "Approved ({{count}})",
      kpi_approved_value_ready: "Ready for delivery",
      kpi_approved_value_dash: "\u2014",
      kpi_pending_confirm_label_format: "Awaiting confirmation ({{count}})",
      kpi_pending_confirm_value_tracking: "Tracking active",
      kpi_pending_confirm_value_dash: "\u2014",
      fm_status_label: "Fresh Market 2026 \u2014 Status",
      fm_status_closed_badge: "\u{1F534} Closed",
      fm_status_open_badge: "\u{1F7E2} Open",
      fm_status_cta_hint: "click to manage \u2192",
      fm_status_stat_suppliers: "Suppliers",
      fm_status_stat_retailers: "Retailers",
      fm_status_stat_meetings: "Meetings",
      nav_pipeline_title: "Pipeline",
      nav_pipeline_desc: "Moderation, delivery, 14-day confirmations",
      nav_retailers_title: "Retailers",
      nav_retailers_desc: "Buyer contacts and delivery schedule",
      nav_firmy_title: "Companies",
      nav_firmy_desc: "Packages, limits, settlements per company",
      p_modules_title: "Modules",
      p_kpi_firms: "Companies to activate",
      p_kpi_moderation: "To moderate",
      p_kpi_approved: "Ready to send",
      p_kpi_tracking: "Awaiting confirmation",
      p_kpi_proformas: "Proformas pending",
      p_nav_pipeline_desc: "Moderation, sending, tracking",
      p_nav_firmy_desc: "Activation, profiles, access",
      p_nav_settlements_desc: "Proformas, packages, payments",
      p_nav_retailers_desc: "Buyers, contacts, schedule",
      p_nav_messages_desc: "Chat with suppliers and buyers"
    },
    pipeline_split: {
      tab_moderation: "To moderate",
      tab_networks: "Networks / mailing",
      tab_suppliers: "Suppliers / tracking",
      mod_offer: "Offer",
      mod_supplier: "Supplier",
      mod_retailer: "Network",
      mod_empty: "No offers to moderate.",
      net_col_network: "Network",
      net_col_in_panel: "In buyer panel",
      net_col_in_basket: "In email basket",
      net_col_sent: "Emailed",
      net_col_last_email: "Last email sent",
      net_col_next_planned: "Next planned send",
      net_send_email: "Send email to this network",
      net_empty: "No networks.",
      net_global_bar: "Next mailing (first Tuesday of the month): {{date}}",
      sup_col_supplier: "Supplier",
      sup_col_in_panel: "Offers in buyer panels",
      sup_col_networks: "Networks reached",
      sup_col_last_added: "Last added to panel",
      sup_col_last_email: "Last email",
      sup_col_read_deadline: "Read / settlement deadline",
      sup_col_read: "Read",
      sup_col_awaiting: "Awaiting settlement/refund",
      sup_empty: "No suppliers.",
      date_none: "\u2014",
      date_legend: "Added to panel = when the offer reached the buyer panel \xB7 Planned send = first Tuesday after adding \xB7 Email sent = actual email date \xB7 Read deadline = 14 days from email sent.",
      prop_col_network: "Network",
      prop_col_product: "Product",
      prop_col_added: "Added to panel",
      prop_col_planned: "Planned send",
      prop_col_emailed: "Email sent",
      prop_col_read: "Read",
      prop_col_deadline: "Read deadline",
      prop_col_settle: "Settlement / refund",
      prop_preview: "Preview",
      prop_settle_settled: "Settled",
      prop_settle_awaiting: "Awaiting settlement",
      prop_settle_refunded: "Refunded",
      prop_settle_awaiting_refund: "Awaiting refund"
    },
    retailers: {
      header_title: "Retailers and buyers",
      header_stats_format: "{{active}} active \xB7 {{inactive}} inactive \xB7 {{buyers}} buyers total",
      header_add_btn: "Add retailer",
      header_cancel_btn: "Cancel",
      search_placeholder: "Search retailer or country...",
      filter_countries_all: "All countries",
      filter_categories_all: "All categories",
      filter_active_all: "All",
      filter_active_active: "Active",
      filter_active_inactive: "Inactive",
      cat_options: {
        owoce: "\u{1F34E} Fruits",
        warzywa: "\u{1F955} Vegetables",
        kwiaty: "\u{1F338} Flowers"
      },
      form_title: "New retailer",
      form_name_label: "NAME *",
      form_name_placeholder: "e.g. Kaufland CZ",
      form_country_label: "COUNTRY *",
      form_country_dash: "\u2014 select \u2014",
      form_next_send_label: "FIRST SUBMISSION",
      form_desc_label: "DESCRIPTION / NOTE",
      form_fm26_toggle: "Retailer participates in Fresh Market 2026",
      form_fm26_id_label: "FM 2026 retailer ID (fm26ChainId)",
      form_fm26_id_required_mark: "*",
      form_fm26_id_placeholder: "e.g. ch28, ch29 \u2014 must be unique",
      form_fm26_id_hint: "Without this ID the retailer won't appear in the supplier FM panel. E.g. ch28, ch29...",
      form_buyer_section_title: "Buyer (main contact)",
      form_buyer_name_label: "FULL NAME *",
      form_buyer_name_placeholder: "e.g. Anna Kowalska",
      form_buyer_email_label: "EMAIL *",
      form_buyer_email_placeholder: "buyer@retailer.com",
      form_buyer_phone_label: "PHONE",
      form_buyer_phone_placeholder: "+48 22 123 4567",
      form_buyer_position_label: "POSITION",
      form_buyer_position_placeholder: "e.g. Category Manager",
      form_buyer_resp_label: "RESPONSIBLE FOR *",
      form_add_btn: "Add retailer",
      form_cancel_btn: "Cancel",
      form_err_required: "Required",
      form_err_country_required: "Required",
      form_err_buyer_name_required: "Required",
      form_err_buyer_email_required: "Required",
      form_err_invalid_email: "Invalid email",
      form_err_cats_required: "Select min. 1",
      form_err_email_duplicate_format: "Email is already assigned to {{buyerName}} at {{retailerName}}",
      form_err_fm26_id_required: "Required when retailer participates in FM 2026 (e.g. ch28)",
      form_err_fm26_id_taken: "This ID is already taken by another retailer",
      empty: "No retailers matching the criteria.",
      list_buyers_count_format: "{{count}} active buyers \xB7 Submission: {{date}}",
      list_saved_indicator: "\u2705 Saved",
      list_active_badge: "\u2705 Active",
      list_inactive_badge: "\u26D4 Inactive",
      list_fm26_active_badge: "\u{1F4C5} FM 2026",
      list_fm26_inactive_badge: "\u{1F4C5} Outside FM",
      gate_label: "Gate",
      gate_none: "\u2014 not set \u2014",
      gate_hint: "Which meeting-zone entrance displays this chain\u2019s logo. Printed on supplier cards (\u201CGate\u201D column).",
      list_fm26_toggle_title: "Click to toggle \u2014 saves immediately. fm26ChainId and FM26 buyers are set by expanding the retailer card.",
      expand_logo_label: "RETAILER LOGO",
      expand_logo_upload_change: "Click to change retailer logo",
      expand_logo_upload_new: "Click to upload retailer logo",
      expand_field_name: "NAME",
      expand_field_country: "COUNTRY",
      expand_field_next_send_label: "NEXT SUBMISSION",
      expand_field_next_send_hint: "(defaults to first Tuesday of the month)",
      expand_field_desc_label: "ADMIN DESCRIPTION / NOTE",
      supplier_req_label: "PreConnect \u2014 retailer purchasing requirements",
      supplier_req_help: "Shown before sending a PreConnect proposal and requiring acknowledgement. Enter purchasing requirements, import restrictions or volumes. Put online meeting arrangements and hours in the separate FM fields below.",
      fm_note_label: "FM \u2014 meeting arrangements",
      fm_note_help: "Online format, availability hours and event instructions. Shown next to the retailer in FM, without acknowledgement and without affecting PreConnect proposals.",
      fm_note_pl: "Information in Polish",
      fm_note_en: "Information in English",
      supplier_req_placeholder: "E.g. This retailer does not import directly from abroad. It prefers suppliers operating through local distributors in Poland. Large export volume offers may not be a good fit.",
      buyers_section_title_format: "Buyers ({{count}})",
      buyers_add_btn: "Add buyer",
      buyer_no_format: "Buyer #{{n}}",
      buyer_active: "Active",
      buyer_inactive: "Inactive",
      buyer_fm26: "FM 2026",
      buyer_field_name_label: "FULL NAME",
      buyer_field_name_placeholder: "e.g. Anna Nowak",
      buyer_field_email_label: "EMAIL",
      buyer_field_email_placeholder: "buyer@retailer.com",
      buyer_field_phone_label: "PHONE",
      buyer_field_phone_placeholder: "+48 22 ...",
      buyer_field_position_label: "POSITION",
      buyer_field_position_placeholder: "e.g. Category Manager",
      buyer_resp_label: "RESPONSIBLE FOR",
      new_buyer_accounts_title: "New buyer accounts created",
      save_btn: "\u{1F4BE} Save changes",
      saving: "Saving...",
      collapse_btn: "Collapse",
      toast_save_failed_default: "Failed to save change.",
      toast_save_failed_full_default: "Failed to save changes.",
      toast_saved_full: "\u2705 Network saved.",
      toast_save_name_required: "Retailer must have a name.",
      toast_save_active_needs_buyer: "An active retailer must have at least one active buyer.",
      toast_save_fm26_needs_fm_buyer: "An FM 2026 retailer must have at least one active buyer marked for FM 2026.",
      toast_save_buyer_name_required: "Every active buyer must have a full name.",
      toast_save_buyer_email_required: "Every active buyer must have an email.",
      toast_save_buyer_email_invalid_format: 'Email of buyer "{{buyer}}" has invalid format.',
      toast_save_buyer_email_unique: "Buyer email within a single retailer must be unique.",
      toast_save_buyer_email_duplicate_format: "Email {{email}} is already assigned to buyer {{buyer}} at retailer {{retailer}}.",
      toast_save_buyer_cats_required: "Every active buyer must have min. 1 category.",
      toast_save_fm26_id_required: "An FM 2026 retailer must have its chain ID set.",
      toast_duplicate_buyer_fallback: "buyer"
    },
    firmy: {
      grant_btn: "Grant free credits",
      grant_locked_hint: "The result of the previous attempt is uncertain (connection error). Retry without changes or close and reopen the form \u2014 fields are locked so the same key never goes out with different content.",
      grant_retry_btn: "Retry",
      grant_uncertain_close: "The result of the last attempt is unknown. Before trying again, check the batch history to see whether the credits were already granted \u2014 reopening the form starts a new batch, not a retry.",
      grant_mismatch_error: "This form was already submitted with different content. Close it and open it again.",
      grant_modal_title: "Free PreConnect credits from the organiser",
      grant_intro: "Credits reach the selected companies immediately, without payment. The supplier sees them separately as \u201CFree from the organiser\u201D together with your message. No e-mail is sent.",
      grant_companies_label: "Companies ({{count}})",
      grant_add_company_placeholder: "Add another company \u2014 type a name",
      grant_remove_company: "Remove",
      grant_qty_label: "Credits per company",
      grant_reason_label: "Reason",
      grant_reason_promotion: "Promotion",
      grant_reason_compensation: "Compensation",
      grant_reason_gift: "Gift",
      grant_reason_registration: "Registration gift",
      grant_reason_other: "Other",
      grant_expires_label: "Valid until",
      grant_expires_hint: "Defaults to 3 months from the grant date (computed in the database). Purchased credits are not affected.",
      grant_message_label: "Message for the recipient",
      grant_message_hint: "The supplier sees it in their panel next to the credits.",
      grant_message_placeholder: "e.g. Compensation for cancelled meetings. You can use the credits for any retailer in PreConnect.",
      grant_note_label: "Internal note",
      grant_note_hint: "Visible to administrators only.",
      grant_submit: "Grant credits",
      grant_submitting: "Granting\u2026",
      grant_cancel: "Cancel",
      grant_summary_format: "{{qty}} \xD7 {{count}} companies = {{total}} credits, valid until {{date}}",
      grant_toast_done_format: "Granted {{qty}} free credits to {{count}} companies, valid until {{date}}.",
      grant_toast_already: "This batch was already granted on {{date}}: {{qty}} credits for {{count}} companies \u2014 nothing was added.",
      grant_toast_error: "Could not grant credits.",
      pools_free_format: "free {{free}}",
      pools_paid_format: "purchased {{paid}}",
      status_labels: {
        pending_review: "Pending approval",
        active: "\u2713 Active",
        rejected: "Rejected",
        suspended: "Suspended"
      },
      review_labels: {
        pending: "Pending review",
        approved: "\u2713 Approved",
        edited: "Edited manually",
        rejected: "Rejected"
      },
      header_title: "Companies, statuses and package limits",
      filter_all_format: "All ({{count}})",
      filter_pending_label: "Pending approval",
      empty_pending: "No companies awaiting approval.",
      empty_all: "No companies in the system.",
      list_pkg_label: "Package:",
      list_valid_until_label: "Valid until:",
      list_preconnect_off: "\xB7 PreConnect off",
      list_fm_b2b: "\xB7 FM B2B",
      fm_b2b_packages_label: "Packages:",
      payment_date_label: "Payment date",
      payment_date_tooltip: "FM B2B priority date. Changes apply to the next calculation, not to the existing schedule.",
      payment_date_save: "Save payment date",
      payment_date_reset: "Discard date change",
      payment_date_saved: "Date saved.",
      payment_date_error: "The date could not be confirmed as saved. Check your connection and try again.",
      payment_date_conflict: "Another session changed the date. Current: {{date}}. Review your change before saving again.",
      fm_b2b_packages_hint_format: "= up to {{count}} meetings",
      toast_fm_b2b_tier_format: "{{name}}: FM B2B package tier \u2192 {{tier}}.",
      fm_b2b_tier_tooltip: "Event package tier. Premium wins ties in the meeting queue.",
      toast_fm_b2b_packages_format: "{{name}}: Business packages = {{count}} (pool of up to {{meetings}} B2B meetings).",
      list_used_unit: "submissions",
      status_section_title: "Status & access",
      status_approved_at_format: "\xB7 since {{date}}",
      status_note_placeholder: "Note for the supplier (reason for rejection/suspension, instructions on what to fix). Will appear in the email.",
      status_btn_approve: "\u2713 Approve account",
      status_btn_reject: "Reject",
      status_btn_suspend: "Suspend account",
      status_btn_reactivate: "Reactivate",
      access_preconnect_title: "PreConnect",
      access_preconnect_desc: "Submit proposals to retailers",
      access_fm_b2b_title: "B2B Meetings",
      access_fm_b2b_desc: "Fresh Market 2026",
      pkg_usage_label: "Credit usage",
      pkg_usage_value_format: "{{pct}}% ({{used}}/{{max}} credits)",
      pkg_limit_label: "CREDIT LIMIT",
      pkg_select_label: "PACKAGE",
      pkg_option_std_5: "Standard 5",
      pkg_option_std_10: "Standard 10",
      pkg_option_std_20: "Standard 20",
      pkg_option_prem_10: "Premium 10",
      pkg_option_prem_20: "Premium 20",
      pkg_save_btn: "Save package",
      pkg_saving_btn: "Saving...",
      pkg_unsaved_hint: 'Package or limit changed. Click "Save package" to save it in the database.',
      toast_pkg_saved_format: "Package saved: {{pkgLabel}}, limit {{limit}} submissions.",
      toast_pkg_invalid_limit: "Submission limit must be a number equal to or greater than 0.",
      toast_pkg_limit_below_used_format: "Limit cannot be lower than submissions already used ({{used}}).",
      toast_pkg_save_error: "Could not save the package.",
      ai_section_title: "AI description",
      ai_btn_preview: "Preview",
      ai_btn_edit: "Edit",
      ai_btn_generate: " Generate AI",
      ai_btn_generating: " Generating\u2026",
      ai_website_label: "Website (AI will read its content):",
      ai_website_placeholder: "e.g. https://freshworld.com.pl \u2014 enter and click Generate AI",
      ai_btn_approve: "Approve",
      ai_edit_short_label: "Short description",
      ai_edit_standard_label: "Standard description",
      ai_edit_cancel: "Cancel",
      ai_edit_save: "Save",
      ai_view_short_prefix: "Short:",
      ai_view_standard_prefix: "Standard:",
      ai_view_empty_html: "No descriptions. Click <em>\u201CGenerate AI\u201D</em> to create them.",
      sends_section_title_format: "Submissions ({{count}}):",
      sends_empty: "No submissions.",
      sends_row_fallback_offer: "Proposal",
      sends_row_fallback_retailer: "\u2014",
      toast_ai_no_name: "The company doesn't have a name yet \u2014 can't generate description.",
      toast_ai_generated_format: "AI generated descriptions for {{name}}. {{richness}}",
      toast_ai_richness_rich: "(extended profile)",
      toast_ai_richness_minimal: "(short profile)",
      toast_ai_richness_default: "",
      toast_ai_failed: "Failed to generate company description.",
      toast_ai_approved_format: "Company profile {{name}} approved.",
      toast_ai_approved_translated_format: "Company profile {{name}} approved + description translated to EN.",
      toast_ai_translated_format: "{{name}}: description translated to EN.",
      ai_btn_translate: " Translate to EN",
      toast_ai_saved_format: "Descriptions saved for {{name}}.",
      toast_status_changed_with_email_format: "Company status {{name}} \u2192 {{status}}. Email sent.",
      toast_status_changed_without_email_format: "Company status {{name}} \u2192 {{status}}. (Email was not sent \u2014 check configuration.)",
      toast_status_changed_format: "Company status {{name}} \u2192 {{status}}.",
      toast_flag_format: "{{flag}} {{state}} for {{name}}.",
      toast_flag_preconnect: "PreConnect",
      toast_flag_fm_b2b: "B2B Meetings",
      toast_flag_state_active: "enabled",
      toast_flag_state_inactive: "disabled",
      tabs: {
        active: "Active",
        pending: "Pending review",
        suspended: "Suspended",
        rejected: "Rejected",
        fm_b2b: "B2B FM26",
        all: "All"
      },
      tab_count_aria: "{{count}} companies",
      row: {
        contact_person_label: "Contact",
        account_operator_label: "Account operator",
        business_contact_label: "Company contact",
        no_contact_person: "\u2014",
        no_contact_email: "no email",
        no_contact_phone: "no phone",
        copy_email: "Copy email",
        copy_phone: "Copy phone",
        send_email: "Send email",
        open_details: "Details",
        open_chat_legacy: "Messages",
        open_chat_legacy_tooltip: "Go to the messages panel"
      },
      empty_active: "No active companies.",
      empty_suspended: "No suspended companies.",
      empty_rejected: "No rejected companies.",
      empty_fm_b2b: "No companies enabled for FM 2026 B2B meetings.",
      empty_filtered: "No companies found for these filters. Clear the filters or change the search term.",
      search_placeholder: "Search: name, person, email, phone, country, city\u2026",
      search_aria: "Search companies",
      results_count: "Results: {{shown}} of {{total}} companies",
      clear_filters: "Clear filters",
      filter_country_label: "Country",
      filter_country_all: "Country: all",
      filter_pkg_label: "Package",
      filter_pkg_all: "Package: all",
      filter_preconnect_label: "PreConnect",
      filter_preconnect_all: "PreConnect: all",
      filter_preconnect_on: "PreConnect: on",
      filter_preconnect_off: "PreConnect: off",
      filter_fm_b2b_label: "FM B2B",
      filter_fm_b2b_all: "FM B2B: all",
      filter_fm_b2b_on: "FM B2B: on",
      filter_fm_b2b_off: "FM B2B: off",
      filter_ai_label: "AI description",
      filter_ai_all: "AI description: all",
      toast_copied_email: "Email copied: {{email}}",
      toast_copied_phone: "Phone copied: {{phone}}",
      toast_copy_failed: "Couldn't copy to clipboard.",
      drawer: {
        tab_preview: "Overview",
        tab_chat: "Chat",
        tab_package: "Package",
        tab_history: "History",
        tab_notes: "Notes",
        close: "Close",
        prev_company: "Previous company",
        next_company: "Next company",
        chat_placeholder_title: "Chat with company \u2014 coming soon",
        chat_placeholder_body: "Chat in this panel will land in the next stage. For now use the \u201CMessages\u201D button in the list row \u2014 it opens the full messages panel.",
        placeholder_preview: "Company profile overview \u2014 content lands here in Commit 2.",
        placeholder_package: "Package and access (PreConnect / FM B2B) + AI editor \u2014 content lands here in Commit 2.",
        placeholder_history: "Submission history and status note \u2014 content lands here in Commit 2.",
        placeholder_notes: "Status note editor \u2014 content lands here in Commit 2.",
        footer_actions_placeholder: "Status actions (Approve / Reject / Suspend / Reactivate) land here in Commit 3.",
        notes_save: "Save note",
        notes_saved: "Note saved",
        notes_unsaved_confirm: "You have unsaved changes in the note. Close the details panel?",
        history_recent_sends: "Recent submissions",
        history_empty: "No submissions for this company.",
        history_approved_at_label: "Account approved:",
        history_status_note_label: "Status note:",
        history_limit_hint: "Showing the last 20 submissions.",
        package_plan_section: "Package and limits",
        package_access_section: "Access and visibility",
        package_limits_hint: "Plan and limits are read-only here.",
        notes_intro: "The status note is visible to the team and used when changing account status.",
        notes_placeholder: "Reason for rejection, activation comment or an internal note\u2026",
        footer_status_label: "Status:",
        footer_reject_reason_label: "Reason for rejection",
        footer_suspend_reason_label: "Reason for suspension",
        footer_reason_placeholder: "Provide a reason \u2014 it will be saved to the status note and included in the company notification\u2026",
        footer_confirm_reject: "Confirm rejection",
        footer_confirm_suspend: "Confirm suspension",
        footer_cancel: "Cancel"
      }
    },
    pipeline: {
      tab_mod_format: "Moderation ({{count}})",
      tab_track_format: "Submitted & Tracking ({{count}})",
      hint_pos_label: "Edit position (no. 1 = top for the buyer). Submission: ",
      send_approved_btn_format: "Submit approved ({{count}})",
      alert_pending_html_one: "<strong>{{count}}</strong> proposal awaiting moderation.",
      alert_pending_html_few: "<strong>{{count}}</strong> proposals awaiting moderation.",
      alert_pending_html_many: "<strong>{{count}}</strong> proposals awaiting moderation.",
      alert_pending_html_other: "<strong>{{count}}</strong> proposals awaiting moderation.",
      alert_empty_queues: "No proposals in the queues.",
      btn_show_tracking_format: "Show Submitted & Tracking ({{count}})",
      retailer_inactive_badge: "Inactive",
      retailer_proposals_count_format: "{{count}} proposals",
      retailer_pending_count_format: "\xB7 {{count}} pending moderation",
      retailer_slots_format: "{{count}}/10 slots",
      retailer_email_btn: "Email",
      send_pos_label: "pos.",
      send_prem_badge: "Prem.",
      send_status_pending: "Pending moderation",
      send_status_approved: "Approved",
      send_status_queued: "Queued",
      send_btn_approve: "Approve",
      send_btn_reject: "Reject",
      send_date_label: "Submission date:",
      send_date_default_hint: "default: 1st Tuesday of the month",
      history_modal_title_format: "History: {{product}}",
      history_empty: "No history.",
      history_action_confirm: "Confirmed",
      history_action_revert: "Reverted",
      track_alert_pending_html_one: "<strong>{{count}}</strong> proposal awaiting read confirmation (14 days).",
      track_alert_pending_html_few: "<strong>{{count}}</strong> proposals awaiting read confirmation (14 days).",
      track_alert_pending_html_many: "<strong>{{count}}</strong> proposals awaiting read confirmation (14 days).",
      track_alert_pending_html_other: "<strong>{{count}}</strong> proposals awaiting read confirmation (14 days).",
      track_alert_done: "All delivered proposals are confirmed.",
      credits_settle: {
        title: "PreConnect credits settlement",
        bought: "Bought",
        used: "Used",
        remaining: "Remaining",
        returned: "Returns",
        awaiting: "Awaiting read",
        hint: "A credit is finally consumed only after the buyer reads the proposal. \u201CReturns\u201D = credits kept due to no read within 14 days. \u201CAwaiting read\u201D = proposals in the buyer panel, not yet read. This is an operational view (credits), not financial.",
        show_per_company: "Show per company ({{count}})",
        hide_per_company: "Hide breakdown",
        col_company: "Company"
      },
      settle_card_title: "Supplier settlements (revenue EUR)",
      settle_settled_label: "Settled (items)",
      settle_settled_amount_format: "revenue: {{amount}} EUR",
      settle_waiting_label: "Waiting (items)",
      settle_waiting_desc: "submitted, but not yet seen / no package",
      settle_empty: "No submitted proposals to settle.",
      settle_supplier_fallback: "Supplier",
      settle_offer_fallback: "Proposal",
      settle_retailer_fallback: "Retailer",
      settle_badge_settled_count_format: "{{count}} settled",
      settle_badge_waiting_count_format: "{{count}} waiting",
      settle_row_charged_badge_format: "Settled {{amount}} EUR",
      settle_row_no_package: "No package",
      settle_row_waiting: "Waiting",
      settle_more_format: "+{{count}} more",
      track_tracking_label: "14-day tracking",
      track_days_left_format: "{{count}} days left",
      track_badge_email_opened: "Email opened",
      track_badge_auto_app: "List/app",
      track_badge_manual: "Manual",
      track_badge_unread: "Unread",
      track_badge_settled: "Settled",
      track_confirm_undo_btn: "Undo",
      track_confirmed_email: "The buyer opened the batch email with proposals",
      track_confirmed_auto: "The buyer saw the proposal in PreConnect",
      track_manual_phone: "Phone",
      track_manual_email: "Email",
      track_manual_meeting: "Meeting",
      track_settlement_inline_format: "Settlement: {{amount}} EUR",
      confirm_form_label: "Manual contact with the buyer:",
      confirm_form_type_phone: "Phone",
      confirm_form_type_email: "Email",
      confirm_form_type_meeting: "Meeting",
      confirm_form_note_label: "Note",
      confirm_form_save_btn: "Save confirmation",
      confirm_form_toast_saved: "Confirmation saved.",
      table: {
        search_placeholder: "Search: retailer, supplier, product\u2026",
        search_aria: "Search proposals",
        results_count: "Results: {{shown}} of {{total}} proposals",
        clear_filters: "Clear filters",
        export_csv: "Export CSV",
        page_size_label: "Per page:",
        page_prev: "Previous",
        page_next: "Next",
        page_status_format: "{{from}}\u2013{{to}} of {{total}}",
        empty_filtered: "No proposals for the selected filters. Clear the filters or change the criteria.",
        empty_all: "No proposals in the system.",
        mode_moderation: "To moderate",
        mode_tracking: "Sent / mailing",
        mod_hint: "Step 1: approve or reject proposals (eye = preview). Step 2: send approved ones to the buyer panel with the button next to it.",
        mod_empty_hint: "No proposals to moderate. New supplier submissions will appear here.",
        col_mod_status: "Status",
        mod_status_pending: "To moderate",
        mod_status_queued: "Queued",
        mod_status_approved: "Ready for panel",
        mod_approve: "Approve",
        mod_reject: "Reject",
        mod_send_approved: "Send approved to buyer panel ({{count}})",
        mod_approved_ready_format: 'You have {{count}} approved proposals (status "Ready for panel"). They are approved \u2014 Step 2: send them to the buyer panel with the button.',
        mod_step2: "Step 2",
        mod_empty_table: "No proposals to moderate.",
        summary_all: "All",
        summary_in_panel: "In panel",
        summary_no_email: "No email",
        summary_unread: "Unread",
        summary_waiting: "Awaiting settlement",
        summary_in_basket: "In email basket",
        next_mailing_label: "Next email send:",
        basket_groups_title: "Mailing basket \u2014 by retailer",
        basket_group_counts: "{{panel}} in panel \xB7 {{basket}} in basket \xB7 {{emailed}} sent",
        basket_send_email: "Send email to this retailer",
        basket_empty_hint: "No proposals selected for email. You can check them in the Pipeline table.",
        basket_manual_hint: "Sending is manual \u2014 the system only shows the next mailing date, it does not send automatically.",
        col_basket: "Email basket",
        basket_checkbox_aria: "Add to email basket",
        basket_not_eligible: "Not available \u2014 the proposal is not in the buyer panel or the email was already sent.",
        col_date: "Date",
        col_retailer: "Retailer",
        col_supplier: "Supplier",
        col_product: "Product",
        col_panel: "Buyer panel",
        col_email: "Email",
        col_read: "Read",
        col_settlement: "Settlement",
        col_actions: "Actions",
        panel_yes: "In panel",
        panel_no: "\u2014",
        email_sent: "Sent",
        email_not_sent: "Not sent",
        read_read: "Read",
        read_unread: "Unread",
        read_expired: "Expired",
        read_na: "\u2014",
        settle_charged: "Settled",
        settle_waiting: "Waiting",
        settle_refunded: "Refunded",
        settle_na: "\u2014",
        action_preview: "Preview offer",
        filter_panel_label: "Panel",
        filter_panel_all: "Panel: all",
        filter_panel_in: "In buyer panel",
        filter_panel_out: "Outside panel",
        filter_email_label: "Email",
        filter_email_all: "Email: all",
        filter_email_sent: "Email: sent",
        filter_email_unsent: "Email: not sent",
        filter_read_label: "Read",
        filter_read_all: "Read: all",
        filter_read_read: "Read: read",
        filter_read_unread: "Read: unread",
        filter_settle_label: "Settlement",
        filter_settle_all: "Settlement: all",
        filter_settle_charged: "Settlement: settled",
        filter_settle_waiting: "Settlement: waiting",
        filter_retailer_all: "Retailer: all",
        filter_supplier_all: "Supplier: all",
        filter_date_from: "Date from",
        filter_date_to: "Date to",
        mod_ai_btn: "ChatGPT",
        mod_message_btn: "Message",
        ai_modal_title: "ChatGPT proposal analysis",
        ai_modal_subtitle_format: "{{product}} \xB7 {{supplier}}",
        ai_loading: "Analysing the proposal...",
        ai_empty: "No saved analysis. Click \u201CAnalyse again\u201D.",
        ai_run: "Analyse again",
        ai_saved: "AI analysis saved on the proposal.",
        ai_offer_missing_error: "No proposal to analyse.",
        ai_error_format: "Could not run the AI analysis: {{message}}",
        ai_score_format: "Completeness score: {{score}}/5",
        ai_section_missing: "Worth completing",
        ai_section_suggestions: "Suggestions for admin",
        ai_section_strengths: "Strong points",
        ai_message_draft_label: "Suggested message to supplier",
        ai_use_message: "Use as message",
        message_modal_title: "Message to supplier",
        message_modal_desc_format: "Notes for proposal: {{product}}",
        message_text_label: "Message text",
        message_send: "Send message",
        message_sending: "Sending...",
        message_sent: "Message sent to the supplier.",
        message_empty_error: "Enter the message text.",
        message_supplier_missing_error: "I cannot identify the supplier for this proposal.",
        message_prefill_empty: "Hello,\n\nPlease complete the proposal \u201C{{product}}\u201D with the missing information so we can review it more smoothly and show it to buyers.\n\nBest regards"
      },
      full_preview: {
        modal_title: "Full proposal preview \u2013 moderation",
        notice: "These are the full supplier form details. The buyer sees a shorter, organized view.",
        section_internal: "Internal data",
        section_identification: "Product identification",
        section_quality: "Quality and specification",
        section_availability: "Availability and volume",
        section_packaging: "Packaging and palletization",
        section_logistics: "Logistics",
        section_certs: "Certificates and traceability",
        section_commercial: "Commercial terms",
        section_benefits: "Buyer benefits",
        section_risk: "Risk mitigation",
        section_photos: "Product photos",
        section_supplier: "Supplier and contacts",
        internal_title: "Internal title",
        buyer_title: "Buyer title",
        status: "Status",
        tier: "Package",
        product: "Product",
        variety: "Variety",
        category: "Category",
        subcategory: "Subcategory",
        origin: "Origin country",
        region: "Region",
        offer_type: "Proposal type",
        positioning: "Positioning",
        size: "Size / calibre",
        quality_class: "Quality class",
        brand: "Brand",
        sale_mode: "Sales model",
        bio: "Organic",
        brix: "Brix",
        color_spec: "Color",
        quality_spec: "Quality specification",
        stem_length: "Stem length",
        opening_phase: "Opening phase",
        bouquet_count: "Bouquet count",
        vase_life: "Vase life",
        flower_color: "Flower color",
        from: "From",
        to: "To",
        availability_model: "Availability model",
        volume: "Volume",
        volume_min: "Min. volume",
        volume_max: "Max. volume",
        moq: "Minimum order",
        lead_time: "Lead time",
        promo_volume: "Promo volume",
        delivery_days: "Delivery days",
        packaging_desc: "Packaging description",
        net_weight: "Net weight",
        units_per_carton: "Units per carton",
        ean: "EAN",
        pallet_type: "Pallet type",
        pallet_height: "Pallet height",
        cartons_per_layer: "Cartons per layer",
        layers_per_pallet: "Layers per pallet",
        units_per_pallet: "Units per pallet",
        srp: "SRP / shelf-ready",
        delivery_model: "Delivery model",
        loading_point: "Loading point",
        delivery_regions: "Delivery regions",
        cold_chain: "Cold chain",
        temp_transport: "Transport temperature",
        traceability: "Traceability",
        cert_number: "Certificate number",
        cert_valid: "Valid until",
        current_tests: "Current tests",
        price_offer: "Offer price",
        incoterm: "Incoterm",
        price_window: "Price window",
        promo_price: "Promo price",
        contract_program: "Contract program",
        samples: "Samples",
        benefit1: "Benefit 1",
        benefit2: "Benefit 2",
        benefit3: "Benefit 3",
        shop_benefit: "Store benefit",
        description: "Description",
        risk_mitigation: "How the supplier mitigates risk",
        risk_proof: "Proof / safeguards",
        risk_now: "What to verify now",
        photo_main: "Main photo",
        photo_item_format: "Photo {{n}}",
        photos_empty: "No photos in this proposal.",
        yes: "Yes",
        no: "No"
      },
      email_modal_title_format: "Email for {{name}}",
      email_modal_title_fallback: "Email for the retailer",
      email_buyer_line_one_format: "This message will go to 1 buyer at {{name}} and contains {{offers}}.",
      email_buyer_line_many_format: "This message will go to {{buyers}} buyers at {{name}} and contains {{offers}}.",
      email_offers_one_format: "{{count}} proposal",
      email_offers_few_format: "{{count}} proposals",
      email_offers_many_format: "{{count}} proposals",
      email_subject_format: "Fresh Market PreConnect \u2013 supplier submissions for {{retailer}} ({{summary}})",
      email_subject_offers_one_format: "{{count}} submission",
      email_subject_offers_few_format: "{{count}} submissions",
      email_subject_offers_many_format: "{{count}} submissions",
      email_no_offers_skipped_html: "No proposals ready for email for this retailer. {{skipped}} items are in another status (moderation / rejected / email already sent).",
      email_no_offers_empty: "This retailer has no proposals in the queue.",
      email_no_buyers_html: "Retailer <strong>{{name}}</strong> has no active buyer with email. First add a buyer in \u201CRetailers\u201D \u2192 choose this retailer \u2192 \u201CBuyers\u201D.",
      email_btn_close: "Close",
      email_btn_cancel: "Cancel",
      email_btn_sent: "\u2713 Sent",
      email_btn_sending: "Sending\u2026",
      email_btn_send_format: "Send ({{count}})",
      email_hdr_from: "From",
      email_hdr_to: "To",
      email_hdr_subject: "Subject",
      email_select_title: "Choose proposals for this email",
      email_select_hint: "You can deliver all proposals to the buyer panel and show only selected ones in the email.",
      email_select_all: "Select all",
      email_select_none: "Clear",
      email_select_panel_badge: "in panel",
      email_select_approved_badge: "approved",
      email_select_empty_warning: "Select at least one proposal to send the email.",
      email_skipped_format_one: "Skipped {{count}} proposal (rejected, in moderation, already read, or email already sent).",
      email_skipped_format_few: "Skipped {{count}} proposals (rejected, in moderation, already read, or email already sent).",
      email_skipped_format_many: "Skipped {{count}} proposals (rejected, in moderation, already read, or email already sent).",
      email_skipped_format_other: "Skipped {{count}} proposals (rejected, in moderation, already read, or email already sent).",
      email_pending_card_title: "Proposals in panel without email",
      email_pending_card_desc: "The buyer can already see these proposals in their panel. You can now send a separate email with selected items.",
      email_pending_count_format: "{{count}} proposals ready for email",
      toast_send_failed_default: "Sending failed.",
      toast_send_unknown_error: "Failed to send email.",
      toast_send_partial_format: "Sent to {{succeeded}}/{{total}} buyers \xB7 {{count}} proposals marked as sent. {{failed}} buyer(s) failed.",
      toast_send_success_format: "Sent! {{buyers}} buyer(s) \xB7 {{count}} proposals marked as sent.",
      delivery_refresh_failed: "Delivery was recorded. The list could not be refreshed \u2014 reload the page, do not resend."
    },
    branding: {
      page_title: "Branding",
      page_desc: "Fresh Market logo shown in sidebars, panel headers, and on login and registration pages.",
      current_label: "Current logo",
      loading: "Loading...",
      current_dark_alt: "Current logo",
      current_light_alt: "Current logo (light background)",
      current_hint: "We render the logo both on dark (admin/supplier/buyer sidebar) and light backgrounds (panel topbar, /login). If only one of the two looks right \u2014 consider using a version with a transparent background (PNG/SVG).",
      no_logo_warning: "\u26A0 No logo in the database. We're currently using the fallback SVG (green apple) \u2014 upload a logo below to replace it.",
      upload_section_label: "Upload new logo",
      upload_desc_format_html: "<strong>Format:</strong> PNG, JPG, SVG, WEBP \u2014 max. 1 MB.<br/><strong>Recommended:</strong> transparent background (PNG/SVG), height \u2265 64 px, horizontal or square format.<br/><strong>File name:</strong> if it contains the word <code>wordmark</code>, we won't add the \u201CFresh Market\u201D text next to the logo (the logo already contains the name).",
      preview_label: "Preview",
      preview_dark_alt: "Preview on dark background",
      preview_light_alt: "Preview on light background",
      file_meta_format: "{{name}} \u2014 {{kb}} KB",
      save_btn: "Save logo",
      saving: "Saving...",
      cancel_btn: "Cancel",
      info_box_html: "<strong>\u{1F4A1} Where will I see the changes?</strong><br/>\u2022 Sidebar (left panel) \u2014 branding section at the top<br/>\u2022 Panel header (PanelTopBar) \u2014 admin, supplier, buyer<br/>\u2022 Pages /login, /rejestracja-dostawcy, /zakup-ok<br/>\u2022 Chat (bottom right corner)<br/><br/>After upload refresh the page (F5) \u2014 we attach the new URL once per load.",
      toast_invalid_format: "Disallowed format. Use PNG, JPG, SVG or WEBP.",
      toast_too_large: "File too large. Max. 1 MB.",
      toast_upload_error_format: "\u274C Upload error: {{error}}",
      toast_upload_error_unknown: "unknown",
      toast_upload_success: "\u2713 Logo saved. Refresh the page (F5) to see it in the sidebar and headers.",
      toast_upload_exception_format: "\u274C Exception: {{message}}",
      ui_instructions_title: "Instructions (menu link)",
      ui_instructions_desc: "Content shown as \u201CInstructions\u201D in the left menu \u2014 separately for supplier and buyer, in two languages. Simple HTML allowed.",
      ui_announce_title: "Announcements (bar / modal)",
      ui_announce_desc: "Short notice at the top of the panel \u2014 separately for supplier and buyer, in two languages.",
      ui_role_supplier: "Supplier",
      ui_role_buyer: "Buyer",
      ui_field_pl: "Content PL",
      ui_field_en: "Content EN",
      ui_announce_enabled: "Show announcement",
      ui_announce_type: "Type",
      ui_announce_type_bar: "Top bar",
      ui_announce_type_modal: "Modal on entry (urgent) + bar",
      ui_announce_date_from: "Date from (optional)",
      ui_announce_date_to: "Date to (optional)",
      ui_preview_title: "Preview",
      ui_preview_role: "Role",
      ui_preview_lang: "Language",
      ui_preview_lang_pl: "PL",
      ui_preview_lang_en: "EN",
      ui_preview_ticker_label: "Top bar:",
      ui_preview_instr_label: "Instructions (page):",
      ui_preview_empty: "(no content for this combination)",
      ui_save_btn: "Save content",
      ui_saving: "Saving...",
      partners_title: "Sponsors",
      partners_desc: "Sponsor logos shown in the footer of the buyer and supplier panel \u2014 on every screen. Order in the list = order in the strip.",
      partners_empty: "No sponsors yet. Add the first logo below.",
      partners_field_name: "Name",
      partners_field_url: "Website (optional)",
      partners_field_enabled: "Visible in footer",
      partners_add_btn: "Add sponsor logo",
      partners_uploading: "Uploading...",
      partners_file_hint: "PNG (transparent background preferred), SVG, JPG or WebP \xB7 max 1 MB \xB7 recommended height at least 120 px",
      partners_preview_label: "Footer preview \u2014 this is what buyers and suppliers see",
      partners_strip_label: "Fresh Market 2026 Sponsors",
      partners_move_up: "Move up",
      partners_move_down: "Move down",
      partners_remove: "Remove sponsor",
      partners_toast_added: 'Logo uploaded. Click "Save content" to publish.',
      ui_toast_saved: "\u2713 Content saved. Users will see it after refreshing the page.",
      ui_toast_error_format: "\u274C Save error: {{error}}",
      ui_html_hint: "Simple HTML allowed: <b>, <i>, <br>, <ul><li>, <a href>."
    },
    team: {
      gating_title: "\u26D4 Access denied",
      gating_desc: "The \u201CAdministrators\u201D section is available only to the super administrator. You're logged in as a regular administrator \u2014 you have access to all other features, but team management requires super-admin privileges.",
      page_title: "Administrators",
      page_desc: "Manage the Fresh Market B2B administrator team. Only you (super admin) can change permissions.",
      promote_section_title: "Promote a user to administrator",
      promote_section_desc_html: "Enter the email of a user who <strong>already exists in the system</strong> (registered through the supplier registration page or added as a buyer). After promotion they will get access to all administrator features \u2014 proposal moderation, retailer and company management, FM 2026 panel, branding.",
      email_placeholder: "email@company.com",
      promote_btn: "Promote to administrator",
      promoting: "Promoting...",
      list_section_title_format: "Administrator list ({{count}})",
      loading: "Loading...",
      list_empty: "No administrators. That's odd \u2014 you should be on this list.",
      me_label: "(it's you)",
      super_admin_badge: "\u2B50 SUPER ADMIN",
      super_admin_title: "Super admin can manage the team",
      admin_badge: "ADMIN",
      toggle_super_title_demote: "Revoke super admin privileges (becomes a regular admin)",
      toggle_super_title_promote: "Promote to super admin",
      toggle_super_btn_demote: "Demote super",
      toggle_super_btn_promote: "Promote to super",
      remove_btn_title: "Revoke administrator privileges entirely",
      remove_btn: "Remove",
      info_box_title: "\u{1F4A1} Tips:",
      info_box_item1_html: "<strong>Super admin</strong> \u2014 full access + can manage the team (you)",
      info_box_item2_html: "<strong>Regular admin</strong> \u2014 full access to moderation, retailers, companies, FM, branding, but does NOT see this tab",
      info_box_item3_html: "To promote a new admin, the user must <strong>first create an account</strong> (e.g. through supplier registration)",
      info_box_item4: "You can't revoke your own privileges (safeguard against locking yourself out of the system)",
      confirm_modal_title: "Remove administrator privileges?",
      confirm_modal_desc_html: "Are you sure you want to revoke administrator privileges from user <strong>{{name}}</strong>?<br/><br/>The account remains active but loses access to the administrator panel (moderation, retailers, companies, FM, branding).<br/><br/>You can later promote this user back to administrator.",
      confirm_btn_cancel: "Cancel",
      confirm_btn_delete: "Yes, remove",
      removing: "Removing...",
      toast_email_required: "Enter user's email.",
      toast_error_prefix: "\u274C ",
      toast_promoted_success_format: "\u2713 {{email}} received administrator privileges.",
      toast_super_demoted_format: "\u2713 {{email}} is now a regular administrator.",
      toast_super_promoted_format: "\u2713 {{email}} is now a super administrator.",
      toast_removed_success_format: "\u2713 {{email}} lost administrator privileges."
    }
  },
  fm: {
    meeting_note_label: "FM meeting arrangements",
    default_chance: {
      badge: "\u{1F91D} Give a chance \u2014 automatic",
      notice: "For a supplier who selected the retailer, no response automatically means \u201CGive a chance\u201D. Acceptances have priority for both allocation and queue numbers; explicit and automatic chances are equal and follow accepted meetings. Rejections are excluded. Package and station capacity limits still apply.",
      saved_plan: "A saved plan does not change automatically. Recalculate, review and approve the plan to apply the new rule.",
      unknown: "Needs review \u2014 unknown status",
      inputs_loading: "Loading the complete supplier choices and retailer responses. Plan calculation and approval are temporarily blocked.",
      inputs_error: "Could not load all supplier choices or retailer responses. A read error does NOT mean \u201CGive a chance\u201D. Plan calculation and approval are blocked. Refresh the page and try again."
    },
    decision_source: {
      admin_badge: "Selected by the administrator",
      admin_tooltip: "This choice was set by the administrator on your behalf. You can change it \u2014 the marker will then disappear.",
      admin_meta: "Set by administrator {{who}} \xB7 {{when}}",
      unknown_author: "(server session, no identifier)",
      admin_badge_target: "Retailer choice: set by the administrator",
      admin_badge_resp: "Buyer decision: set by the administrator"
    },
    event_date: "24 September 2026",
    phases: {
      "1": {
        label: "Registration",
        sub: "Retailers confirm participation in FM 2026",
        dates: "September 2026"
      },
      "2": {
        label: "Preferences",
        sub: "Suppliers and buyers choose partners (until September 16)",
        dates: "September 1\u201316"
      },
      "3": {
        label: "Algorithm + Corrections",
        sub: "Admin runs the algorithm and adjusts the plan (September 17\u201321)",
        dates: "September 17\u201321"
      },
      "4": {
        label: "Publication and event",
        sub: "Final list September 22 \xB7 Event September 24",
        dates: "September 22\u201324"
      }
    },
    venue_footer_brand: "Fresh Market 2026",
    lock_screen: {
      processing_title: "Generating the meeting plan",
      contact_html: "Questions? Contact: <strong>Oksana Koz\u0142owska</strong> \xB7 oksana@freshmarket.eu \xB7 +48 509 086 949",
      default_title: "B2B Meetings \u2014 Fresh Market 2026",
      default_desc_html: "Planning B2B meetings with retailer buyers at the <strong>Fresh Market 2026</strong> trade show.<br/>Partner selection: <strong>until September 16</strong>. Plan publication: <strong>September 22</strong>. Event: <strong>September 24</strong>.",
      open_date_format: "Planned opening: {{date}}",
      open_date_fallback: "September 1, 2026",
      schedule_hint: "Selection until September 16 \xB7 Publication September 22 \xB7 Event September 24",
      feature_select_emoji: "\u2B50",
      feature_select_title: "Choose retailers",
      feature_select_desc: "Mark preferred retailers and backups",
      feature_algo_emoji: "\u{1F916}",
      feature_algo_title: "Algorithm",
      feature_algo_desc: "Intelligent meeting assignment",
      feature_plan_emoji: "\u{1F4CB}",
      feature_plan_title: "Meeting plan",
      feature_plan_desc: "Your meeting numbers for event day"
    },
    retailer_preview: {
      modal_title: "Retailer preview",
      initials_fallback: "??",
      categories_label: "Categories",
      no_contact_data: "Buyer contact data is not available in this view."
    },
    supplier: {
      sched_intro_readonly_html: "<strong>Selection closed \u2014 September 16.</strong> Your preferences have been saved. The administrator is now arranging the meeting plan. Final numbers will be published on <strong>September 22</strong>. For changes contact the administrator via Chat.",
      sched_intro_open_html: "<strong>Stage: until September 16, 2026</strong><br/>Pick the retailers you want to meet with. You can change selections until close. After that date selections are irreversible \u2014 if you want to change anything, contact the administrator via Chat.",
      stats_stars_format: "{{count}}/{{max}}",
      stats_stars_label: "\u2B50 Priority retailers",
      stats_thumbs_count_format: "{{count}}",
      stats_thumbs_label: "\u{1F44D} Backups",
      stats_status_ready: "Ready \u2713",
      stats_status_pending: "\u23F3 Choose {{min}} retailers",
      stats_status_min_reached: "Minimum \u2713",
      stats_status_label: "Status",
      stats_status_label_more: "you can add {{count}} more \u2B50",
      ready_alert_html: "Ready! {{max}} priority retailers selected. You can still add backups. Selections can be changed until <strong>September 16, 2026</strong> (11:59 PM).",
      min_reached_alert_html: "<strong>Minimum reached</strong> \u2014 {{min}} priority retailers selected, you can confirm now. Your packages ({{packages}} \xD7 Business) allow up to <strong>{{max}}</strong> priority retailers in total \u2014 add <strong>{{count}}</strong> more \u2B50 if you wish. Backups are unlimited. Selections can be changed until <strong>September 16, 2026</strong> (11:59 PM).",
      confirm_confirmed_title: "Selection confirmed",
      confirm_confirmed_meta_html: "Saved: <strong>{{date}}</strong>. You can still change selections until September 16 \u2014 click <em>Confirm selection</em> again after changes so the admin sees the current decision.",
      confirm_ready_title: "Ready \u2014 click Confirm selection",
      targets_save_failed: "Your latest changes to the retailer selection could not be saved ({{message}}). Refresh the page and check the list before confirming.",
      confirm_ready_more_title: "You can confirm \u2014 or add {{count}} more \u2B50",
      confirm_not_ready_title: "First choose {{min}} priority retailers",
      confirm_unconfirmed_meta_html: "Your selections are saved on the fly, but only clicking <em>Confirm selection</em> tells the administrator your choice is final.",
      confirm_btn_initial: "Confirm selection",
      confirm_btn_again: "Confirm again",
      chains_card_title_readonly: "Your retailer selections (read-only)",
      chains_card_title_editable: "Choose retailers",
      chain_badge_main: "PRIORITY",
      chain_badge_backup: "BACKUP",
      chains_hint: "Click once \u2192 \u2B50 priority (min. {{min}}, max {{max}} from your packages) \xB7 click again \u2192 \u{1F44D} backup \xB7 click again \u2192 remove",
      algo_lock_message: "Selections were closed on September 16. The meeting plan is being prepared and adjusted by the administrator. Final numbers will be published on September 22. If you want to report something, contact the administrator via Chat.",
      algo_warning_title: "Working preview \u2014 the plan may still change",
      algo_warning_desc_html: "The administrator shared a preliminary preview of planned meetings. <strong>This is not the final plan.</strong> Official publication will happen on <strong>September 22, 2026</strong>.",
      algo_card_title: "Preliminary preview of planned meetings",
      algo_card_desc: "The algorithm planned meetings with the retailers below. Working plan \u2014 may change before publication on September 22.",
      algo_empty: "No meetings assigned in the working plan.",
      zone_green: "\u{1F7E2} Good",
      zone_orange: "\u{1F7E0} Medium",
      zone_red: "\u{1F534} Late",
      wyniki_lock_emoji: "\u23F3",
      wyniki_lock_title: "Plan being finalized",
      wyniki_lock_desc_html: "The administrator is preparing the final meeting plan.<br/>It will be published on <strong>September 22, 2026</strong>. That day you'll see your meeting numbers.<br/><br/>Questions? Contact: <strong>Oksana Koz\u0142owska</strong><br/>oksana@freshmarket.eu \xB7 +48 509 086 949",
      wyniki_hero_event_title: "Fresh Market 2026",
      wyniki_hero_meta_format: "{{date}} \xB7 {{venue}}",
      wyniki_hero_badge: "\u25CF Final plan published",
      wyniki_card_title: "Your meeting schedule \u2014 final",
      wyniki_empty: "No scheduled meetings.",
      wyniki_meeting_sub_format: "{{country}} \xB7 Meeting no. {{num}}",
      wyniki_preview_btn: "Preview",
      wyniki_check_badge: "\u2713",
      wyniki_info_label: "How meeting calls work on event day",
      wyniki_info_item1_html: "<strong>Meeting numbers</strong> above indicate the order in which you'll be called \u2014 not fixed times.",
      wyniki_info_item2_html: "Current calls will be visible on the <strong>big screen</strong> in the middle of the hall and <strong>in the app</strong> (here, in live mode).",
      wyniki_info_item3_html: "When you see your number, go to the B2B desk at <strong>Gate 1</strong> or <strong>Gate 2</strong> (at the back of the hall).",
      wyniki_info_item4_html: "A Fresh Market assistant will <strong>walk you</strong> to your meeting with the retailer.",
      wyniki_info_item5: "After your meeting, return to watching the queue \u2014 your next number may be called soon.",
      wyniki_ready_warning_html: "<strong>Be ready.</strong> On event day calls come quickly \u2014 prepare materials and samples for all {{count}} retailers before the start."
    },
    buyer: {
      phase_banner_label_format: "\xB7 Buyer panel: ",
      remove_dialog_title_html: "Skip the meeting with <strong>{{name}}</strong>?",
      remove_dialog_desc: "We can move this company to the back of the queue \u2014 if there's time, the meeting will happen.",
      remove_dialog_btn_chance_html: "\u{1F501} Move to back of queue <span>(recommended)</span>",
      remove_dialog_btn_remove: "I don't want a meeting with this company",
      remove_dialog_btn_cancel: "Cancel",
      remove_confirm_title: "\u26A0\uFE0F Confirm rejection",
      remove_confirm_desc_html: "You'll mark company <strong>{{name}}</strong> as <strong>NO MEETING</strong>. The algorithm won't add this pair to your plan. The admin can still add the meeting manually after an explicit warning.",
      remove_confirm_btn_yes: "Yes, no meeting",
      remove_confirm_btn_cancel: "Cancel",
      stats_picked_label: "Picked your retailer",
      stats_want_label: "\u2705 Want to meet",
      stats_chance_label: "\u{1F91D} Give a chance",
      card_interested_title: "Suppliers who picked your retailer",
      card_interested_desc: "These companies selected your retailer. Accepted meetings have priority. \u201CGive a chance\u201D and no response provide the same chance of a meeting, with a queue number after accepted meetings. \u201CNot interested\u201D excludes the meeting. You do not need to click \u201CGive a chance\u201D for every remaining company; capacity and package limits still apply.",
      card_interested_empty_html: "No suppliers awaiting a decision.<br/><span>When suppliers select your retailer in \u201CChoose retailers\u201D, they'll appear here.</span>",
      pref_main: "\u2B50 Priority",
      pref_backup: "\u{1F44D} Backup",
      preview_btn: "Preview",
      btn_want: "\u2705 Want",
      btn_chance: "\u{1F91D} Give a chance",
      btn_remove: "\u274C Don't want",
      resp_want_full: "\u2705 Want to meet",
      resp_chance_full: "\u{1F91D} Give a chance",
      resp_remove_full: "\u274C Don't want",
      phase3_status_title: "Selections closed \u2014 plan in preparation",
      phase3_status_desc_html: "Selections were closed on <strong>September 16</strong>. The administrator is arranging and adjusting the meeting plan.<br/>Final numbers and meeting schedule will be published on <strong>September 22, 2026</strong>.<br/>For changes or questions, contact the administrator via <strong>Chat \u2198</strong>.",
      phase3_preview_warning_title: "Working preview \u2014 the plan may still change",
      phase3_preview_warning_desc_html: "The administrator shared a preliminary preview of planned meetings. <strong>This is not the final plan.</strong> Official publication will happen on <strong>September 22, 2026</strong>.",
      phase3_preview_card_title: "Preliminary preview \u2014 planned meetings with your retailer",
      phase3_preview_empty: "No planned meetings for this retailer in the working plan.",
      phase3_responses_card_title: "Selections and responses from the Preferences phase \u2014 read-only",
      phase3_responses_card_desc: "Below you see saved responses and automatic \u201CGive a chance\u201D for suppliers who selected your retailer and have not received a response. An automatic chance is not buyer approval. These are matching inputs, not the list of assigned meetings. Only the administrator can edit them.",
      phase3_responses_empty_no_data: "No supplier data.",
      phase3_responses_empty_no_marks: "No marked responses in the Preferences phase.",
      phase3_late_warning_title: "Late selection \u2014 only information for the administrator",
      phase3_late_warning_desc_html: "Your responses <strong>no longer participate in the algorithm</strong> and do not automatically change the meeting plan. They serve only as support material for the administrator.",
      phase3_late_card_title: "Supplier selection \u2014 after deadline (info for admin)",
      phase3_late_card_desc: "Mark suppliers you'd like to meet with. The administrator will decide if it's possible.",
      final_card_title_published: "1. Companies you're meeting with \u2014 final plan",
      final_card_title_working: "1. Companies you're meeting with \u2014 working plan",
      final_pending_info: "The plan is being finalized by the administrator. Final list will be published on September 22.",
      final_empty: "No assigned companies.",
      final_badge_final: "\u2713 Final",
      wish_card_title: "2. Companies you'd still like to meet with",
      wish_card_desc: "Mark additional companies \u2014 info for the administrator. Doesn't automatically change the plan.",
      wish_card_desc_admin_note: " The administrator may take these wishes into account.",
      wish_btn_added: "\u2705 Reported",
      wish_btn_add: "+ Want",
      wish_summary_one: "1 additional company reported to the administrator. Oksana Koz\u0142owska will make manual corrections if possible.",
      wish_summary_few: "{{count}} additional companies reported to the administrator. Oksana Koz\u0142owska will make manual corrections if possible.",
      wish_summary_many: "{{count}} additional companies reported to the administrator. Oksana Koz\u0142owska will make manual corrections if possible.",
      wish_summary_other: "{{count}} additional companies reported to the administrator. Oksana Koz\u0142owska will make manual corrections if possible.",
      pub_contact_html: "For changes contact: <strong>Oksana Koz\u0142owska</strong> \xB7 oksana@freshmarket.eu \xB7 +48 509 086 949",
      footer_extra: "Your booth \u2014 you'll find out at event reception.\nRegistration starts: 8:00\u20139:00 AM."
    },
    admin: {
      tab_management: "\u2699\uFE0F Management",
      tab_data: "\u{1F4CB} Input data",
      tab_plan: "\u26A1 Meeting plan",
      tab_corrections: "\u270F\uFE0F Corrections",
      access_card_title: "Participant access",
      access_badge_open: "OPEN",
      access_badge_closed: "CLOSED",
      access_open_date_label: "Planned opening date",
      access_btn_open: "Open access",
      access_btn_close: "Close",
      access_info_html: "\u201CFM 2026 Meetings\u201D tab visible in sidebar <strong>at all times</strong>. When closed \u2014 participants see a lock screen with the opening date.",
      publish_card_title: "Final plan publication",
      publish_badge_published: "PUBLISHED",
      publish_badge_unpublished: "NOT PUBLISHED",
      publish_desc_published: "Final plan published. Suppliers and buyers see their meetings with queue numbers.",
      publish_desc_unpublished: "After publishing, suppliers and buyers will see Your meetings tab with final numbers. This operation is irreversible.",
      publish_btn_publish: "Publish final plan",
      publish_btn_revert: "Revert publication",
      publish_warning: "Before publishing make sure the meeting plan is approved. After publishing, suppliers and buyers will immediately see the final meeting numbers.",
      phases_card_title: "Fresh Market 2026 organizational phases",
      phases_card_desc: "Click a phase to activate it. The active phase unlocks the corresponding features for suppliers and retailers.",
      phase_active_badge: "\u25CF ACTIVE",
      phase_done_badge: "Completed",
      data_empty_no_input: "Input data is not yet complete \u2014 no suppliers or retailers.",
      data_stat_suppliers_ready_label: "Suppliers ready",
      data_stat_confirmed_label: "\u2713 Confirmed",
      data_stat_not_picked_label: "Didn't pick",
      data_stat_chains_resp_label: "Retailers resp.",
      data_stat_readiness_label: "Readiness",
      data_warning_low_readiness_format: "Only {{ready}}/{{total}} suppliers filled in preferences ({{pct}}%). Consider waiting to run the algorithm.",
      data_warning_unconfirmed_one_format: "{{count}} supplier has at least 5 priority retailers but hasn't clicked \u201CConfirm selection\u201D yet \u2014 selection is not final.",
      data_warning_unconfirmed_few_format: "{{count}} suppliers have at least 5 priority retailers but haven't clicked \u201CConfirm selection\u201D yet \u2014 selection is not final.",
      data_warning_unconfirmed_many_format: "{{count}} suppliers have at least 5 priority retailers but haven't clicked \u201CConfirm selection\u201D yet \u2014 selection is not final.",
      data_warning_unconfirmed_other_format: "{{count}} suppliers have at least 5 priority retailers but haven't clicked \u201CConfirm selection\u201D yet \u2014 selection is not final.",
      data_box_no_picks_title_format: "Suppliers with no picks ({{count}})",
      data_box_unconfirmed_title_format: "Ready, not confirmed ({{count}})",
      data_box_no_resp_title_format: "Retailers with no response ({{count}})",
      plan_warn_no_meetings_title_one_format: "{{count}} company without meetings",
      plan_warn_no_meetings_title_few_format: "{{count}} companies without meetings",
      plan_warn_no_meetings_title_many_format: "{{count}} companies without meetings",
      plan_warn_no_meetings_title_other_format: "{{count}} companies without meetings",
      plan_warn_no_meetings_desc_format: "{{names}} \u2014 check if retailers rejected them or add alternatives in Corrections.",
      plan_warn_swaps_title_one_format: "{{count}} swap suggestion \u2B50/\u{1F44D}",
      plan_warn_swaps_title_few_format: "{{count}} swap suggestions \u2B50/\u{1F44D}",
      plan_warn_swaps_title_many_format: "{{count}} swap suggestions \u2B50/\u{1F44D}",
      plan_warn_swaps_title_other_format: "{{count}} swap suggestions \u2B50/\u{1F44D}",
      plan_warn_swaps_more_format: "...and {{count}} more",
      plan_stat_suppliers: "Suppliers",
      plan_stat_chains: "Retailers",
      plan_stat_meetings: "Meetings",
      plan_stat_full_plans: "Full plans",
      plan_table_card_title: "Suppliers \u2014 meeting plan",
      plan_table_header_company: "Company",
      plan_table_header_pkg: "Package",
      plan_table_header_meetings: "Meetings",
      plan_table_header_chains: "Retailers",
      plan_table_chains_empty: "\u2014",
      plan_table_override_tooltip_one_format: "{{count}} meeting added despite buyer rejection",
      plan_table_override_tooltip_few_format: "{{count}} meetings added despite buyer rejection",
      plan_table_override_tooltip_many_format: "{{count}} meetings added despite buyer rejection",
      plan_table_override_tooltip_other_format: "{{count}} meetings added despite buyer rejection",
      plan_goto_corrections_btn: "\u270F\uFE0F Go to number corrections \u2192",
      corr_phase_warning_title: "Corrections available from Phase 3 (Matching Algorithm)",
      corr_phase_warning_desc_html: "Currently active: <strong>{{phase}}</strong>. Go to the <strong>Management</strong> tab and activate phase 3 \u2014 Algorithm + Corrections.",
      corr_phase3_info_html: "\u2139\uFE0F <strong>Phase 3 \u2014 Administrator Work (September 17\u201321).</strong> Manually adjust the plan and approve it before September 22. Participants no longer have their own corrections \u2014 they can only submit notes via chat.",
      corr_header_title: "Queue number corrections",
      corr_header_desc: "Manually change the meeting order. Available from algorithm launch until publication of the final schedule (September 22).",
      corr_btn_load_approved: "Load approved",
      corr_btn_rebuild: "Rebuild from preferences",
      preview_card_title: "Preview of planned meetings (working)",
      preview_card_desc: "Enable preview for a selected participant \u2014 they will see a preliminary plan with the note \u201CWorking version \u2014 may change before September 22\u201D.",
      preview_section_suppliers: "Suppliers",
      preview_section_chains: "Retailers",
      preview_late_toggle_label: "\u23F0 Late",
      preview_late_toggle_title: "Unlock late selection for this retailer",
      late_card_title: "\u23F0 Late responses \u2014 for manual corrections only",
      late_card_desc: "The following retailers submitted picks AFTER the September 16 deadline. They don't participate in the algorithm.",
      late_row_want_label: "\u2705 Want: ",
      late_row_chance_label: "\u{1F91D} Give a chance: ",
      late_row_remove_label: "\u274C Don't want: ",
      plan_warn_swap_item_format: "{{supplier}}: PRIMARY retailer {{starName}} got number {{starNum}} (red zone), while BACKUP {{thumbName}} got number {{thumbNum}} (green zone). Consider swapping priority in Corrections.",
      algo_header_title: "Matching algorithm \u2014 Phase 3",
      algo_header_status_done_format: "Algorithm completed \xB7 {{count}} meetings generated",
      algo_header_status_ready: "Enough preferences gathered \u2014 you can run the algorithm",
      algo_header_status_waiting: "Waiting for supplier preferences and retailer responses",
      algo_stat_suppliers_ready: "Suppliers ready",
      algo_stat_chains_resp: "Retailers responded",
      algo_stat_meetings_planned: "Planned meetings",
      algo_done_title: "Algorithm completed!",
      algo_done_desc: "Meeting plan ready. View switched to Phase 3. Suppliers and retailers can see results.",
      algo_active_badge_format: "Meeting plan active \u2014 Phase {{phase}}",
      algo_rerun_btn: "Rebuild plan",
      algo_running_btn: "Running algorithm\u2026",
      algo_run_btn: "\u26A1 Run matching algorithm \u2014 Phase 3",
      algo_locked_html: "Algorithm becomes available once at least <strong>{{min}}</strong> suppliers fill in preferences and retailers send responses. Currently ready: <strong>{{ready}} suppliers</strong>, <strong>{{chains}} retailers</strong>.",
      prefs_view: {
        stat_total_stars: "\u2B50 Primary picks",
        stat_total_thumbs: "\u{1F44D} Backup",
        stat_total_want: "\u2705 Want",
        stat_total_chance: "\u{1F91D} Give a chance",
        stat_total_remove: "\u274C No",
        subview_suppliers: "\u{1F3ED} Supplier preferences",
        subview_chains: "\u{1F3EA} Retailer responses",
        search_placeholder_suppliers: "Search company...",
        search_placeholder_chains: "Search retailer...",
        supplier_confirmed_inline: "\u2713 CONFIRMED",
        supplier_confirmed_badge_format: "\u2713 Confirmed {{date}}",
        supplier_stars_section_format: "\u2B50 Primary retailers ({{count}}/{{max}})",
        supplier_thumbs_section_format: "\u{1F44D} Backup ({{count}})",
        resp_badge_want: "\u2705 WANTS",
        resp_badge_chance: "\u{1F91D} LATE",
        resp_badge_remove: "\u274C NO MEETING",
        resp_badge_none: "\u23F3 none",
        resp_title_want: "Buyer: WANTS MEETING",
        resp_title_chance_full: "Buyer: BACK OF QUEUE (deprioritized_by_buyer)",
        resp_title_chance_short: "Buyer: BACK OF QUEUE",
        resp_title_remove_full: "Buyer: DOESN'T WANT MEETING (rejected_by_buyer)",
        resp_title_remove_short: "Buyer: DOESN'T WANT MEETING",
        resp_title_none: "Buyer hasn't responded yet",
        supplier_empty: "This company hasn't selected retailers yet.",
        chain_signups_short_format: "{{count}} reqs",
        chain_detail_meta_format_one: "{{country}} \xB7 {{cat}} \xB7 {{count}} signup",
        chain_detail_meta_format_few: "{{country}} \xB7 {{cat}} \xB7 {{count}} signups",
        chain_detail_meta_format_many: "{{country}} \xB7 {{cat}} \xB7 {{count}} signups",
        chain_detail_meta_format_other: "{{country}} \xB7 {{cat}} \xB7 {{count}} signups",
        chain_group_want: "\u2705 Want",
        chain_group_chance: "\u{1F91D} Give a chance",
        chain_group_remove: "\u274C Not interested",
        chain_group_label_format: "{{label}} ({{count}})",
        chain_empty: "No signups for this retailer."
      },
      tab_event_day: "Event day",
      plan_warn_capacity_title: "Retailer capacity (desks \xD7 meetings per desk)",
      plan_warn_capacity_hint: "Desk configuration: tab \u201CEvent day\u201D \u2192 Desks. Re-run the algorithm after changes."
    },
    corrections: {
      empty_data: "Data not generated yet",
      modal_title: "Heads-up \u2014 buyer rejection",
      modal_text_single_html: "Retailer <strong>{{chain}}</strong> flagged supplier <strong>{{supplier}}</strong> as <strong>DON'T WANT MEETING</strong>. Do you still want to add the meeting manually?",
      modal_text_multi_intro_html: "The following pairs were flagged by buyers as <strong>DON'T WANT MEETING</strong>:",
      modal_text_multi_pair_html: "<strong>{{supplier}}</strong> \u2192 <strong>{{chain}}</strong>",
      modal_text_multi_close: "Do you still want to add these meetings manually?",
      modal_info_html: "\u2139\uFE0F After confirmation the pairs will be marked in the system as <strong>ADDED MANUALLY DESPITE REJECTION</strong> and will be visible with a \u26A0\uFE0F icon in the pipeline and plan preview.",
      modal_btn_cancel: "Cancel",
      modal_btn_confirm: "Add despite rejection",
      status_unapproved_title: "\u26A0\uFE0F Schedule not approved",
      status_unapproved_desc: "Adjust the numbering, then approve the plan. After approval, editing is locked.",
      status_btn_approve: "\u2705 Approve plan",
      status_approved_title: "\u2705 APPROVED \u2014 ready to send to participants",
      status_btn_unlock: "Unlock editing",
      kpi_suppliers: "Suppliers",
      kpi_chains: "Retailers",
      kpi_meetings: "Meetings",
      kpi_admin_changes: "Admin changes",
      wishlist_header: "\u{1F4DD} Additional requests from Retailers (Wishlist)",
      wishlist_desc: "The following retailers asked to add companies to their plan. You can include them manually in the grid.",
      wishlist_requests_label: " is requesting to add: ",
      panel_title: "Number correction panel",
      filter_all_format: "All retailers ({{count}})",
      selected_hint_prefix_html: "\u270B Selected: <strong>{{name}}</strong>",
      selected_hint_suffix: "\u2014 click another cell to swap / move",
      cell_override_tooltip: "Added manually despite buyer rejection",
      legend_green: "\u{1F7E2} 1\u201325 strong position",
      legend_orange: "\u{1F7E0} 26\u201335 medium",
      legend_red: "\u{1F534} 36+ late",
      legend_pkg: "\xB7 Yellow dot = Premium \xB7 Blue = Business",
      instructions_html: "<strong>How to use:</strong> Click a company (it'll highlight yellow) \u2192 click another company = <strong>swap numbers</strong>. Click a company \u2192 click an empty slot (\u2193) = <strong>move to an earlier position</strong>.",
      log_card_title: "\u{1F4CB} Admin change log",
      log_swap_format: "\u{1F504} Swap: {{nameA}} ({{chainA}} #{{posA}}) \u2194 {{nameB}} ({{chainB}} #{{posB}})",
      log_move_format: "\u27A1\uFE0F Move: {{name}} \u2192 {{chain}} #{{pos}}",
      log_override_format: "\u26A0\uFE0F Added despite rejection: {{supplier}} \u2192 {{chain}}"
    },
    late: {
      buyer_title: "Requests for manual corrections \u2014 after deadline",
      admin_title: "Buyer requests for manual corrections",
      description: "Requests are saved separately. They do not change selections, algorithm responses or the meeting plan. The administrator decides whether to apply them manually.",
      refresh: "Refresh requests",
      loading: "Loading\u2026",
      load_error: "Could not read requests or access settings. Refresh and try again. The list is not confirmed.",
      save_error: "Could not confirm the save. Access may have been closed or the connection interrupted. Refresh requests before making another change.",
      saved: "Saved. The meeting plan is unchanged.",
      closed: "Requests are closed. Previous requests remain available to view.",
      search: "Search suppliers\u2026",
      no_results: "No suppliers match your search.",
      phase_required: "New requests can be opened in phase 3, before the plan is published.",
      access_open: "requests open",
      access_closed: "requests closed",
      received: "Received requests \u2014 for administrator review",
      filter: "Retailer filter",
      all_chains: "All retailers",
      empty: "No saved requests.",
      chain: "Retailer",
      supplier: "Supplier",
      choice: "Request",
      date: "Request date"
    },
    board: {
      title: "Safe plan corrections",
      instructions: "A single click shows and highlights all meetings of the company. Double-click a specific meeting to start moving it. Then select another company or an empty cell and review the summary. Only \u201CConfirm change\u201D saves the operation. Click + in an empty position to add a new meeting for a company.",
      company_preview: "All company meetings",
      meeting_count: "Meetings across the entire board: {{count}}",
      start_move: "Move this meeting",
      close_preview: "Close preview",
      move_mode: "Move mode",
      cancel_move: "Cancel moving",
      choose_destination: "Select the destination. The change requires a separate confirmation. Escape or Cancel moving returns to preview.",
      preview_hint: "This is a preview only. To move a specific meeting, double-click it or use the \u201CMove this meeting\u201D button.",
      preview_empty: "Click any company once to see the count and list of all its meetings and highlight them in the board. Preview makes no changes.",
      approved: "Plan approved. Unlock corrections to edit the working board.",
      saved_revision: "Working board saved to the database \u2014 revision {{revision}}. Changes require separate plan approval.",
      not_started: "Corrections have not started yet. Double-click or use \u201CMove this meeting\u201D to save a starting snapshot and then choose a destination.",
      initialize: "Start corrections \u2014 save snapshot",
      loading: "Loading board and history\u2026",
      saving: "Saving board and history\u2026",
      reload: "Refresh board and history",
      phase_locked: "Corrections are available only in phase 3, before publication.",
      undo: "Undo last change",
      rebuild: "Rebuild from preferences",
      load_approved: "Load approved plan",
      approve: "Approve plan",
      unlock: "Unlock corrections",
      cancel: "Cancel \u2014 no change",
      confirm: "Confirm change",
      cancel_selection: "Clear selection",
      filter: "Retailer filter",
      all_chains: "All retailers",
      empty_cell: "Empty cell",
      empty_target: "The destination is empty. The company\u2019s previous position will be cleared.",
      cross_chain: "This moves a company between different retailers \u2014 the meeting partner changes too.",
      rejected: "This retailer rejected the company:",
      accept_rejection: "I explicitly add the meeting despite the buyer\u2019s rejection.",
      gap_warning: "Warning: this company has another meeting at the same or an adjacent queue number.",
      accept_gap: "I checked the spacing between meetings and confirm this correction.",
      confirm_hint: "Cancel makes no change. Confirmation saves the board and history with the author and time. It does not publish the plan or change participant preferences.",
      history: "Correction history",
      history_hint: "History is stored in the database and survives refresh. Undo adds a new entry; previous entries remain. Most recent operations appear first.",
      history_empty: "No saved operations. Changes before the starting snapshot cannot be recovered.",
      more: "Show older entries",
      undo_revision: "Undid the change from revision {{revision}}.",
      override_recorded: "Added despite buyer rejection \u2014 explicitly confirmed by the administrator.",
      confirm_initialize: "Save this board as the starting snapshot?",
      explain_initialize: "We will save the current working board. Every confirmed correction from this point will have its own history entry.",
      confirm_swap: "Swap these companies?",
      confirm_move: "Move the company to the empty cell?",
      confirm_undo: "Undo the last change?",
      explain_undo: "The board will return to its exact state before the operation below. Undo will have its own history entry.",
      confirm_rebuild: "Replace the working board with the algorithm result?",
      explain_rebuild: "The result calculated from the currently loaded preferences will replace working corrections. Both versions and history will be retained. This operation can be undone.",
      confirm_load_approved: "Replace the working board with the approved plan?",
      explain_load_approved: "The approved plan in the database will replace this working board. History is retained and this operation can be undone.",
      confirm_approve: "Approve and save this plan?",
      explain_approve: "The working board will be saved as the approved plan and editing will be locked. This does not publish the plan to participants.",
      confirm_unlock: "Unlock working corrections?",
      explain_unlock: "Editing the working board will be enabled. The previous approved plan remains unchanged until you approve again.",
      action_initialize: "Starting snapshot",
      action_swap: "Company swap",
      action_move: "Company move",
      action_undo: "Undo change",
      action_rebuild: "Rebuild from preferences",
      action_load_approved: "Load approved plan",
      action_approve: "Plan approval",
      action_unlock: "Unlock corrections",
      errors: {
        network: "Could not confirm the current state. Refresh the board and history before another change. Do not blindly repeat the swap.",
        fm_correction_conflict: "Another tab or administrator changed the board. Your operation was not applied. Refresh and check current positions.",
        fm_correction_duplicate: "This company already has a meeting with this retailer. A second meeting for the same pair is blocked.",
        fm_correction_capacity: "This retailer has reached its meeting limit. An empty cell does not increase capacity.",
        fm_correction_rejection_confirmation: "The buyer rejected this company. Refresh responses and explicitly acknowledge the rejection before trying again.",
        fm_correction_undo_conflict: "This revision cannot be safely undone. Refresh the board and history.",
        fm_correction_phase_locked: "The phase has changed. Corrections are locked; refresh the page.",
        fm_correction_plan_changed: "The approved plan changed outside this board. Refresh, then explicitly load the approved plan before continuing.",
        fm_correction_approved_locked: "The plan is approved. Refresh and unlock corrections.",
        fm_correction_no_change: "This operation does not change the board. No new change was saved. Refresh to continue.",
        fm_correction_no_approved_plan: "There is no approved plan in the database yet. Refresh to return to the board.",
        fm_correction_supplier_ineligible: "This company is not an active B2B meeting participant.",
        fm_correction_invalid_cell: "Invalid position. Refresh the board and choose an empty position at an active retailer.",
        fm_correction_occupied: "This position is already occupied. Refresh the board.",
        fm_correction_supplier_limit: "This company already has its full allowance of meetings.",
        fm_correction_limit_invalid: "The company limit cannot be verified. Check the plan settings.",
        fm_correction_chain_inactive: "This retailer is no longer participating. Refresh the board.",
        fm_correction_buyer_rejected: "The buyer rejected this company. This meeting cannot be added.",
        fm_correction_gap: "The company has another meeting at the same or an adjacent number. Choose a position at least two numbers away."
      },
      remove_meeting: "Remove this meeting",
      selected_meeting: "Selected meeting",
      confirm_remove: "Remove this meeting from the plan?",
      explain_remove: "Only the meeting below between this company and this retailer will be removed. All other meetings and queue numbers stay in place. The removal is recorded in history and can be undone. Rebuilding from preferences may add this meeting again.",
      action_remove: "Meeting removed",
      restored_meeting: "\u2014 meeting restored",
      continue_move: "After confirming, choose another company or an empty destination. Saving the starting snapshot or unlocking does not move any meeting.",
      continue_remove: "A separate removal confirmation will follow, showing the company and retailer. This step does not remove a meeting.",
      add_meeting: "Add meeting",
      add_no_move: "One new meeting will be added. All existing meetings and their numbers will stay in place.",
      add_search: "Search company",
      add_company: "Company to add",
      add_choose: "Choose a company\u2026",
      add_unavailable: "cannot be added here",
      add_search_empty: "No company matches this name.",
      add_none_eligible: "No company meets all requirements for this position. Select a company to see the reason, or choose another position.",
      add_count: "Company meetings: {{before}} \u2192 {{after}}. Limit: {{limit}}.",
      add_review: "Review and add",
      confirm_add: "Add a new meeting for this company?",
      explain_add: "Check the company, retailer and position. Nothing is saved until you confirm.",
      action_add: "Meeting added",
      continue_add: "Next, choose a company and separately confirm the new meeting. This step does not add a meeting yet.",
      removed_added_meeting: "Removed the added meeting:"
    }
  },
  chat: {
    floating: {
      header_brand: "Fresh Market Support",
      header_admin_name: "Oksana Koz\u0142owska \xB7 Admin",
      empty_html: "Send a message to the administrator.<br/>We'll respond as soon as possible.",
      input_placeholder: "Write a message... (Enter = send)"
    },
    admin: {
      header_title: "Messages",
      threads_count_format: "{{count}} active threads",
      empty_threads_html: "No messages.<br/>Participants can write through the floating bubble.",
      role_supplier: "Supplier",
      role_buyer: "Buyer",
      role_admin: "Admin",
      prefix_admin_msg: "You: ",
      empty_thread_prompt: "Pick a thread from the list to see the conversation",
      empty_thread_message: "No messages in this thread.",
      ai_loading: "AI is analyzing the query...",
      ai_suggest_btn: "\u2728 Draft a reply (AI)",
      ai_suggest_hint: "The draft will be pasted into the reply field \u2014 review before sending.",
      reply_placeholder_format: "Reply to {{name}}... (Enter = send)",
      send_btn: "Send",
      clear_btn: "Clear",
      send_failed: "The message could not be sent. Please try again.",
      no_recipient_error: "Cannot send the message: this company has no active user account assigned.",
      ai_fallback_reply: "Hello! I'm forwarding this question to our team. I'll get back to you as soon as possible. For urgent matters please contact: oksana@freshmarket.eu \xB7 +48 509 086 949."
    }
  },
  errors: {
    db: {
      grant_companies_required: "Select at least one company.",
      grant_qty_invalid: "The number of credits must be between 1 and 100.",
      grant_reason_invalid: "Choose a reason for the grant.",
      grant_key_missing: "Missing operation key \u2014 close and reopen the form.",
      buyer_profile_id_required: "updateOwnBuyerProfile requires id",
      buyer_profile_name_required: "Full name is required.",
      password_current_required: "Enter your current password.",
      password_length: "New password must be at least 8 characters.",
      password_no_session: "No active session.",
      password_current_invalid: "Current password is invalid.",
      password_change_failed: "Failed to change password.",
      payu_must_be_logged_in: "You must be logged in to buy a package.",
      payu_status_format: "PayU: error {{status}}",
      payu_no_redirect_uri: "PayU: no redirectUri in response",
      company_id_required: "Missing company identifier.",
      buyer_name_required: "Buyer must have a first and last name.",
      buyer_email_required: "Buyer must have an email address.",
      buyer_email_invalid_format: "Buyer email has an invalid format.",
      buyer_retailer_required: "Buyer must be assigned to one retailer.",
      buyer_category_required: "An active buyer must have at least one assigned category.",
      buyer_create_failed: "Failed to create buyer",
      buyer_update_failed: "Failed to update buyer",
      public_url_fetch_failed: "Failed to fetch public URL",
      save_offer_failed_format: "Failed to save submission ({{status}})",
      supplier_register_failed: "Failed to register the account.",
      send_email_failed: "Failed to send email.",
      admin_promote_user_not_found_format: "No user {{email}}. They must register in the app first (e.g. via the supplier registration page), then promote.",
      admin_promote_already_admin_format: "{{email}} is already an administrator.",
      admin_demote_self_forbidden: "You cannot remove administrator rights from yourself.",
      admin_super_demote_self_forbidden: "You cannot remove super admin rights from yourself.",
      no_active_session: "No active session.",
      no_active_admin_session: "No active admin session.",
      ai_company_description_failed: "Failed to generate company description.",
      ai_chat_suggestion_failed: "Failed to generate reply suggestion.",
      ai_moderation_review_failed: "Could not analyse the submission with AI.",
      buyer_id_required: "Missing buyer identifier to update.",
      upload_no_file: "No file",
      upload_ok_url_failed_format: "Upload OK, but URL write failed: {{detail}}",
      upload_ok_insert_failed_format: "Upload OK, but insert failed: {{detail}}",
      admin_invalid_email: "Invalid email",
      admin_missing_user_id: "Missing userId",
      package_plan_required: "No package selected.",
      package_limit_invalid: "Submission limit must be a number equal to or greater than 0.",
      package_plan_inactive: "The selected package does not exist or is inactive.",
      package_limit_below_used_format: "Limit cannot be lower than submissions already used ({{used}}).",
      profile_not_own: "Cannot save the profile of another account. Switch back to your own account and try again.",
      fm_inputs_locked: "The selection stage is already closed \u2014 this change was not saved. Please contact the organiser for corrections.",
      fm_targets_rpc_missing: "Saving selections is temporarily unavailable (system update in progress). Your existing selections are safe \u2014 refresh the page in a moment."
    }
  },
  shell: {
    grants: {
      banner_title_one_format: "You have received {{count}} free PreConnect credit from the organiser",
      banner_title_few_format: "You have received {{count}} free PreConnect credits from the organiser",
      banner_title_many_format: "You have received {{count}} free PreConnect credits from the organiser",
      banner_title_other_format: "You have received {{count}} free PreConnect credits from the organiser",
      banner_valid_format: "Valid until {{date}}. Use them at no extra charge \u2014 free credits are used first.",
      banner_use_btn: "Send a proposal",
      banner_dismiss_btn: "Got it"
    },
    account_switcher: {
      role_admin: "Admin",
      role_supplier: "Supplier",
      role_buyer: "Buyer",
      role_filter_all: "All",
      role_filter_admins: "Admin",
      role_filter_suppliers: "Suppliers",
      role_filter_buyers: "Buyers",
      role_group_admins_format: "Admins ({{count}})",
      role_group_suppliers_format: "Suppliers ({{count}})",
      role_group_buyers_format: "Buyers ({{count}})",
      retailer_inactive_inline: "(retailer inactive)",
      active_account_marker: "\u2713 active"
    },
    package: {
      label_standard_one_format: "Standard \u2013 {{qty}} submission",
      label_standard_few_format: "Standard \u2013 {{qty}} submissions",
      label_standard_many_format: "Standard \u2013 {{qty}} submissions",
      label_standard_other_format: "Standard \u2013 {{qty}} submissions",
      label_premium_one_format: "Premium \u2013 {{qty}} submission",
      label_premium_few_format: "Premium \u2013 {{qty}} submissions",
      label_premium_many_format: "Premium \u2013 {{qty}} submissions",
      label_premium_other_format: "Premium \u2013 {{qty}} submissions",
      label_with_price_standard_one_format: "Standard \u2013 {{qty}} submission ({{perSend}} EUR/submission)",
      label_with_price_standard_few_format: "Standard \u2013 {{qty}} submissions ({{perSend}} EUR/submission)",
      label_with_price_standard_many_format: "Standard \u2013 {{qty}} submissions ({{perSend}} EUR/submission)",
      label_with_price_standard_other_format: "Standard \u2013 {{qty}} submissions ({{perSend}} EUR/submission)",
      label_with_price_premium_one_format: "Premium \u2013 {{qty}} submission ({{perSend}} EUR/submission)",
      label_with_price_premium_few_format: "Premium \u2013 {{qty}} submissions ({{perSend}} EUR/submission)",
      label_with_price_premium_many_format: "Premium \u2013 {{qty}} submissions ({{perSend}} EUR/submission)",
      label_with_price_premium_other_format: "Premium \u2013 {{qty}} submissions ({{perSend}} EUR/submission)",
      label_credits_standard_one_format: "Standard \u2013 {{qty}} credit",
      label_credits_standard_few_format: "Standard \u2013 {{qty}} credits",
      label_credits_standard_many_format: "Standard \u2013 {{qty}} credits",
      label_credits_standard_other_format: "Standard \u2013 {{qty}} credits",
      label_credits_premium_one_format: "Premium \u2013 {{qty}} credit",
      label_credits_premium_few_format: "Premium \u2013 {{qty}} credits",
      label_credits_premium_many_format: "Premium \u2013 {{qty}} credits",
      label_credits_premium_other_format: "Premium \u2013 {{qty}} credits",
      transaction_purchase_format: "Package purchase: {{pkgLabel}}",
      transaction_topup: "Top-up"
    },
    sidebar: {
      dashboard: "Dashboard",
      preconnect_section: "PreConnect",
      instructions: "Instructions",
      instructions_page_title: "Instructions",
      instructions_empty: "Instructions will appear soon.",
      ticker_close: "Close",
      announcement_title: "Important notice",
      fm_section: "Fresh Market 2026",
      admin_section: "Admin",
      admin_operational_section: "Operational",
      admin_finance_section: "Finance",
      system_section: "System",
      supplier_wysylki: "Submissions",
      supplier_my_offers: "My submissions",
      supplier_finance: "Finance",
      supplier_your_company: "Your company",
      supplier_my_profile: "My profile",
      fm_locked_label: "FM 2026 meetings",
      fm_locked_tooltip_company: "B2B meetings are activated individually by the administrator for your company.",
      fm_locked_tooltip_phase: "The B2B meetings phase is not open yet.",
      fm_select_retailers: "Retailer selection",
      fm_algorithm: "Algorithm",
      fm_your_meetings: "Your meetings",
      buyer_offers: "Submissions",
      buyer_suppliers: "Suppliers",
      buyer_saved: "Saved",
      buyer_my_profile: "My Profile",
      buyer_fm_meetings: "FM 2026 meetings",
      admin_pipeline: "Pipeline",
      admin_retailers: "Retailers",
      admin_firmy: "Companies",
      admin_settlements: "Settlements",
      admin_messages: "Messages",
      admin_fm_meetings: "FM Meetings B2B",
      admin_branding: "Branding",
      admin_team: "Administrators",
      admin_super_badge: "SUPER",
      admin_super_tooltip: "Only super admins can see this tab",
      admin_pipeline_pending_tooltip_one_format: "{{count}} submission awaiting moderation",
      admin_pipeline_pending_tooltip_few_format: "{{count}} submissions awaiting moderation",
      admin_pipeline_pending_tooltip_many_format: "{{count}} submissions awaiting moderation",
      admin_pipeline_pending_tooltip_other_format: "{{count}} submissions awaiting moderation",
      admin_firmy_pending_tooltip_one_format: "{{count}} company awaiting approval",
      admin_firmy_pending_tooltip_few_format: "{{count}} companies awaiting approval",
      admin_firmy_pending_tooltip_many_format: "{{count}} companies awaiting approval",
      admin_firmy_pending_tooltip_other_format: "{{count}} companies awaiting approval",
      admin_fm_status_published: "Published",
      admin_fm_status_active: "Active",
      admin_fm_status_closed: "Closed"
    },
    app_toasts: {
      package_purchased_format: "Package purchased! +{{qty}} submissions added to your account.",
      package_purchased_credits_format: "Package purchased! +{{qty}} credits added to your account.",
      moderate_error_format: "Moderation error: {{message}}",
      moderate_approved: "Submission approved",
      moderate_rejected: "Submission rejected",
      send_no_approved: "No approved submissions.",
      send_error_format: "Send error: {{message}}",
      send_success_format: "Sent {{count}} submissions.",
      confirm_error_format: "Confirmation error: {{message}}",
      confirm_saved: "Confirmation saved.",
      undo_confirm_error_format: "Undo confirmation error: {{message}}",
      undo_confirm_done: "Confirmation undone",
      fm_company_not_found: "Could not find your company in the database. Contact the administrator.",
      fm_confirm_error_format: "Confirmation error: {{message}}",
      fm_confirm_saved: "Thank you, your retailer selection has been saved.",
      ai_ready_with_website: "AI prepared the description from company data and website.",
      ai_ready_company_only: "AI prepared the description from company data.",
      ai_failed: "Failed to generate company description.",
      ai_tier_rich: "(extended profile)",
      ai_tier_minimal: "(short profile \u2014 add more data for a richer description)",
      tryagain_fallback: "try again",
      chat_msg_sent_success: "\u2713 Message sent to the administrator. The reply will appear in the chat (bottom-right).",
      chat_msg_failed: "Failed to send the message. Try again or write directly to: newsletter@freshmarket.eu",
      chat_req_sent_success: "\u2713 Request sent to the administrator. The reply will appear in the chat (bottom-right).",
      chat_req_failed: "Failed to send the message. Try again or write directly to: newsletter@freshmarket.eu"
    },
    activation_banner: {
      pending_title: "Account awaiting approval.",
      pending_desc: " You can complete the company profile, upload logo and certificates. After the administrator approves, we will unlock sending submissions to retailers (PreConnect) and B2B Meetings.",
      pending_button_default: "Write to admin",
      pending_button_sent: "\u2713 Sent",
      pending_chat_template_format: "Please activate the account for company {{name}} in the Fresh Market B2B panel.\n\nMy profile is complete and I'm awaiting the decision. Let me know if anything else needs to be added.",
      company_name_placeholder: "(no name)",
      rejected_title: "Registration was not approved.",
      rejected_desc_suffix: " Contact ",
      suspended_title: "Account has been suspended.",
      suspended_desc_suffix: " The company profile remains available, but submissions and B2B meetings are blocked until clarification.",
      partial_title: "Account is active.",
      partial_off_preconnect: "PreConnect (sending submissions to retailers) is not yet active",
      partial_off_fm: "Fresh Market 2026 B2B Meetings are activated individually by the administrator",
      partial_module_preconnect: "PreConnect",
      partial_module_fm: "FM 2026 Meetings",
      partial_button: "Request activation",
      partial_chat_template_format: "Please activate modules {{modules}} for company {{name}} in the Fresh Market B2B panel.\n\nMy account is active but the selected modules are not yet. Can I get access?"
    },
    refunds: {
      wallet_desc_format: "Refund for unread submission #{{id}}",
      notif_msg_format: "Refund for unread submission #{{id}} has been credited to your wallet.",
      notif_amount_label_format: "Refund {{amount}} EUR",
      notif_forward_btn: "Forward"
    }
  },
  fm_plan: {
    title: "Meeting plan export \u2014 PDF cards, Excel, mailing",
    desc: "Cards for suppliers and chains (language by company country: PL / EN), print-shop batch files, master Excel for the team and e-mail dispatch. Data is fetched from the database when you click.",
    load: "Fetch data and prepare cards",
    reload: "Refresh data",
    loading: "Preparing: {{step}}",
    step_data: "database\u2026",
    step_images: "logos\u2026",
    step_render: "cards {{done}}/{{total}}\u2026",
    mode_final: "Approved plan",
    mode_working: "Working plan (not approved)",
    mode_simulation: "SIMULATION \u2014 no approved plan, cards carry a watermark",
    stats: "{{suppliers}} suppliers \xB7 {{chains}} chains \xB7 {{pairs}} meetings \xB7 no e-mail: {{noEmail}}",
    dl_excel: "Excel (master)",
    dl_print_sup: "PRINT \u2014 suppliers (PDF)",
    dl_print_chain: "PRINT \u2014 chains (PDF)",
    dl_zip: "ZIP \u2014 all cards",
    send_test: "Send a test to my address",
    send_suppliers: "Send to suppliers ({{n}})",
    send_chains: "Send to chains ({{n}})",
    send_blocked: "Sending to participants is possible only after the plan is approved. A test to your own address always works.",
    confirm_send: "Send {{n}} e-mails with PDF cards? Each recipient gets their own card in their language. This cannot be undone.",
    sending: "Sending {{done}}/{{total}}\u2026",
    sent_summary: "Sent: {{ok}} \xB7 errors: {{err}} \xB7 skipped (no e-mail): {{skipped}}",
    col_card: "Card",
    col_name: "Company / chain",
    col_lang: "Lang",
    col_n: "Meetings",
    col_pages: "Pages",
    col_emails: "E-mails",
    col_status: "Status",
    preview: "Preview",
    no_email: "no e-mail",
    sent_at: "sent {{when}}",
    gate_missing: "Chains without a gate set: {{names}} \u2014 set it in the Retailers tab, otherwise cards will show \u201CGATE ?\u201D.",
    test_sent: "Test sent to {{email}}",
    error: "Error: {{message}}",
    tab_suppliers: "Suppliers",
    tab_chains: "Chains",
    status_ok: "sent",
    status_err: "error",
    status_skip: "skipped",
    send_note: "Cards for e-mail are generated on the server from the approved plan (the same version you see in the table) with logos fetched from our Storage; the browser sends no card bytes at all. Each recipient gets a separate message with an idempotency key and a retry after an error never re-sends to addresses already served.",
    already_sent: "all recipients already had this version",
    in_progress: "in progress",
    uncertain: "uncertain result, retry",
    unconfirmed: "accepted by mail provider, confirmation not stored \u2014 retry (no duplicate)",
    stale_unconfirmed: "uncertain result older than 24 h \u2014 check Resend, then \u201CSend again anyway\u201D",
    retry_send: "Retry",
    force_send: "Send again anyway",
    force_confirm: "This attempt is older than 24 h, so the mail provider will not recognise the repeat. If the message went out earlier, the recipient will receive it twice. Send anyway?"
  },
  profile: {
    impersonation: {
      notice: "You are viewing another account. The \u201EMy profile\u201D page and the password change always apply to your own administrator account, so editing is disabled here. Change this person\u2019s data in the admin panel (Companies / Buyers).",
      blocked: "Viewing another account \u2014 saving is disabled so your own profile is not overwritten."
    }
  }
};

// netlify/functions/_shared/render-retailer-email.js
var FLAG = {
  AT: "\u{1F1E6}\u{1F1F9}",
  BE: "\u{1F1E7}\u{1F1EA}",
  BG: "\u{1F1E7}\u{1F1EC}",
  BR: "\u{1F1E7}\u{1F1F7}",
  CL: "\u{1F1E8}\u{1F1F1}",
  CO: "\u{1F1E8}\u{1F1F4}",
  CR: "\u{1F1E8}\u{1F1F7}",
  HR: "\u{1F1ED}\u{1F1F7}",
  CY: "\u{1F1E8}\u{1F1FE}",
  CZ: "\u{1F1E8}\u{1F1FF}",
  DE: "\u{1F1E9}\u{1F1EA}",
  DK: "\u{1F1E9}\u{1F1F0}",
  EC: "\u{1F1EA}\u{1F1E8}",
  EG: "\u{1F1EA}\u{1F1EC}",
  EE: "\u{1F1EA}\u{1F1EA}",
  FI: "\u{1F1EB}\u{1F1EE}",
  FR: "\u{1F1EB}\u{1F1F7}",
  GR: "\u{1F1EC}\u{1F1F7}",
  ES: "\u{1F1EA}\u{1F1F8}",
  NL: "\u{1F1F3}\u{1F1F1}",
  IE: "\u{1F1EE}\u{1F1EA}",
  IT: "\u{1F1EE}\u{1F1F9}",
  KE: "\u{1F1F0}\u{1F1EA}",
  LV: "\u{1F1F1}\u{1F1FB}",
  LT: "\u{1F1F1}\u{1F1F9}",
  LU: "\u{1F1F1}\u{1F1FA}",
  MD: "\u{1F1F2}\u{1F1E9}",
  MT: "\u{1F1F2}\u{1F1F9}",
  MA: "\u{1F1F2}\u{1F1E6}",
  PE: "\u{1F1F5}\u{1F1EA}",
  PL: "\u{1F1F5}\u{1F1F1}",
  PT: "\u{1F1F5}\u{1F1F9}",
  RO: "\u{1F1F7}\u{1F1F4}",
  SK: "\u{1F1F8}\u{1F1F0}",
  SI: "\u{1F1F8}\u{1F1EE}",
  ZA: "\u{1F1FF}\u{1F1E6}",
  SE: "\u{1F1F8}\u{1F1EA}",
  TR: "\u{1F1F9}\u{1F1F7}",
  UA: "\u{1F1FA}\u{1F1E6}",
  HU: "\u{1F1ED}\u{1F1FA}"
};
var CNAME_PL = {
  AT: "Austria",
  BE: "Belgia",
  BG: "Bu\u0142garia",
  BR: "Brazylia",
  CL: "Chile",
  CO: "Kolumbia",
  CR: "Kostaryka",
  HR: "Chorwacja",
  CY: "Cypr",
  CZ: "Czechy",
  DE: "Niemcy",
  DK: "Dania",
  EC: "Ekwador",
  EG: "Egipt",
  EE: "Estonia",
  FI: "Finlandia",
  FR: "Francja",
  GR: "Grecja",
  ES: "Hiszpania",
  NL: "Holandia",
  IE: "Irlandia",
  IT: "W\u0142ochy",
  KE: "Kenia",
  LV: "\u0141otwa",
  LT: "Litwa",
  LU: "Luksemburg",
  MD: "Mo\u0142dawia",
  MT: "Malta",
  MA: "Maroko",
  PE: "Peru",
  PL: "Polska",
  PT: "Portugalia",
  RO: "Rumunia",
  SK: "S\u0142owacja",
  SI: "S\u0142owenia",
  ZA: "RPA",
  SE: "Szwecja",
  TR: "Turcja",
  UA: "Ukraina",
  HU: "W\u0119gry"
};
var CNAME_EN = {
  AT: "Austria",
  BE: "Belgium",
  BG: "Bulgaria",
  BR: "Brazil",
  CL: "Chile",
  CO: "Colombia",
  CR: "Costa Rica",
  HR: "Croatia",
  CY: "Cyprus",
  CZ: "Czechia",
  DE: "Germany",
  DK: "Denmark",
  EC: "Ecuador",
  EG: "Egypt",
  EE: "Estonia",
  FI: "Finland",
  FR: "France",
  GR: "Greece",
  ES: "Spain",
  NL: "Netherlands",
  IE: "Ireland",
  IT: "Italy",
  KE: "Kenya",
  LV: "Latvia",
  LT: "Lithuania",
  LU: "Luxembourg",
  MD: "Moldova",
  MT: "Malta",
  MA: "Morocco",
  PE: "Peru",
  PL: "Poland",
  PT: "Portugal",
  RO: "Romania",
  SK: "Slovakia",
  SI: "Slovenia",
  ZA: "South Africa",
  SE: "Sweden",
  TR: "Turkey",
  UA: "Ukraine",
  HU: "Hungary"
};
function pickLocale(input) {
  if (!input) return "pl";
  const raw = String(input).trim().toLowerCase().split(/[-_]/)[0];
  return ["pl", "en"].includes(raw) ? raw : "pl";
}
function pluralOfertaPL(n) {
  if (n === 1) return "oferta";
  if (n >= 2 && n <= 4) return "oferty";
  return "ofert";
}
function pluralKupiecPL(n) {
  if (n === 1) return "kupca";
  return "kupc\xF3w";
}
function pluralOfferEN(n) {
  return n === 1 ? "submission" : "submissions";
}
function pluralBuyerEN(n) {
  return n === 1 ? "buyer" : "buyers";
}
function brandLogoBox(brandLogoUrl, { footer = false } = {}) {
  if (!brandLogoUrl) {
    return `<div style="color:${footer ? "rgba(255,255,255,0.92)" : "white"};font-weight:800;font-size:${footer ? "15px" : "22px"};letter-spacing:-0.5px;">Fresh Market <span style="color:${footer ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.55)"};font-weight:600;font-size:${footer ? "12px" : "13px"};">PreConnect</span></div>`;
  }
  return `<div style="display:inline-block;background:rgba(255,255,255,0.96);padding:${footer ? "6px 12px" : "8px 16px"};border-radius:12px;margin-bottom:${footer ? "8px" : "14px"};">
    <img src="${esc(brandLogoUrl)}" alt="Fresh Market" width="${footer ? "130" : "170"}" style="display:block;max-width:${footer ? "130px" : "170px"};height:auto;border:0;outline:none;text-decoration:none;">
  </div>`;
}
function buildSubject({ retailer, offerCount, locale }) {
  const lng = pickLocale(locale);
  const safeName = retailer?.name || (lng === "en" ? "retailer" : "sieci");
  if (lng === "en") {
    return `Fresh Market PreConnect \u2013 supplier ${pluralOfferEN(offerCount)} for ${safeName} (${offerCount})`;
  }
  return `Fresh Market PreConnect \u2013 propozycje dostawc\xF3w dla ${safeName} (${offerCount})`;
}
function renderRetailerEmail({ retailer, sends, offers, companies, buyerCount, month, appUrl, locale, brandLogoUrl, magicLinksByLegacyId }) {
  const lng = pickLocale(locale);
  const sortedSends = [...sends].sort((a, b) => {
    const ap = a.data && a.data.pos || a.pos || 99;
    const bp = b.data && b.data.pos || b.pos || 99;
    return ap - bp;
  });
  const offerCount = sortedSends.length;
  const subject = buildSubject({ retailer, offerCount, locale: lng });
  const offerBlocks = sortedSends.map((s) => renderOfferBlock(s, offers, companies, appUrl, lng, magicLinksByLegacyId)).join("");
  const i18n = lng === "en" ? {
    headerSubtitleFormat: (m) => `Supplier proposals \u2013 ${esc(m)}`,
    headerMailingFor: (name) => `Prepared for <strong style="color:rgba(255,255,255,0.9);">${esc(name)}</strong>`,
    introGreet: "Dear Sir or Madam,",
    introBody: (count, retName) => `below you will find <strong>${count} supplier ${pluralOfferEN(count)}</strong> directed to <strong>${esc(retName)}</strong>. This is not a closed selection: all current proposals, supplier profiles and company contact details are available in the Fresh Market B2B application.`,
    introHint: "Use the button by a proposal to sign in securely with a magic link and open that proposal in the application.",
    buyerLine: (count, retName) => `Goes to ${count} ${pluralBuyerEN(count)} at ${esc(retName)}`,
    footerAddress: "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Poland",
    footerLegalFormat: (year, retName) => `You received this message because you are registered with the Fresh Market PreConnect programme as a buyer at ${esc(retName)}.<br>\xA9 ${year} KJOW Sp. z o.o. All rights reserved.`
  } : {
    headerSubtitleFormat: (m) => `Propozycje od dostawc\xF3w \u2013 ${esc(m)}`,
    headerMailingFor: (name) => `Skierowane do sieci <strong style="color:rgba(255,255,255,0.9);">${esc(name)}</strong>`,
    introGreet: "Szanowni Pa\u0144stwo,",
    introBody: (count, retName) => `poni\u017Cej znajd\u0105 Pa\u0144stwo <strong>${count} ${pluralOfertaPL(count)}</strong> od dostawc\xF3w skierowanych do sieci <strong>${esc(retName)}</strong>. To nie jest zamkni\u0119ta selekcja: wszystkie aktualne propozycje, profile dostawc\xF3w oraz dane kontaktowe firm s\u0105 dost\u0119pne w aplikacji Fresh Market B2B.`,
    introHint: "Kliknij przycisk przy propozycji, aby bezpiecznie zalogowa\u0107 si\u0119 magic linkiem i przej\u015B\u0107 bezpo\u015Brednio do tej propozycji w aplikacji.",
    buyerLine: (count, retName) => `Trafia do ${count} ${pluralKupiecPL(count)} z sieci ${esc(retName)}`,
    footerAddress: "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Polska",
    footerLegalFormat: (year, retName) => `Otrzyma\u0142e\u015B t\u0119 wiadomo\u015B\u0107, poniewa\u017C jeste\u015B zarejestrowany w programie Fresh Market PreConnect jako kupiec sieci ${esc(retName)}.<br>\xA9 ${year} KJOW Sp. z o.o. Wszelkie prawa zastrze\u017Cone.`
  };
  const retailerName = retailer?.name || "";
  return {
    subject,
    html: `<!DOCTYPE html>
<html lang="${lng}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${esc(subject)}</title>
</head>
<body style="margin:0;padding:0;background:#ececec;font-family:Arial,Helvetica,sans-serif;color:#1a1a1a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ececec;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 18px rgba(15,23,42,0.08);">
      <!-- Header -->
      <tr><td style="background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#0d9488 100%);padding:28px 32px;text-align:center;">
        ${brandLogoBox(brandLogoUrl)}
        <div style="color:rgba(255,255,255,0.95);font-size:20px;font-weight:700;margin-bottom:4px;">${i18n.headerSubtitleFormat(month)}</div>
        <div style="color:rgba(255,255,255,0.55);font-size:13px;">${i18n.headerMailingFor(retailerName)}</div>
      </td></tr>
      <!-- Intro -->
      <tr><td style="padding:22px 32px 8px;border-left:4px solid #0d9488;border-right:4px solid #0d9488;">
        <p style="margin:0 0 10px;color:#334155;line-height:1.6;font-size:14px;">${i18n.introGreet}</p>
        <p style="margin:0 0 10px;color:#334155;line-height:1.65;font-size:14px;">${i18n.introBody(offerCount, retailerName)}</p>
        <p style="margin:0 0 10px;color:#0f766e;line-height:1.6;font-size:13px;font-weight:700;">${i18n.introHint}</p>
        <p style="margin:0;font-size:12px;color:#94a3b8;">${i18n.buyerLine(buyerCount, retailerName)}.</p>
      </td></tr>
      <!-- Offers -->
      ${offerBlocks}
      <!-- Footer -->
      <tr><td style="background:#0f172a;padding:22px 28px;text-align:center;">
        ${brandLogoBox(brandLogoUrl, { footer: true })}
        <div style="color:rgba(255,255,255,0.45);font-size:11px;line-height:1.8;">
          ${i18n.footerAddress}<br>
          <a href="${esc(appUrl)}" style="color:rgba(255,255,255,0.7);text-decoration:none;">freshmarket.eu</a> \xB7
          <a href="mailto:newsletter@freshmarket.eu" style="color:rgba(255,255,255,0.7);text-decoration:none;">newsletter@freshmarket.eu</a> \xB7
          +48 603 424 346
        </div>
        <div style="margin-top:12px;padding-top:10px;border-top:1px solid rgba(255,255,255,0.1);font-size:10px;color:rgba(255,255,255,0.35);line-height:1.6;">
          ${i18n.footerLegalFormat((/* @__PURE__ */ new Date()).getFullYear(), retailerName)}
        </div>
      </td></tr>
    </table>
  </td></tr>
</table>
</body>
</html>`
  };
}
function renderOfferBlock(send, offersMap, companiesMap, appUrl, lng, magicLinksByLegacyId) {
  const data = send.data || {};
  const offerId = data.offerId || send.offer_legacy_id;
  const offer = offerId != null ? offersMap.get(offerId) || offersMap.get(String(offerId)) : null;
  if (!offer) return "";
  const supplierKey = data.supplierId || offer.supplierId;
  const company = supplierKey ? companiesMap.get(supplierKey) : null;
  const isPrem = (offer.tier || "") === "premium";
  const photo = Array.isArray(offer.photos) && offer.photos[0] ? typeof offer.photos[0] === "string" ? offer.photos[0] : offer.photos[0].url : null;
  const certs = [...offer.certs || [], offer.customCert].filter(Boolean);
  const enumLabel = (field, value) => offerEnumLabel(field, value, (key, { defaultValue }) => lng === "en" ? key.split(".").reduce((o, k) => o?.[k], legacy_default) ?? defaultValue : defaultValue);
  const packaging = [...(offer.packaging || []).map((p) => enumLabel("packaging", p)), offer.customPackaging].filter(Boolean);
  const cnames = lng === "en" ? CNAME_EN : CNAME_PL;
  const originLabel = offer.origin ? `${FLAG[offer.origin] || "\u{1F310}"} ${esc(cnames[offer.origin] || offer.origin)}` : "";
  const cta = offer.cta || "";
  const ctaLabels = lng === "en" ? {
    samples: "Request samples",
    rfq: "Ask about price & volume",
    meet_fm: "Book a meeting",
    default: "View in app",
    supplierFallback: "Fresh Market supplier"
  } : {
    samples: "Popro\u015B o pr\xF3bki",
    rfq: "Zapytaj o cen\u0119 i wolumen",
    meet_fm: "Um\xF3w spotkanie",
    default: "Zobacz w aplikacji",
    supplierFallback: "Dostawca Fresh Market"
  };
  const ctaLabel = cta.includes("samples") ? ctaLabels.samples : cta.includes("rfq") ? ctaLabels.rfq : cta.includes("meet_fm") ? ctaLabels.meet_fm : ctaLabels.default;
  const sendIdForLink = send.legacy_id || data.id || "";
  const fallbackCtaUrl = sendIdForLink ? `${appUrl}/kupiec?send=${esc(sendIdForLink)}` : `${appUrl}/kupiec`;
  const magicCtaUrl = sendIdForLink ? magicLinksByLegacyId?.get?.(String(sendIdForLink)) : null;
  const ctaUrl = magicCtaUrl || fallbackCtaUrl;
  const companyName = company?.name || ctaLabels.supplierFallback;
  const companyLogo = company?.logo_url || company?.logo || null;
  const trOffer = lng === "en" && offer?.i18n_en && typeof offer.i18n_en === "object" ? offer.i18n_en : null;
  const offerTitle = trOffer?.title || trOffer?.product || offer.title || offer.product || "";
  const offerDesc = trOffer?.description || offer.description || "";
  const companyDescShort = ((lng === "en" ? company?.description_short_en || company?.description_short : company?.description_short) || "").trim();
  return `
<tr><td style="padding:0 0 0 0;border-left:4px solid ${isPrem ? "#fbbf24" : "#e2e8f0"};border-right:4px solid ${isPrem ? "#fbbf24" : "#e2e8f0"};border-bottom:1px solid #f1f5f9;background:white;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:white;">
    <tr><td style="padding:18px 24px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="top" style="width:56px;padding-right:14px;">
            ${companyLogo ? `<img src="${esc(companyLogo)}" alt="${esc(companyName)}" width="48" height="48" style="display:block;width:48px;height:48px;object-fit:contain;border-radius:8px;border:1px solid #e2e8f0;background:white;">` : `<div style="width:48px;height:48px;border-radius:8px;background:#f1f5f9;color:#64748b;text-align:center;line-height:48px;font-weight:700;font-size:16px;">${esc(initials(companyName))}</div>`}
          </td>
          <td valign="top">
            <div style="font-size:11px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:2px;">${esc(companyName)}${isPrem ? `<span style="background:#d97706;color:white;font-size:10px;padding:2px 8px;border-radius:20px;margin-left:8px;text-transform:none;letter-spacing:0;">PREMIUM</span>` : ""}</div>
            <div style="font-weight:700;font-size:16px;color:#0f172a;line-height:1.3;margin-bottom:4px;">${esc(offerTitle)}</div>
            <div style="font-size:12px;color:#64748b;">${originLabel}${offer.volume ? ` \xB7 ${esc(offer.volume)} ${esc(enumLabel("volumeUnit", offer.volumeUnit || ""))}` : ""}${packaging[0] ? ` \xB7 ${esc(packaging[0])}` : ""}</div>
          </td>
        </tr>
      </table>
      ${photo ? `<div style="margin-top:12px;"><img src="${esc(photo)}" alt="" width="552" style="display:block;width:100%;max-width:552px;height:auto;border-radius:8px;border:1px solid #f1f5f9;"></div>` : ""}
      ${offerDesc ? `<p style="margin:12px 0 0;font-size:13px;line-height:1.7;color:#475569;background:${isPrem ? "#fffbeb" : "#f8fafc"};padding:10px 14px;border-radius:7px;border-left:3px solid ${isPrem ? "#fbbf24" : "#e2e8f0"};">${esc(truncate(offerDesc, 280))}</p>` : ""}
      ${certs.length > 0 || companyDescShort ? `
        <div style="margin-top:10px;font-size:11px;color:#64748b;">
          ${certs.length > 0 ? certs.slice(0, 5).map((c) => `<span style="background:#d1fae5;color:#047857;font-weight:600;padding:2px 8px;border-radius:20px;border:1px solid #6ee7b7;margin-right:4px;">\u2713 ${esc(c)}</span>`).join("") : ""}
        </div>` : ""}
      <div style="margin-top:14px;text-align:right;">
        <a href="${esc(ctaUrl)}" style="display:inline-block;background:${isPrem ? "#d97706" : "#0d9488"};color:white;padding:9px 20px;border-radius:7px;font-weight:700;font-size:12px;text-decoration:none;">${esc(ctaLabel)}</a>
      </div>
    </td></tr>
  </table>
</td></tr>`;
}
function initials(name) {
  return String(name || "").split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "\u2022";
}
function truncate(s, max) {
  const text = String(s || "").trim();
  if (text.length <= max) return text;
  return text.slice(0, max - 1).trimEnd() + "\u2026";
}
function esc(s) {
  if (s == null) return "";
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// netlify/functions/_shared/supplier-email-templates.js
var SUPPORTED_TPL_LOCALES = ["pl", "en"];
function pickLocale2(input) {
  if (!input) return "pl";
  const raw = String(input).trim().toLowerCase().split(/[-_]/)[0];
  return SUPPORTED_TPL_LOCALES.includes(raw) ? raw : "pl";
}
var CONTACT_EMAIL = process.env.ACCOUNT_EMAIL_CONTACT_FIX === "true" ? "hello@freshmarket.eu" : "newsletter@freshmarket.eu";
var FOOTER = (appUrl, locale = "pl") => {
  const addressLine = locale === "en" ? "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Poland" : "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Polska";
  return `
<tr><td style="background:#0f172a;padding:18px 28px;text-align:center;">
  <div style="color:rgba(255,255,255,0.92);font-weight:700;font-size:13px;margin-bottom:4px;">Fresh Market PreConnect</div>
  <div style="color:rgba(255,255,255,0.45);font-size:11px;line-height:1.7;">
    ${addressLine}<br>
    <a href="${esc2(appUrl)}" style="color:rgba(255,255,255,0.7);text-decoration:none;">freshmarket.eu</a> \xB7
    <a href="mailto:${CONTACT_EMAIL}" style="color:rgba(255,255,255,0.7);text-decoration:none;">${CONTACT_EMAIL}</a>
  </div>
</td></tr>`;
};
function shell({ title, accent = "#0d9488", body, appUrl, locale = "pl" }) {
  return `<!DOCTYPE html>
<html lang="${locale}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc2(title)}</title></head>
<body style="margin:0;padding:0;background:#ececec;font-family:Arial,Helvetica,sans-serif;color:#1a1a1a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ececec;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 18px rgba(15,23,42,0.08);">
      <tr><td style="background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,${accent} 100%);padding:24px 32px;text-align:center;">
        <div style="color:white;font-weight:800;font-size:20px;letter-spacing:-0.4px;">Fresh Market <span style="color:rgba(255,255,255,0.6);font-weight:600;font-size:12px;">PreConnect</span></div>
      </td></tr>
      ${body}
      ${FOOTER(appUrl, locale)}
    </table>
  </td></tr>
</table>
</body></html>`;
}
function pBlock(text) {
  return `<p style="margin:0 0 10px;color:#334155;line-height:1.65;font-size:14px;">${text}</p>`;
}
function ctaButton(label, url, color = "#0d9488") {
  return `<div style="margin:18px 0 8px;text-align:center;">
    <a href="${esc2(url)}" style="display:inline-block;background:${color};color:white;padding:11px 24px;border-radius:7px;font-weight:700;font-size:13px;text-decoration:none;">${esc2(label)}</a>
  </div>`;
}
function offerItemsList(offers = [], locale = "pl") {
  const items = (offers || []).filter(Boolean);
  if (!items.length) return "";
  const visible = items.slice(0, 8);
  const extra = items.length - visible.length;
  const moreLabel = locale === "en" ? `+ ${extra} more` : `+ ${extra} kolejne`;
  const fallbackTitle = locale === "en" ? "Submission" : "Oferta";
  return `<ul style="color:#334155;font-size:14px;line-height:1.7;padding-left:18px;margin:8px 0 12px;">
    ${visible.map((o) => `<li><strong>${esc2(o.title || o.offerTitle || o.product || fallbackTitle)}</strong></li>`).join("")}
    ${extra > 0 ? `<li>${moreLabel}</li>` : ""}
  </ul>`;
}
function pluralOffersPL(count) {
  const n = Math.abs(Number(count || 0));
  if (n === 1) return "ofert\u0119";
  const last = n % 10;
  const lastTwo = n % 100;
  if (last >= 2 && last <= 4 && !(lastTwo >= 12 && lastTwo <= 14)) return "oferty";
  return "ofert";
}
function pluralOffersEN(count) {
  return Number(count) === 1 ? "submission" : "submissions";
}
function tplOffersSentToRetailer({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl, locale }) {
  const lng = pickLocale2(locale);
  if (lng === "en") return tplOffersSentToRetailerEN({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl });
  return tplOffersSentToRetailerPL({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl });
}
function tplOffersSentToRetailerPL({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl }) {
  const count = Number(offerCount || (offers || []).length || 1);
  const subject = count === 1 ? `Fresh Market \u2013 oferta zosta\u0142a wys\u0142ana do ${retailerName || "sieci"}` : `Fresh Market \u2013 wys\u0142ali\u015Bmy ${count} ${pluralOffersPL(count)} do ${retailerName || "sieci"}`;
  const list = offerItemsList(offers?.length ? offers : [{ title: offerTitle }], "pl");
  const intro = count === 1 ? `Twoja oferta zosta\u0142a wys\u0142ana do sieci <strong>${esc2(retailerName || "")}</strong>${sentAt ? ` w dniu ${esc2(sentAt)}` : ""}.` : `Wys\u0142ali\u015Bmy do sieci <strong>${esc2(retailerName || "")}</strong> <strong>${count} ${pluralOffersPL(count)}</strong>${sentAt ? ` w dniu ${esc2(sentAt)}` : ""}.`;
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Dzie\u0144 dobry,")}
  ${pBlock(intro)}
  ${list}
  ${pBlock("Kupiec otrzyma\u0142 zbiorczy mail Fresh Market PreConnect. Gdy otworzy mail albo wejdzie na list\u0119 ofert w panelu, oznaczymy wysy\u0142k\u0119 jako dostarczon\u0105 i poka\u017Cemy rozliczenie w panelu.")}
  ${ctaButton("Zobacz w panelu", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "pl" }) };
}
function tplOffersSentToRetailerEN({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl }) {
  const count = Number(offerCount || (offers || []).length || 1);
  const subject = count === 1 ? `Fresh Market \u2013 submission sent to ${retailerName || "retailer"}` : `Fresh Market \u2013 ${count} ${pluralOffersEN(count)} sent to ${retailerName || "retailer"}`;
  const list = offerItemsList(offers?.length ? offers : [{ title: offerTitle }], "en");
  const intro = count === 1 ? `Your submission has been sent to <strong>${esc2(retailerName || "")}</strong>${sentAt ? ` on ${esc2(sentAt)}` : ""}.` : `We sent <strong>${count} ${pluralOffersEN(count)}</strong> to <strong>${esc2(retailerName || "")}</strong>${sentAt ? ` on ${esc2(sentAt)}` : ""}.`;
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Hello,")}
  ${pBlock(intro)}
  ${list}
  ${pBlock("The buyer received the Fresh Market PreConnect batch email. When they open the email or visit the offer list in the panel, we'll mark the submission as delivered and show the billing in your panel.")}
  ${ctaButton("View in panel", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "en" }) };
}
function esc2(s) {
  if (s == null) return "";
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

// netlify/functions/_shared/error-messages.js
var SUPPORTED_LOCALES = ["pl", "en"];
function pickErrLocale(input) {
  if (!input) return "pl";
  const raw = String(input).trim().toLowerCase().split(/[-_]/)[0];
  return SUPPORTED_LOCALES.includes(raw) ? raw : "pl";
}
var MESSAGES = {
  pl: {
    retailer_delivery_unconfirmed: "Poczta przyj\u0119\u0142a wiadomo\u015B\u0107, ale zapis wysy\u0142ki nie zosta\u0142 potwierdzony. Nie wysy\u0142aj ponownie \u2014 najpierw sprawd\u017A dor\u0119czenie z administratorem.",
    // ── Auth / token ──
    no_auth_header: "Brak nag\u0142\xF3wka Authorization",
    no_auth_token: "Brak tokenu autoryzacji",
    invalid_token: "Nieprawid\u0142owy token",
    profile_not_found: "Nie znaleziono profilu u\u017Cytkownika",
    profile_no_role: "Brak profilu u\u017Cytkownika",
    account_inactive: "Konto jest nieaktywne",
    account_inactive_buyer: "Konto kupca jest nieaktywne",
    // ── Role gates ──
    only_admin: "Tylko admin mo\u017Ce wywo\u0142a\u0107 t\u0119 funkcj\u0119.",
    only_admin_create_users: "Tylko admin mo\u017Ce tworzy\u0107 konta B2B",
    only_admin_update_users: "Tylko admin mo\u017Ce aktualizowa\u0107 konta B2B",
    only_admin_reset_password: "Tylko admin mo\u017Ce resetowa\u0107 has\u0142a",
    only_admin_or_supplier: "Tylko admin lub supplier mo\u017Ce wywo\u0142a\u0107.",
    only_buyer_or_admin_mark_seen: "Tylko kupiec lub admin mo\u017Ce oznaczy\u0107 ofert\u0119 jako zobaczon\u0105",
    only_buyer_or_admin_mark_seen_list: "Tylko kupiec lub admin mo\u017Ce oznaczy\u0107 oferty jako zobaczone",
    only_admin_send_batch: "Tylko admin mo\u017Ce wysy\u0142a\u0107 zbiorcze maile do sieci.",
    only_supplier_buy_pkg: "Tylko dostawca mo\u017Ce kupowa\u0107 pakiety",
    only_admin_or_supplier_ai_desc: "Ta funkcja jest dost\u0119pna tylko dla admina lub dostawcy.",
    only_admin_ai_chat: "Ta funkcja jest dost\u0119pna tylko dla administratora.",
    ai_moderation_review_failed: "Nie uda\u0142o si\u0119 przeanalizowa\u0107 propozycji przez AI.",
    no_offer_write_perm: "Brak uprawnie\u0144 do zapisu propozycji",
    // ── Walidacja body ──
    invalid_json: "Niepoprawny JSON",
    missing_email: "Podaj poprawny adres email.",
    missing_email_short: "Brak email",
    missing_password: "Has\u0142o musi mie\u0107 minimum 8 znak\xF3w.",
    missing_company_name: "Podaj nazw\u0119 firmy.",
    company_name_too_long: "Nazwa firmy jest za d\u0142uga.",
    missing_nip: "Podaj NIP firmy. To pole jest wymagane do rejestracji i rozlicze\u0144.",
    invalid_role: "Niepoprawna rola (admin/supplier/buyer)",
    supplier_needs_company: "Supplier wymaga company_id",
    buyer_needs_retailer: "Buyer wymaga retailer_id",
    buyer_needs_name: "Buyer wymaga imienia i nazwiska",
    buyer_needs_name_full: "Kupiec musi mie\u0107 imi\u0119 i nazwisko.",
    buyer_needs_email: "Kupiec musi mie\u0107 adres e-mail.",
    buyer_needs_one_retailer: "Kupiec musi by\u0107 przypisany do jednej sieci handlowej.",
    buyer_needs_category: "Aktywny kupiec musi mie\u0107 przynajmniej jedn\u0105 kategori\u0119.",
    retailer_not_found: "Wybrana sie\u0107 handlowa nie istnieje.",
    retailer_not_found_short: "Sie\u0107 handlowa nie znaleziona.",
    missing_user_id: "Brak user_id",
    missing_send_ids: "send_ids jest puste \u2014 nie ma czego wys\u0142a\u0107.",
    missing_retailer_id: "Brak retailer_id",
    missing_legacy_id: "Brak / nieprawid\u0142owy legacy_id",
    missing_template: "Brak template",
    missing_recipient: "Brak adresata maila.",
    missing_send_id: "Brak sendId",
    missing_offer_id: "Brak ID propozycji",
    missing_supplier_id: "Brak identyfikatora dostawcy",
    missing_plan_id: "Brak plan_id",
    missing_user_password_or_link: "Podaj new_password ALBO send_magic_link=true",
    missing_data_company: "Brak danych firmy do opisu.",
    missing_chat_messages: "Brak wiadomo\u015Bci do analizy.",
    // ── Auth state ──
    email_exists: "Konto z tym adresem email ju\u017C istnieje. Spr\xF3buj zalogowa\u0107 si\u0119 lub odzyska\u0107 has\u0142o.",
    buyer_email_duplicate: "Kupiec z tym adresem e-mail ju\u017C istnieje.",
    user_not_found: "User nie znaleziony",
    target_profile_not_found: "Nie znaleziono profilu kupca do aktualizacji.",
    buyer_only_path: "Ta \u015Bcie\u017Cka s\u0142u\u017Cy tylko do zarz\u0105dzania kupcami.",
    // ── Send batch ──
    no_active_buyers: 'Sie\u0107 {retailerName} nie ma \u017Cadnego aktywnego kupca z e-mailem. Najpierw uzupe\u0142nij Buyer w "Sieci".',
    sends_read_failed: "B\u0142\u0105d odczytu sends: {detail}",
    no_approved_sends: "Brak propozycji gotowych do e-maila \u2014 wszystkie s\u0105 odrzucone, w moderacji, odczytane albo e-mail ju\u017C zosta\u0142 wys\u0142any.",
    // ── Send single ──
    send_not_found: "Wysy\u0142ka nie znaleziona",
    send_bad_status: "Wysy\u0142ka ma status {status} \u2014 nie wysy\u0142am",
    resend_error: "Resend error",
    // ── PayU ──
    no_company_assigned: "Konto nie jest przypisane do firmy. Skontaktuj si\u0119 z administratorem.",
    plan_not_found: "Plan {planId} nie istnieje lub jest nieaktywny",
    payu_order_register_failed: "Nie uda\u0142o si\u0119 zarejestrowa\u0107 zam\xF3wienia: {detail}",
    payu_config_error: "Konfiguracja PayU jest niepoprawna: {detail}",
    payu_currency_rate_missing: "Konfiguracja PayU wymaga kursu przeliczeniowego EUR na {currency}. Ustaw PAYU_EUR_TO_PAYU_RATE albo skonfiguruj POS PayU w EUR.",
    payu_currency_mismatch: "Waluta zam\xF3wienia nie zgadza si\u0119 z walut\u0105 POS PayU. U\u017Cyta konfiguracja: {context}. Por\xF3wnaj POS ID i OAuth client_id z punktem p\u0142atno\u015Bci REST API w PayU.",
    // ── Proforma (przelew) ──
    proforma_nip_required: "Podaj NIP firmy. To pole jest wymagane do rejestracji i rozlicze\u0144.",
    proforma_number_failed: "Nie uda\u0142o si\u0119 nada\u0107 numeru proformy: {detail}",
    proforma_create_failed: "Nie uda\u0142o si\u0119 wygenerowa\u0107 proformy: {detail}",
    payu_api_error: "PayU API: {detail}",
    // ── Misc create / update failures ──
    create_user_failed: "Nie uda\u0142o si\u0119 utworzy\u0107 konta: {detail}",
    create_user_failed_short: "Nie uda\u0142o si\u0119 utworzy\u0107 usera: {detail}",
    create_company_failed: "Nie uda\u0142o si\u0119 utworzy\u0107 firmy: {detail}",
    create_profile_failed: "Nie uda\u0142o si\u0119 utworzy\u0107 profilu: {detail}",
    update_profile_after_auth_failed: "Konto utworzone, ale update profile nie powi\xF3d\u0142 si\u0119: {detail}",
    magic_link_failed: "Magic link nie wygenerowany: {detail}",
    magic_link_failed_warning: "Konto utworzone, magic link nie wygenerowany: {detail}",
    password_update_failed: "Nie uda\u0142o si\u0119 zaktualizowa\u0107 has\u0142a: {detail}",
    auth_update_failed: "Nie uda\u0142o si\u0119 zaktualizowa\u0107 auth.users: {detail}",
    profile_after_auth_update_failed: "Auth zaktualizowany, ale profil nie: {detail}",
    duplicate_check_failed: "Nie uda\u0142o si\u0119 sprawdzi\u0107 duplikat\xF3w kupc\xF3w.",
    unknown_template: "Nieznany template: {template}",
    legacy_supplier_id_backfill_failed: "Nie uda\u0142o si\u0119 przygotowa\u0107 identyfikatora dostawcy: {detail}",
    own_company_only_ai_desc: "Dostawca mo\u017Ce generowa\u0107 opis tylko dla swojej firmy.",
    method_not_allowed: "Method Not Allowed"
  },
  en: {
    retailer_delivery_unconfirmed: "The email provider accepted the message, but its delivery record is unconfirmed. Do not resend; check delivery with the administrator first.",
    // ── Auth / token ──
    no_auth_header: "Authorization header missing",
    no_auth_token: "Authorization token missing",
    invalid_token: "Invalid token",
    profile_not_found: "User profile not found",
    profile_no_role: "User profile not found",
    account_inactive: "Account is inactive",
    account_inactive_buyer: "Buyer account is inactive",
    // ── Role gates ──
    only_admin: "Only an administrator can call this function.",
    only_admin_create_users: "Only an administrator can create B2B accounts",
    only_admin_update_users: "Only an administrator can update B2B accounts",
    only_admin_reset_password: "Only an administrator can reset passwords",
    only_admin_or_supplier: "Only an administrator or supplier can call this function.",
    only_buyer_or_admin_mark_seen: "Only a buyer or administrator can mark a submission as seen",
    only_buyer_or_admin_mark_seen_list: "Only a buyer or administrator can mark submissions as seen",
    only_admin_send_batch: "Only an administrator can send batch emails to retailers.",
    only_supplier_buy_pkg: "Only a supplier can purchase packages",
    only_admin_or_supplier_ai_desc: "This function is available only to administrators or suppliers.",
    only_admin_ai_chat: "This function is available only to administrators.",
    ai_moderation_review_failed: "Could not analyse the submission with AI.",
    no_offer_write_perm: "No permission to write submission",
    // ── Walidacja body ──
    invalid_json: "Invalid JSON",
    missing_email: "Provide a valid email address.",
    missing_email_short: "Email missing",
    missing_password: "Password must be at least 8 characters.",
    missing_company_name: "Provide a company name.",
    company_name_too_long: "Company name is too long.",
    missing_nip: "Provide the company Tax ID. This field is required for registration and billing.",
    invalid_role: "Invalid role (admin/supplier/buyer)",
    supplier_needs_company: "Supplier requires company_id",
    buyer_needs_retailer: "Buyer requires retailer_id",
    buyer_needs_name: "Buyer requires a first and last name",
    buyer_needs_name_full: "Buyer must have a first and last name.",
    buyer_needs_email: "Buyer must have an email address.",
    buyer_needs_one_retailer: "Buyer must be assigned to one retailer.",
    buyer_needs_category: "An active buyer must have at least one category.",
    retailer_not_found: "Selected retailer does not exist.",
    retailer_not_found_short: "Retailer not found.",
    missing_user_id: "user_id missing",
    missing_send_ids: "send_ids is empty \u2014 nothing to send.",
    missing_retailer_id: "retailer_id missing",
    missing_legacy_id: "Missing / invalid legacy_id",
    missing_template: "template missing",
    missing_recipient: "No email recipient.",
    missing_send_id: "sendId missing",
    missing_offer_id: "Submission ID missing",
    missing_supplier_id: "Supplier identifier missing",
    missing_plan_id: "plan_id missing",
    missing_user_password_or_link: "Provide new_password OR send_magic_link=true",
    missing_data_company: "No company data to describe.",
    missing_chat_messages: "No messages to analyse.",
    // ── Auth state ──
    email_exists: "An account with this email already exists. Try signing in or recovering the password.",
    buyer_email_duplicate: "A buyer with this email already exists.",
    user_not_found: "User not found",
    target_profile_not_found: "Buyer profile to update not found.",
    buyer_only_path: "This path is only for buyer management.",
    // ── Send batch ──
    no_active_buyers: 'Retailer {retailerName} has no active buyer with an email. Add a Buyer in "Retailers" first.',
    sends_read_failed: "Sends read error: {detail}",
    no_approved_sends: "No submissions ready for email \u2014 all are rejected, in moderation, already read, or email was already sent.",
    // ── Send single ──
    send_not_found: "Send not found",
    send_bad_status: "Send has status {status} \u2014 not sending",
    resend_error: "Resend error",
    // ── PayU ──
    no_company_assigned: "Account is not assigned to a company. Contact the administrator.",
    plan_not_found: "Plan {planId} does not exist or is inactive",
    payu_order_register_failed: "Could not register the order: {detail}",
    payu_config_error: "PayU configuration is invalid: {detail}",
    payu_currency_rate_missing: "PayU configuration requires an EUR to {currency} conversion rate. Set PAYU_EUR_TO_PAYU_RATE or configure the PayU POS in EUR.",
    payu_currency_mismatch: "The order currency does not match the PayU POS currency. Used configuration: {context}. Compare POS ID and OAuth client_id with the REST API payment point in PayU.",
    // ── Proforma (bank transfer) ──
    proforma_nip_required: "Provide the company Tax ID. This field is required for registration and billing.",
    proforma_number_failed: "Could not assign a proforma number: {detail}",
    proforma_create_failed: "Could not generate the proforma: {detail}",
    payu_api_error: "PayU API: {detail}",
    // ── Misc create / update failures ──
    create_user_failed: "Could not create the account: {detail}",
    create_user_failed_short: "Could not create the user: {detail}",
    create_company_failed: "Could not create the company: {detail}",
    create_profile_failed: "Could not create the profile: {detail}",
    update_profile_after_auth_failed: "Account created, but profile update failed: {detail}",
    magic_link_failed: "Magic link not generated: {detail}",
    magic_link_failed_warning: "Account created, magic link not generated: {detail}",
    password_update_failed: "Could not update the password: {detail}",
    auth_update_failed: "Could not update auth.users: {detail}",
    profile_after_auth_update_failed: "Auth updated, but profile did not: {detail}",
    duplicate_check_failed: "Could not check buyer duplicates.",
    unknown_template: "Unknown template: {template}",
    legacy_supplier_id_backfill_failed: "Could not prepare supplier identifier: {detail}",
    own_company_only_ai_desc: "Supplier can generate description only for their own company.",
    method_not_allowed: "Method Not Allowed"
  }
};
function errLoc(locale, key, params = {}) {
  const lng = pickErrLocale(locale);
  const lookup = MESSAGES[lng]?.[key] || MESSAGES.pl[key] || key;
  let msg = lookup;
  for (const [k, v] of Object.entries(params || {})) {
    msg = msg.split(`{${k}}`).join(String(v ?? ""));
  }
  return msg;
}
function resolveLocale({ bodyLocale, profileLocale, acceptLanguage } = {}) {
  if (bodyLocale) return pickErrLocale(bodyLocale);
  if (profileLocale) return pickErrLocale(profileLocale);
  if (acceptLanguage) return pickErrLocale(String(acceptLanguage).split(",")[0]);
  return "pl";
}

// netlify/functions/send-retailer-batch.js
var cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function hasRetailerEmailMarker(row) {
  const data = row?.data || {};
  const messageIds = data.resendMessageIds || [];
  const buyerCount = Number(data.resendBuyerCount || 0) || (Array.isArray(data.resendBuyerEmails) ? data.resendBuyerEmails.length : 0);
  return Boolean(
    row?.resend_message_id || data.resendMessageId || data.resend_message_id || data.emailSentAt || data.email_sent_at || Array.isArray(messageIds) && messageIds.length || buyerCount > 0
  );
}
async function getBrandLogoUrl(supaSvc) {
  try {
    const { data } = await supaSvc.from("fm_settings").select("brand_logo_url").order("updated_at", { ascending: false }).limit(1).maybeSingle();
    return data?.brand_logo_url || null;
  } catch {
    return null;
  }
}
async function buildMagicLinksByLegacyId({ supaSvc, buyer, sends, appUrl }) {
  const links = /* @__PURE__ */ new Map();
  const email = String(buyer?.email || "").trim();
  if (!email || !email.includes("@")) return links;
  for (const s of sends || []) {
    const legacyId = s?.legacy_id || s?.data?.id;
    if (!legacyId) continue;
    const redirectTo = `${appUrl}/kupiec?send=${encodeURIComponent(String(legacyId))}`;
    try {
      const { data, error } = await supaSvc.auth.admin.generateLink({
        type: "magiclink",
        email,
        options: { redirectTo }
      });
      if (!error && data?.properties?.action_link) {
        links.set(String(legacyId), data.properties.action_link);
      }
    } catch (e) {
      console.warn("[retailer_batch_magic_link]", email, legacyId, e?.message || e);
    }
  }
  return links;
}
async function handler(request) {
  const acceptLang = request.headers.get("accept-language");
  let adminLocale = resolveLocale({ acceptLanguage: acceptLang });
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (request.method !== "POST") return json(405, { error: errLoc(adminLocale, "method_not_allowed") });
  const env = resolveEnvConfig();
  const required = ["supabaseUrl", "supabaseAnonKey", "supabaseServiceRoleKey", "resendApiKey"];
  const missing = missingEnvNames(env, required);
  if (missing.length) return json(500, envErrorPayload("send-retailer-batch", missing));
  const authHeader = request.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return json(401, { error: errLoc(adminLocale, "no_auth_header") });
  const token = authHeader.slice(7);
  const supaUser = createClient(env.supabaseUrl, env.supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } }
  });
  const { data: userData, error: userErr } = await supaUser.auth.getUser(token);
  if (userErr || !userData?.user) return json(401, { error: errLoc(adminLocale, "invalid_token") });
  const supaSvc = createClient(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: caller, error: callerErr } = await supaSvc.from("profiles").select("id, role, name, email, locale, active").eq("id", userData.user.id).maybeSingle();
  if (callerErr || !caller) return json(403, { error: errLoc(adminLocale, "profile_not_found") });
  if (caller.role !== "admin" || caller.active === false) {
    return json(403, { error: errLoc(adminLocale, "only_admin_send_batch") });
  }
  adminLocale = resolveLocale({ profileLocale: caller.locale, acceptLanguage: acceptLang });
  let body;
  try {
    body = await request.json();
  } catch {
    return json(400, { error: errLoc(adminLocale, "invalid_json") });
  }
  adminLocale = resolveLocale({ bodyLocale: body.locale, profileLocale: caller.locale, acceptLanguage: acceptLang });
  const retailerId = Number(body.retailer_id);
  const sendIds = Array.isArray(body.send_ids) ? body.send_ids.map(Number).filter(Number.isFinite) : [];
  const dryRun = !!body.dry_run;
  if (!retailerId) return json(400, { error: errLoc(adminLocale, "missing_retailer_id") });
  if (!sendIds.length) return json(400, { error: errLoc(adminLocale, "missing_send_ids") });
  const { data: retailer, error: retErr } = await supaSvc.from("retailers").select(`id, name, country, color, bg, logo_url,
             buyers:profiles!fk_profiles_retailer(id, role, name, email, active, fm26_active, locale)`).eq("id", retailerId).maybeSingle();
  if (retErr || !retailer) return json(404, { error: errLoc(adminLocale, "retailer_not_found_short") });
  const activeBuyers = (retailer.buyers || []).filter(
    (b) => b && (b.role == null || b.role === "buyer") && b.active !== false && b.email && b.email.includes("@")
  );
  if (!activeBuyers.length) {
    return json(400, {
      error: errLoc(adminLocale, "no_active_buyers", { retailerName: retailer.name })
    });
  }
  const { data: sendsRaw, error: sendsErr } = await supaSvc.from("legacy_sends").select("legacy_id, retailer_id, status, resend_message_id, data").in("legacy_id", sendIds);
  if (sendsErr) return json(500, { error: errLoc(adminLocale, "sends_read_failed", { detail: sendsErr.message }) });
  const eligible = (sendsRaw || []).filter(
    (s) => Number(s.retailer_id) === retailerId && ["approved", "sent"].includes(s.status) && !hasRetailerEmailMarker(s)
  );
  const skipped = (sendsRaw || []).filter((s) => !eligible.includes(s));
  if (!eligible.length) {
    return json(400, {
      error: errLoc(adminLocale, "no_approved_sends"),
      skipped_statuses: skipped.map((s) => ({ legacy_id: s.legacy_id, status: hasRetailerEmailMarker(s) ? "email_sent" : s.status }))
    });
  }
  const offerIds = [...new Set(eligible.map((s) => (s.data || {}).offerId).filter((x) => x != null))];
  const offersMap = /* @__PURE__ */ new Map();
  if (offerIds.length) {
    const { data: offerRows } = await supaSvc.from("legacy_offers").select("legacy_id, data").in("legacy_id", offerIds);
    for (const row of offerRows || []) {
      offersMap.set(row.legacy_id, row.data || {});
    }
  }
  const supplierKeys = [...new Set(eligible.map((s) => (s.data || {}).supplierId).filter(Boolean))];
  const companiesMap = /* @__PURE__ */ new Map();
  if (supplierKeys.length) {
    const { data: byLegacy } = await supaSvc.from("companies").select("id, legacy_supplier_id, legacy_fm_id, name, country, logo_url, description_short, description_short_en, description").in("legacy_supplier_id", supplierKeys);
    for (const co of byLegacy || []) {
      if (co.legacy_supplier_id) companiesMap.set(co.legacy_supplier_id, co);
      if (co.id) companiesMap.set(co.id, co);
    }
    const unresolvedKeys = supplierKeys.filter((k) => !companiesMap.has(k));
    const uuidKeys = unresolvedKeys.filter((k) => typeof k === "string" && k.length === 36);
    if (uuidKeys.length) {
      const { data: byUuid } = await supaSvc.from("companies").select("id, legacy_supplier_id, legacy_fm_id, name, country, logo_url, description_short, description_short_en, description").in("id", uuidKeys);
      for (const co of byUuid || []) {
        companiesMap.set(co.id, co);
        if (co.legacy_supplier_id) companiesMap.set(co.legacy_supplier_id, co);
      }
    }
  }
  const brandLogoUrl = await getBrandLogoUrl(supaSvc);
  const renderedByLocale = /* @__PURE__ */ new Map();
  const pickRender = (lng) => {
    if (renderedByLocale.has(lng)) return renderedByLocale.get(lng);
    const month = monthLabel(lng);
    const r = renderRetailerEmail({
      retailer,
      sends: eligible,
      offers: offersMap,
      companies: companiesMap,
      buyerCount: activeBuyers.length,
      month,
      appUrl: env.b2bAppUrl,
      locale: lng,
      brandLogoUrl
    });
    renderedByLocale.set(lng, { ...r, month });
    return renderedByLocale.get(lng);
  };
  if (dryRun) {
    const previewLocale = activeBuyers.some((b) => (b.locale || "pl").toLowerCase().startsWith("en")) ? "en" : "pl";
    const { html, subject } = pickRender(previewLocale);
    return json(200, {
      ok: true,
      dry_run: true,
      subject,
      preview_locale: previewLocale,
      offer_count: eligible.length,
      buyer_count: activeBuyers.length,
      buyers: activeBuyers.map((b) => ({ name: b.name, email: b.email, locale: b.locale || "pl" })),
      html_preview: html.slice(0, 3e3)
    });
  }
  const resendResults = [];
  for (const buyer of activeBuyers) {
    const buyerLocale = (buyer.locale || "pl").toLowerCase().startsWith("en") ? "en" : "pl";
    const month = monthLabel(buyerLocale);
    const magicLinksByLegacyId = await buildMagicLinksByLegacyId({
      supaSvc,
      buyer,
      sends: eligible,
      appUrl: env.b2bAppUrl
    });
    const { html, subject } = renderRetailerEmail({
      retailer,
      sends: eligible,
      offers: offersMap,
      companies: companiesMap,
      buyerCount: activeBuyers.length,
      month,
      appUrl: env.b2bAppUrl,
      locale: buyerLocale,
      brandLogoUrl,
      magicLinksByLegacyId
    });
    if (!renderedByLocale.has(buyerLocale)) {
      renderedByLocale.set(buyerLocale, { html, subject, month });
    }
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${env.resendApiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          from: "Fresh Market <newsletter@freshmarket.eu>",
          to: [buyer.email],
          subject,
          html
        })
      });
      if (!res.ok) {
        const detail = await res.text();
        resendResults.push({ buyer: buyer.email, locale: buyerLocale, ok: false, status: res.status, detail });
      } else {
        const r = await res.json().catch(() => ({}));
        resendResults.push({ buyer: buyer.email, locale: buyerLocale, ok: Boolean(r.id), message_id: r.id || null });
      }
    } catch (e) {
      resendResults.push({ buyer: buyer.email, locale: buyerLocale, ok: false, status: 0, detail: e?.message || String(e) });
    }
  }
  const anySent = resendResults.some((r) => r.ok);
  let markedSendIds = [];
  const successfulMessageIds = resendResults.filter((r) => r.ok && r.message_id).map((r) => r.message_id);
  const firstSuccessfulMessageId = successfulMessageIds[0] || null;
  if (anySent) {
    const sentAtIso = (/* @__PURE__ */ new Date()).toISOString();
    const sentAtDate = sentAtIso.slice(0, 10);
    let persisted;
    try {
      persisted = await supaSvc.rpc("mark_legacy_sends_retailer_emailed", {
        p_send_ids: eligible.map((s) => s.legacy_id),
        p_retailer_id: retailerId,
        p_message_ids: successfulMessageIds,
        p_buyer_count: resendResults.filter((r) => r.ok).length,
        p_sent_at: sentAtIso
      });
    } catch (error) {
      persisted = { error };
    }
    if (persisted.error || !Array.isArray(persisted.data) || persisted.data.length !== eligible.length) {
      return json(502, {
        ok: false,
        delivery_uncertain: true,
        send_ids_marked: [],
        error: errLoc(adminLocale, "retailer_delivery_unconfirmed")
      });
    }
    markedSendIds = persisted.data;
    const supplierEmailsByCompanyId = /* @__PURE__ */ new Map();
    const supplierIdToCompanyId = /* @__PURE__ */ new Map();
    for (const co of companiesMap.values()) {
      if (co?.id && !supplierEmailsByCompanyId.has(co.id)) {
        supplierEmailsByCompanyId.set(co.id, null);
        supplierIdToCompanyId.set(co.legacy_supplier_id, co.id);
        supplierIdToCompanyId.set(co.id, co.id);
      }
    }
    if (supplierEmailsByCompanyId.size) {
      const companyIds = [...supplierEmailsByCompanyId.keys()];
      const { data: ownerProfiles } = await supaSvc.from("profiles").select("name, email, role, active, company_id, locale").in("company_id", companyIds).eq("role", "supplier");
      for (const p of ownerProfiles || []) {
        if (p.active && p.email && !supplierEmailsByCompanyId.get(p.company_id)) {
          supplierEmailsByCompanyId.set(p.company_id, p);
        }
      }
      const groupsByCompanyId = /* @__PURE__ */ new Map();
      for (const s of eligible) {
        const supplierKey = (s.data || {}).supplierId;
        const companyId = supplierIdToCompanyId.get(supplierKey);
        const owner = companyId ? supplierEmailsByCompanyId.get(companyId) : null;
        if (!owner?.email) continue;
        const offer = offersMap.get((s.data || {}).offerId) || {};
        const co = companiesMap.get(supplierKey) || companiesMap.get(companyId) || {};
        if (!groupsByCompanyId.has(companyId)) {
          groupsByCompanyId.set(companyId, {
            owner,
            company: co,
            offers: []
          });
        }
        groupsByCompanyId.get(companyId).offers.push({
          title: offer.title || offer.product || `Oferta`
        });
      }
      for (const group of groupsByCompanyId.values()) {
        const tpl = tplOffersSentToRetailer({
          companyName: group.company?.name || "",
          contactName: group.owner.name || null,
          offers: group.offers,
          offerCount: group.offers.length,
          retailerName: retailer.name || "",
          sentAt: sentAtDate,
          appUrl: env.b2bAppUrl,
          // [P2-backend-mails C2] Supplier sees notification in their language.
          locale: group.owner.locale || "pl"
        });
        try {
          await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: { Authorization: `Bearer ${env.resendApiKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({
              from: "Fresh Market <newsletter@freshmarket.eu>",
              to: [group.owner.email],
              subject: tpl.subject,
              html: tpl.html
            })
          });
        } catch (e) {
          console.warn("[email_supplier_offer_sent]", group.owner.email, e?.message || e);
        }
      }
    }
  }
  const subjectByLocale = Object.fromEntries(
    [...renderedByLocale.entries()].map(([lng, rendered]) => [lng, rendered.subject])
  );
  const firstRendered = renderedByLocale.values().next().value || pickRender("pl");
  return json(200, {
    ok: anySent,
    sent_count: markedSendIds.length,
    buyer_count: activeBuyers.length,
    buyers_succeeded: resendResults.filter((r) => r.ok).map((r) => r.buyer),
    buyers_failed: resendResults.filter((r) => !r.ok),
    send_ids_marked: markedSendIds,
    skipped: skipped.map((s) => ({ legacy_id: s.legacy_id, status: s.status })),
    subject: firstRendered.subject,
    subjects_by_locale: subjectByLocale
  });
}
function monthLabel(locale = "pl") {
  const monthsPL = ["Stycze\u0144", "Luty", "Marzec", "Kwiecie\u0144", "Maj", "Czerwiec", "Lipiec", "Sierpie\u0144", "Wrzesie\u0144", "Pa\u017Adziernik", "Listopad", "Grudzie\u0144"];
  const monthsEN = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const months = locale === "en" ? monthsEN : monthsPL;
  const d = /* @__PURE__ */ new Date();
  return `${months[d.getMonth()]} ${d.getFullYear()}`;
}
function json(statusCode, payload) {
  return new Response(JSON.stringify(payload), {
    status: statusCode,
    headers: { ...cors, "Content-Type": "application/json" }
  });
}
export {
  handler as default
};
