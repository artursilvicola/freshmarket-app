var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var upsert_legacy_offer_exports = {};
__export(upsert_legacy_offer_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(upsert_legacy_offer_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_error_messages = require("./_shared/error-messages.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod !== "POST") return json(405, { error: (0, import_error_messages.errLoc)(locale, "method_not_allowed") });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("upsert-legacy-offer", missing));
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return json(401, { error: (0, import_error_messages.errLoc)(locale, "no_auth_token") });
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "invalid_json") });
  }
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, acceptLanguage: acceptLang });
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: userData, error: userErr } = await supaSvc.auth.getUser(token);
  if (userErr || !userData?.user) return json(401, { error: (0, import_error_messages.errLoc)(locale, "invalid_token") });
  const { data: profile, error: profileErr } = await supaSvc.from("profiles").select("id, role, company_id, locale, company:companies!company_id(id, legacy_supplier_id)").eq("id", userData.user.id).maybeSingle();
  if (profileErr || !profile) return json(403, { error: (0, import_error_messages.errLoc)(locale, "profile_no_role") });
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, profileLocale: profile.locale, acceptLanguage: acceptLang });
  const input = body.offer || {};
  if (!input.id) return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_offer_id") });
  let offer = { ...input };
  if (profile.role === "supplier") {
    if (!profile.company_id) return json(403, { error: (0, import_error_messages.errLoc)(locale, "no_company_assigned") });
    const supplierKey = profile.company?.legacy_supplier_id || profile.company_id;
    if (!profile.company?.legacy_supplier_id) {
      const { error: backfillErr } = await supaSvc.from("companies").update({ legacy_supplier_id: supplierKey }).eq("id", profile.company_id);
      if (backfillErr) return json(500, { error: (0, import_error_messages.errLoc)(locale, "legacy_supplier_id_backfill_failed", { detail: backfillErr.message }) });
    }
    offer.supplierId = supplierKey;
  } else if (profile.role !== "admin") {
    return json(403, { error: (0, import_error_messages.errLoc)(locale, "no_offer_write_perm") });
  } else if (!offer.supplierId) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_supplier_id") });
  }
  const row = {
    legacy_id: offer.id,
    supplier_legacy_id: offer.supplierId,
    status: offer.status || null,
    category: offer.category || null,
    origin: offer.origin || null,
    data: offer
  };
  const { error } = await supaSvc.from("legacy_offers").upsert(row, { onConflict: "legacy_id" });
  if (error) return json(500, { error: error.message });
  return json(200, { offer });
};
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
