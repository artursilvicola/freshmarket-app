var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var create_payu_order_exports = {};
__export(create_payu_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_payu_order_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_node_crypto = require("node:crypto");
var import_function_env = require("./_shared/function-env.js");
var import_payu = require("./_shared/payu.js");
var import_error_messages = require("./_shared/error-messages.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return json(405, { error: (0, import_error_messages.errLoc)(locale, "method_not_allowed") });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, [
    "supabaseUrl",
    "supabaseServiceRoleKey",
    "payuPosId",
    "payuClientId",
    "payuClientSecret",
    "payuCurrencyCode"
  ]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("create-payu-order", missing));
  let payuCurrencyCode;
  try {
    payuCurrencyCode = (0, import_payu.normalizePayuCurrencyCode)(env.payuCurrencyCode);
  } catch (e) {
    return json(500, { error: (0, import_error_messages.errLoc)(locale, "payu_config_error", { detail: e?.message || String(e) }) });
  }
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return json(401, { error: (0, import_error_messages.errLoc)(locale, "no_auth_token") });
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: userData, error: userErr } = await supaSvc.auth.getUser(token);
  if (userErr || !userData?.user) {
    return json(401, { error: (0, import_error_messages.errLoc)(locale, "invalid_token") });
  }
  const userId = userData.user.id;
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "invalid_json") });
  }
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, acceptLanguage: acceptLang });
  const planId = String(body.plan_id || "").trim();
  if (!planId) return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_plan_id") });
  const { data: profile, error: profErr } = await supaSvc.from("profiles").select("id, email, name, role, company_id, locale, company:companies!company_id(id, name)").eq("id", userId).maybeSingle();
  if (profErr || !profile) return json(403, { error: (0, import_error_messages.errLoc)(locale, "profile_not_found") });
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, profileLocale: profile.locale, acceptLanguage: acceptLang });
  if (profile.role !== "supplier" && profile.role !== "admin") {
    return json(403, { error: (0, import_error_messages.errLoc)(locale, "only_supplier_buy_pkg") });
  }
  const companyId = profile.company_id;
  if (!companyId) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "no_company_assigned") });
  }
  const { data: plan, error: planErr } = await supaSvc.from("package_plans").select("*").eq("id", planId).eq("active", true).maybeSingle();
  if (planErr || !plan) return json(400, { error: (0, import_error_messages.errLoc)(locale, "plan_not_found", { planId }) });
  const extOrderId = (0, import_node_crypto.randomUUID)();
  const priceNetEur = roundMoney(Number(plan.price_eur));
  const vatRate = (0, import_payu.parsePositiveNumber)(env.payuVatRate, 23);
  const grossEur = roundMoney(priceNetEur * (1 + vatRate / 100));
  const eurToPayuRate = payuCurrencyCode === "EUR" ? 1 : (0, import_payu.parsePositiveNumber)(env.payuEurToPayuRate, null);
  if (payuCurrencyCode !== "EUR" && !eurToPayuRate) {
    return json(500, {
      error: (0, import_error_messages.errLoc)(locale, "payu_currency_rate_missing", { currency: payuCurrencyCode })
    });
  }
  const payuGrossAmount = roundMoney(grossEur * eurToPayuRate);
  const totalAmountMinor = (0, import_payu.toMinorUnits)(payuGrossAmount, payuCurrencyCode);
  const { data: orderRow, error: orderErr } = await supaSvc.from("payu_orders").insert({
    company_id: companyId,
    plan_id: plan.id,
    price_eur: priceNetEur,
    currency: "EUR",
    status: "created",
    ext_order_id: extOrderId
  }).select().single();
  if (orderErr) {
    return json(500, { error: (0, import_error_messages.errLoc)(locale, "payu_order_register_failed", { detail: orderErr.message }) });
  }
  const baseUrl = (0, import_payu.payuBaseUrl)(env.payuEnv);
  const notifyUrl = `${env.b2bAppUrl}/.netlify/functions/payu-notify`;
  const continueUrl = `${env.b2bAppUrl}/zakup-ok?ext=${extOrderId}`;
  const payuDescription = locale === "en" ? `${plan.tier} ${plan.qty} submissions package (Fresh Market)` : `Pakiet ${plan.tier} ${plan.qty} wysy\u0142ek (Fresh Market)`;
  const payuProductName = locale === "en" ? `${plan.tier} ${plan.qty} submissions` : `${plan.tier} ${plan.qty} wysy\u0142ek`;
  const fallbackFirstName = locale === "en" ? "Customer" : "Klient";
  let payuResult;
  try {
    const accessToken = await (0, import_payu.fetchPayuToken)({
      baseUrl,
      clientId: env.payuClientId,
      clientSecret: env.payuClientSecret
    });
    payuResult = await (0, import_payu.createPayuOrder)({
      baseUrl,
      accessToken,
      posId: env.payuPosId,
      customerIp: event.headers["x-forwarded-for"]?.split(",")[0]?.trim() || "127.0.0.1",
      description: payuDescription,
      currencyCode: payuCurrencyCode,
      totalAmount: totalAmountMinor,
      extOrderId,
      buyer: {
        email: profile.email,
        firstName: (profile.name || "").split(" ")[0] || fallbackFirstName,
        lastName: (profile.name || "").split(" ").slice(1).join(" ") || "FM",
        // [P2-backend-mails C3] PayU `language` controls checkout UI lang.
        // pl|en supported; fallback pl.
        language: locale === "en" ? "en" : "pl"
      },
      products: [{
        name: payuProductName,
        unitPrice: totalAmountMinor,
        quantity: "1"
      }],
      notifyUrl,
      continueUrl,
      metadata: {
        accountingCurrency: "EUR",
        netEur: priceNetEur,
        vatRate,
        grossEur,
        payuCurrencyCode,
        eurToPayuRate,
        payuGrossAmount,
        totalAmountMinor
      }
    });
  } catch (e) {
    const statusCode = (0, import_payu.parsePayuStatusCode)(e);
    const debugContext = payuDebugContext(env, payuCurrencyCode);
    const userMessage = statusCode === "ERROR_INCONSISTENT_CURRENCIES" ? (0, import_error_messages.errLoc)(locale, "payu_currency_mismatch", { currency: payuCurrencyCode, context: debugContext }) : (0, import_error_messages.errLoc)(locale, "payu_api_error", { detail: e?.message || "unknown" });
    console.error("[create-payu-order] PayU error", {
      statusCode,
      message: e?.message || String(e),
      payu: debugContext,
      extOrderId,
      planId: plan.id,
      amount: { netEur: priceNetEur, grossEur, payuCurrencyCode, totalAmountMinor }
    });
    await supaSvc.from("payu_orders").update({
      status: "failed",
      failure_reason: `${e?.message || String(e)} | ${debugContext}`
    }).eq("id", orderRow.id);
    return json(502, { error: userMessage });
  }
  await supaSvc.from("payu_orders").update({
    payu_order_id: payuResult.orderId,
    status: "pending",
    raw_create: payuResult.raw
  }).eq("id", orderRow.id);
  return json(200, {
    redirectUri: payuResult.redirectUri,
    ext_order_id: extOrderId,
    payu_order_id: payuResult.orderId
  });
};
function roundMoney(value) {
  return Math.round(Number(value || 0) * 100) / 100;
}
function payuDebugContext(env, currencyCode) {
  return [
    `env=${String(env.payuEnv || "sandbox")}`,
    `currency=${currencyCode}`,
    `pos=${maskValue(env.payuPosId)}`,
    `client=${maskValue(env.payuClientId)}`
  ].join(", ");
}
function maskValue(value) {
  const str = String(value || "");
  if (!str) return "(brak)";
  if (str.length <= 4) return "***";
  return `***${str.slice(-4)}`;
}
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
