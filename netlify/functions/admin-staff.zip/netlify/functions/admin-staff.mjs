
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-staff.js
import { createClient } from "@supabase/supabase-js";

// netlify/functions/_shared/netlify-modern.js
function getEnv(name) {
  try {
    const v = globalThis.Netlify?.env?.get?.(name);
    if (v != null && v !== "") return v;
  } catch {
  }
  return process.env[name] ?? "";
}
function envConfig() {
  const first = (...keys) => keys.map(getEnv).find(Boolean) || "";
  return {
    supabaseUrl: first("SUPABASE_URL", "VITE_SUPABASE_URL"),
    supabaseAnonKey: first("SUPABASE_ANON_KEY", "VITE_SUPABASE_ANON_KEY"),
    supabaseServiceRoleKey: first("SUPABASE_SERVICE_ROLE_KEY"),
    staffPinPepper: first("STAFF_PIN_PEPPER")
  };
}
function missingOf(cfg, keys) {
  return keys.filter((k) => !cfg[k]);
}
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, Accept-Language",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
function json(status, body, extra = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...extra }
  });
}
async function readJson(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}
function bearer(request) {
  const h = request.headers.get("authorization") || "";
  return h.startsWith("Bearer ") ? h.slice(7) : null;
}

// netlify/functions/_shared/staff-auth.js
import { createHmac, randomInt } from "node:crypto";
var STAFF_EMAIL_DOMAIN = "obsluga.freshmarket.eu";
function normalizeStaffCode(raw) {
  return String(raw || "").trim().toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 32);
}
function staffEmailFor(code) {
  return `${normalizeStaffCode(code).toLowerCase()}@${STAFF_EMAIL_DOMAIN}`;
}
function generatePin() {
  for (; ; ) {
    const s = String(randomInt(0, 1e6)).padStart(6, "0");
    if (/^(\d)\1{5}$/.test(s)) continue;
    if ("0123456789".includes(s) || "9876543210".includes(s)) continue;
    if (/^(\d\d)\1\1$/.test(s)) continue;
    return s;
  }
}
function staffPassword(pepper, code, pin) {
  return createHmac("sha256", pepper).update(`${normalizeStaffCode(code)}:${pin}`).digest("base64url");
}

// netlify/functions/admin-staff.js
var admin_staff_default = async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (request.method !== "POST") return json(405, { error: "Method not allowed" });
  const cfg = envConfig();
  const missing = missingOf(cfg, ["supabaseUrl", "supabaseServiceRoleKey", "supabaseAnonKey"]);
  if (missing.length) return json(500, { error: `Brak konfiguracji: ${missing.join(", ")}` });
  if (!cfg.staffPinPepper || cfg.staffPinPepper.length < 32) return json(500, { error: "Brak konfiguracji STAFF_PIN_PEPPER (Netlify env, min. 32 znaki)." });
  const token = bearer(request);
  if (!token) return json(401, { error: "Brak nag\u0142\xF3wka Authorization" });
  const supaUser = createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data: userData, error: uErr } = await supaUser.auth.getUser(token);
  if (uErr || !userData?.user) return json(401, { error: "Nieprawid\u0142owy token" });
  const svc = createClient(cfg.supabaseUrl, cfg.supabaseServiceRoleKey, { auth: { persistSession: false } });
  const { data: caller } = await svc.from("profiles").select("role, admin_level").eq("id", userData.user.id).maybeSingle();
  if (caller?.role !== "admin" || caller?.admin_level !== "super") return json(403, { error: "Kontami obs\u0142ugi zarz\u0105dza tylko super administrator." });
  const body = await readJson(request);
  if (!body) return json(400, { error: "Niepoprawny JSON" });
  const action = String(body.action || "");
  if (action === "create") {
    const code = normalizeStaffCode(body.code);
    const eventDate = String(body.event_date || "").slice(0, 10);
    const displayName = String(body.display_name || "").trim().slice(0, 80) || null;
    if (!code || code.length < 3) return json(400, { error: "Kod operatora: min. 3 znaki (litery, cyfry, my\u015Blnik)." });
    if (!/^\d{4}-\d{2}-\d{2}$/.test(eventDate)) return json(400, { error: "Podaj dat\u0119 eventu (YYYY-MM-DD)." });
    const { data: exists } = await svc.from("fm_staff").select("id").eq("code", code).maybeSingle();
    if (exists) return json(409, { error: `Kod ${code} ju\u017C istnieje.` });
    const pin = generatePin();
    const { data: created, error: cErr } = await svc.auth.admin.createUser({
      email: staffEmailFor(code),
      password: staffPassword(cfg.staffPinPepper, code, pin),
      email_confirm: true,
      app_metadata: { role: "staff", staff_code: code },
      // rola uprzywilejowana TYLKO tędy
      user_metadata: { staff_code: code }
    });
    if (cErr || !created?.user) return json(500, { error: `Nie uda\u0142o si\u0119 utworzy\u0107 konta: ${cErr?.message || "?"}` });
    const uid = created.user.id;
    const { error: pErr } = await svc.from("profiles").upsert({ id: uid, email: staffEmailFor(code), role: "staff", name: displayName || code }, { onConflict: "id" });
    const { error: sErr } = pErr ? { error: pErr } : await svc.from("fm_staff").insert({
      id: uid,
      code,
      display_name: displayName,
      event_date: eventDate,
      pin_rotated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (sErr) {
      await svc.auth.admin.deleteUser(uid).catch(() => {
      });
      return json(500, { error: `Nie uda\u0142o si\u0119 zapisa\u0107 obs\u0142ugi: ${sErr.message}` });
    }
    return json(200, { id: uid, code, pin });
  }
  const id = String(body.id || "");
  if (!/^[0-9a-f-]{36}$/i.test(id)) return json(400, { error: "Brak id konta obs\u0142ugi." });
  const { data: staff } = await svc.from("fm_staff").select("id, code, blocked").eq("id", id).maybeSingle();
  if (!staff) return json(404, { error: "Nie znaleziono konta obs\u0142ugi." });
  if (action === "reset_pin") {
    const pin = generatePin();
    const { error } = await svc.auth.admin.updateUserById(id, { password: staffPassword(cfg.staffPinPepper, staff.code, pin) });
    if (error) return json(500, { error: `Reset PIN nieudany: ${error.message}` });
    const { data: rev, error: rErr } = await svc.rpc("fm_staff_revoke_sessions", { p_user: id, p_rotate_pin: true });
    if (rErr) return json(500, { error: `Has\u0142o zmienione, ale nie uda\u0142o si\u0119 uniewa\u017Cni\u0107 sesji (${rErr.message}). Powt\xF3rz \u201Enowy PIN\u201D.` });
    return json(200, { id, code: staff.code, pin, sessions_revoked: rev?.sessions_revoked ?? null });
  }
  if (action === "block") {
    const { data: blk, error: bErr } = await svc.rpc("fm_staff_set_blocked", { p_user: id, p_blocked: true });
    if (bErr || !blk?.blocked) return json(500, { error: `Nie uda\u0142o si\u0119 zablokowa\u0107 konta w bazie: ${bErr?.message || "brak potwierdzenia"}.` });
    const { error: banErr } = await svc.auth.admin.updateUserById(id, { ban_duration: "87600h" });
    if (banErr) return json(500, { error: `Konto ZABLOKOWANE w bazie (sesje uniewa\u017Cnione: ${blk.sessions_revoked}), ale ban w Auth nie powi\xF3d\u0142 si\u0119: ${banErr.message}. Powt\xF3rz \u201Ezablokuj\u201D.`, blocked: true });
    return json(200, { id, code: staff.code, blocked: true, sessions_revoked: blk.sessions_revoked });
  }
  if (action === "unblock") {
    const { error: banErr } = await svc.auth.admin.updateUserById(id, { ban_duration: "none" });
    if (banErr) return json(500, { error: `Nie uda\u0142o si\u0119 zdj\u0105\u0107 banu w Auth: ${banErr.message}. Konto pozostaje zablokowane.`, blocked: true });
    const { data: blk, error: bErr } = await svc.rpc("fm_staff_set_blocked", { p_user: id, p_blocked: false });
    if (bErr || blk?.blocked !== false) return json(500, { error: `Ban zdj\u0119ty w Auth, ale baza nadal blokuje konto: ${bErr?.message || "brak potwierdzenia"}. Powt\xF3rz \u201Eodblokuj\u201D.`, blocked: true });
    return json(200, { id, code: staff.code, blocked: false });
  }
  if (action === "delete") {
    const { error } = await svc.auth.admin.deleteUser(id);
    if (error) return json(500, { error: `Usuni\u0119cie nieudane: ${error.message}` });
    return json(200, { id, deleted: true });
  }
  return json(400, { error: "Nieznana akcja." });
};
export {
  admin_staff_default as default
};
