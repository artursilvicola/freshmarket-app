var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fm_plan_raw_exports = {};
__export(fm_plan_raw_exports, {
  loadFmPlanRaw: () => loadFmPlanRaw
});
module.exports = __toCommonJS(fm_plan_raw_exports);
async function loadFmPlanRaw(db) {
  const fail = (scope, error) => ({ error: `${scope}: ${error.message || error}` });
  const settingsQ = await db.from("fm_settings").select("*").order("updated_at", { ascending: false }).limit(1).maybeSingle();
  if (settingsQ.error) return fail("fm_settings", settingsQ.error);
  const planQ = await db.from("fm_plan_private").select("schedule, updated_at").eq("id", 1).maybeSingle();
  if (planQ.error && !/fm_plan_private/i.test(planQ.error.message || "")) return fail("fm_plan_private", planQ.error);
  const plan = planQ.data && planQ.data.schedule ? planQ.data : null;
  const settings = settingsQ.data ? { ...settingsQ.data, schedule: plan?.schedule ?? settingsQ.data.schedule ?? null } : null;
  const companiesQ = await db.from("companies").select("*, company_contacts(name, position, phone, email, role, sort_order)").eq("fm_b2b_enabled", true).neq("account_status", "suspended").neq("account_status", "rejected").order("name");
  if (companiesQ.error) return fail("companies", companiesQ.error);
  const companyIds = (companiesQ.data || []).map((c) => c.id);
  let supplierProfiles = [];
  if (companyIds.length) {
    const profQ = await db.from("profiles").select("id, company_id, email, name, phone, position, role, locale, active").in("company_id", companyIds);
    if (profQ.error) return fail("profiles", profQ.error);
    supplierProfiles = profQ.data || [];
  }
  const retailersQ = await db.from("retailers").select(`*, buyers:profiles!fk_profiles_retailer(id, role, name, email, phone, position, active, fm26_active, buyer_categories, locale)`).eq("fm26_active", true).order("name");
  if (retailersQ.error) return fail("retailers", retailersQ.error);
  const prefsQ = await db.from("company_target_retailers").select("*");
  if (prefsQ.error) return fail("company_target_retailers", prefsQ.error);
  const respsQ = await db.from("fm_resps").select("*");
  if (respsQ.error) return fail("fm_resps", respsQ.error);
  return {
    ok: true,
    generated_at: (/* @__PURE__ */ new Date()).toISOString(),
    plan_updated_at: plan?.updated_at || null,
    settings,
    companies: companiesQ.data || [],
    supplier_profiles: supplierProfiles,
    retailers: retailersQ.data || [],
    prefs: prefsQ.data || [],
    resps: respsQ.data || []
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  loadFmPlanRaw
});
