var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fm_plan_data_exports = {};
__export(fm_plan_data_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(fm_plan_data_exports);
var import_node_crypto = require("node:crypto");
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_fm_plan_raw = require("./_shared/fm-plan-raw.js");
const json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  body: JSON.stringify(body)
});
async function handler(event) {
  if (event.httpMethod !== "GET" && event.httpMethod !== "POST") {
    return json(405, { error: "method_not_allowed" });
  }
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("fm-plan-data", missing));
  const isLocal = process.env.NETLIFY_DEV === "true" || process.env.NETLIFY_LOCAL === "true";
  const localFlag = event.headers["x-fm-local"] || event.headers["X-FM-Local"];
  const svcToken = event.headers["x-fm-token"] || event.headers["X-FM-Token"];
  const expected = process.env.FM_EXPORT_TOKEN || "";
  let authorized = false;
  if (isLocal && localFlag === "1") {
    authorized = true;
  } else if (svcToken && expected && expected.length >= 32) {
    const a = Buffer.from(String(svcToken)), b = Buffer.from(expected);
    if (a.length === b.length && (0, import_node_crypto.timingSafeEqual)(a, b)) authorized = true;
    else return json(401, { error: "invalid_token" });
  } else {
    const authHeader = event.headers.authorization || event.headers.Authorization;
    if (!authHeader?.startsWith("Bearer ")) return json(401, { error: "no_auth_header" });
    const token = authHeader.slice(7);
    const missingAuth = (0, import_function_env.missingEnvNames)(env, ["supabaseAnonKey"]);
    if (missingAuth.length) return json(500, (0, import_function_env.envErrorPayload)("fm-plan-data", missingAuth));
    const supaUser = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });
    const { data: userData, error: uErr } = await supaUser.auth.getUser(token);
    if (uErr || !userData?.user) return json(401, { error: "invalid_token" });
    const supaCheck = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
    const { data: profile } = await supaCheck.from("profiles").select("role, active").eq("id", userData.user.id).maybeSingle();
    if (profile?.role !== "admin" || profile.active === false) return json(403, { error: "admin_only" });
    authorized = true;
  }
  if (!authorized) return json(403, { error: "forbidden" });
  const db = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const raw = await (0, import_fm_plan_raw.loadFmPlanRaw)(db);
  if (raw.error) return json(500, { error: raw.error });
  return json(200, raw);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
