var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var send_supplier_notification_exports = {};
__export(send_supplier_notification_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(send_supplier_notification_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_supplier_email_templates = require("./_shared/supplier-email-templates.js");
var import_error_messages = require("./_shared/error-messages.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let callerLocale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return json(405, { error: (0, import_error_messages.errLoc)(callerLocale, "method_not_allowed") });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseAnonKey", "supabaseServiceRoleKey", "resendApiKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("send-supplier-notification", missing));
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: (0, import_error_messages.errLoc)(callerLocale, "invalid_json") });
  }
  callerLocale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.callerLocale, acceptLanguage: acceptLang });
  const { template, company_id, payload = {} } = body || {};
  if (!template) return json(400, { error: (0, import_error_messages.errLoc)(callerLocale, "missing_template") });
  const internalToken = event.headers["x-internal-token"] || event.headers["X-Internal-Token"];
  const isInternal = Boolean(internalToken && internalToken === env.supabaseServiceRoleKey);
  let callerRole = null;
  if (!isInternal) {
    const authHeader = event.headers.authorization || event.headers.Authorization;
    if (!authHeader?.startsWith("Bearer ")) return json(401, { error: (0, import_error_messages.errLoc)(callerLocale, "no_auth_token") });
    const token = authHeader.slice(7);
    const supaUser = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });
    const { data: userData, error: userErr } = await supaUser.auth.getUser(token);
    if (userErr || !userData?.user) return json(401, { error: (0, import_error_messages.errLoc)(callerLocale, "invalid_token") });
    const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
    const { data: caller } = await supaSvc.from("profiles").select("role, locale").eq("id", userData.user.id).maybeSingle();
    callerRole = caller?.role || null;
    if (!["admin", "supplier"].includes(callerRole)) {
      return json(403, { error: (0, import_error_messages.errLoc)(callerLocale, "only_admin_or_supplier") });
    }
    callerLocale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.callerLocale, profileLocale: caller?.locale, acceptLanguage: acceptLang });
  }
  let recipientEmail = payload.recipientEmail || null;
  let companyName = payload.companyName || null;
  let contactName = payload.contactName || null;
  let country = payload.country || null;
  let recipientLocale = payload.locale || null;
  if (company_id) {
    const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
    const { data: co } = await supaSvc.from("companies").select("id, name, country, status_note").eq("id", company_id).maybeSingle();
    if (co) {
      companyName = companyName || co.name;
      country = country || co.country;
      if (!payload.statusNote && co.status_note) payload.statusNote = co.status_note;
    }
    if (!recipientEmail || !recipientLocale) {
      const { data: ownerProfiles } = await supaSvc.from("profiles").select("name, email, role, active, locale").eq("company_id", company_id).eq("role", "supplier").order("created_at", { ascending: true }).limit(1);
      const owner = ownerProfiles?.[0];
      if (owner) {
        if (!recipientEmail) recipientEmail = owner.email;
        if (!contactName) contactName = contactName || owner.name;
        if (!recipientLocale && owner.locale) recipientLocale = owner.locale;
      }
    }
  }
  if (template === "admin_new_registration") {
    recipientEmail = recipientEmail || "newsletter@freshmarket.eu";
  }
  if (!recipientEmail) return json(400, { error: (0, import_error_messages.errLoc)(callerLocale, "missing_recipient") });
  const tpl = (0, import_supplier_email_templates.pickTemplate)(template, {
    ...payload,
    companyName: companyName || payload.companyName,
    contactName: contactName || payload.contactName,
    country: country || payload.country,
    appUrl: env.b2bAppUrl,
    // [P2-backend-mails C2] Pass resolved locale to template dispatcher.
    // admin_new_registration ignoruje locale (zostaje PL — internal admin notification).
    locale: recipientLocale || payload.locale || "pl"
  });
  if (!tpl) return json(400, { error: (0, import_error_messages.errLoc)(callerLocale, "unknown_template", { template }) });
  const { subject, html } = tpl;
  const resendRes = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.resendApiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from: "Fresh Market <newsletter@freshmarket.eu>",
      to: [recipientEmail],
      subject,
      html
    })
  });
  if (!resendRes.ok) {
    const detail = await resendRes.text();
    return json(502, { error: (0, import_error_messages.errLoc)(callerLocale, "resend_error"), status: resendRes.status, detail });
  }
  const r = await resendRes.json().catch(() => ({}));
  return json(200, { ok: true, template, recipient: recipientEmail, subject, message_id: r.id || null });
};
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
