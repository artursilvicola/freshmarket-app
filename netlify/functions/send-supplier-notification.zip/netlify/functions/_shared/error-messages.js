var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var error_messages_exports = {};
__export(error_messages_exports, {
  errLoc: () => errLoc,
  pickErrLocale: () => pickErrLocale,
  resolveLocale: () => resolveLocale
});
module.exports = __toCommonJS(error_messages_exports);
const SUPPORTED_LOCALES = ["pl", "en"];
function pickErrLocale(input) {
  if (!input) return "pl";
  const raw = String(input).trim().toLowerCase().split(/[-_]/)[0];
  return SUPPORTED_LOCALES.includes(raw) ? raw : "pl";
}
const MESSAGES = {
  pl: {
    retailer_delivery_unconfirmed: "Poczta przyj\u0119\u0142a wiadomo\u015B\u0107, ale zapis wysy\u0142ki nie zosta\u0142 potwierdzony. Nie wysy\u0142aj ponownie \u2014 najpierw sprawd\u017A dor\u0119czenie z administratorem.",
    // ── Auth / token ──
    no_auth_header: "Brak nag\u0142\xF3wka Authorization",
    no_auth_token: "Brak tokenu autoryzacji",
    invalid_token: "Nieprawid\u0142owy token",
    profile_not_found: "Nie znaleziono profilu u\u017Cytkownika",
    profile_no_role: "Brak profilu u\u017Cytkownika",
    account_inactive: "Konto jest nieaktywne",
    account_inactive_buyer: "Konto kupca jest nieaktywne",
    // ── Role gates ──
    only_admin: "Tylko admin mo\u017Ce wywo\u0142a\u0107 t\u0119 funkcj\u0119.",
    only_admin_create_users: "Tylko admin mo\u017Ce tworzy\u0107 konta B2B",
    only_admin_update_users: "Tylko admin mo\u017Ce aktualizowa\u0107 konta B2B",
    only_admin_reset_password: "Tylko admin mo\u017Ce resetowa\u0107 has\u0142a",
    only_admin_or_supplier: "Tylko admin lub supplier mo\u017Ce wywo\u0142a\u0107.",
    only_buyer_or_admin_mark_seen: "Tylko kupiec lub admin mo\u017Ce oznaczy\u0107 ofert\u0119 jako zobaczon\u0105",
    only_buyer_or_admin_mark_seen_list: "Tylko kupiec lub admin mo\u017Ce oznaczy\u0107 oferty jako zobaczone",
    only_admin_send_batch: "Tylko admin mo\u017Ce wysy\u0142a\u0107 zbiorcze maile do sieci.",
    only_supplier_buy_pkg: "Tylko dostawca mo\u017Ce kupowa\u0107 pakiety",
    only_admin_or_supplier_ai_desc: "Ta funkcja jest dost\u0119pna tylko dla admina lub dostawcy.",
    only_admin_ai_chat: "Ta funkcja jest dost\u0119pna tylko dla administratora.",
    ai_moderation_review_failed: "Nie uda\u0142o si\u0119 przeanalizowa\u0107 propozycji przez AI.",
    no_offer_write_perm: "Brak uprawnie\u0144 do zapisu propozycji",
    // ── Walidacja body ──
    invalid_json: "Niepoprawny JSON",
    missing_email: "Podaj poprawny adres email.",
    missing_email_short: "Brak email",
    missing_password: "Has\u0142o musi mie\u0107 minimum 8 znak\xF3w.",
    missing_company_name: "Podaj nazw\u0119 firmy.",
    company_name_too_long: "Nazwa firmy jest za d\u0142uga.",
    missing_nip: "Podaj NIP firmy. To pole jest wymagane do rejestracji i rozlicze\u0144.",
    invalid_role: "Niepoprawna rola (admin/supplier/buyer)",
    supplier_needs_company: "Supplier wymaga company_id",
    buyer_needs_retailer: "Buyer wymaga retailer_id",
    buyer_needs_name: "Buyer wymaga imienia i nazwiska",
    buyer_needs_name_full: "Kupiec musi mie\u0107 imi\u0119 i nazwisko.",
    buyer_needs_email: "Kupiec musi mie\u0107 adres e-mail.",
    buyer_needs_one_retailer: "Kupiec musi by\u0107 przypisany do jednej sieci handlowej.",
    buyer_needs_category: "Aktywny kupiec musi mie\u0107 przynajmniej jedn\u0105 kategori\u0119.",
    retailer_not_found: "Wybrana sie\u0107 handlowa nie istnieje.",
    retailer_not_found_short: "Sie\u0107 handlowa nie znaleziona.",
    missing_user_id: "Brak user_id",
    missing_send_ids: "send_ids jest puste \u2014 nie ma czego wys\u0142a\u0107.",
    missing_retailer_id: "Brak retailer_id",
    missing_legacy_id: "Brak / nieprawid\u0142owy legacy_id",
    missing_template: "Brak template",
    missing_recipient: "Brak adresata maila.",
    missing_send_id: "Brak sendId",
    missing_offer_id: "Brak ID propozycji",
    missing_supplier_id: "Brak identyfikatora dostawcy",
    missing_plan_id: "Brak plan_id",
    missing_user_password_or_link: "Podaj new_password ALBO send_magic_link=true",
    missing_data_company: "Brak danych firmy do opisu.",
    missing_chat_messages: "Brak wiadomo\u015Bci do analizy.",
    // ── Auth state ──
    email_exists: "Konto z tym adresem email ju\u017C istnieje. Spr\xF3buj zalogowa\u0107 si\u0119 lub odzyska\u0107 has\u0142o.",
    buyer_email_duplicate: "Kupiec z tym adresem e-mail ju\u017C istnieje.",
    user_not_found: "User nie znaleziony",
    target_profile_not_found: "Nie znaleziono profilu kupca do aktualizacji.",
    buyer_only_path: "Ta \u015Bcie\u017Cka s\u0142u\u017Cy tylko do zarz\u0105dzania kupcami.",
    // ── Send batch ──
    no_active_buyers: 'Sie\u0107 {retailerName} nie ma \u017Cadnego aktywnego kupca z e-mailem. Najpierw uzupe\u0142nij Buyer w "Sieci".',
    sends_read_failed: "B\u0142\u0105d odczytu sends: {detail}",
    no_approved_sends: "Brak propozycji gotowych do e-maila \u2014 wszystkie s\u0105 odrzucone, w moderacji, odczytane albo e-mail ju\u017C zosta\u0142 wys\u0142any.",
    // ── Send single ──
    send_not_found: "Wysy\u0142ka nie znaleziona",
    send_bad_status: "Wysy\u0142ka ma status {status} \u2014 nie wysy\u0142am",
    resend_error: "Resend error",
    // ── PayU ──
    no_company_assigned: "Konto nie jest przypisane do firmy. Skontaktuj si\u0119 z administratorem.",
    plan_not_found: "Plan {planId} nie istnieje lub jest nieaktywny",
    payu_order_register_failed: "Nie uda\u0142o si\u0119 zarejestrowa\u0107 zam\xF3wienia: {detail}",
    payu_config_error: "Konfiguracja PayU jest niepoprawna: {detail}",
    payu_currency_rate_missing: "Konfiguracja PayU wymaga kursu przeliczeniowego EUR na {currency}. Ustaw PAYU_EUR_TO_PAYU_RATE albo skonfiguruj POS PayU w EUR.",
    payu_currency_mismatch: "Waluta zam\xF3wienia nie zgadza si\u0119 z walut\u0105 POS PayU. U\u017Cyta konfiguracja: {context}. Por\xF3wnaj POS ID i OAuth client_id z punktem p\u0142atno\u015Bci REST API w PayU.",
    // ── Proforma (przelew) ──
    proforma_nip_required: "Podaj NIP firmy. To pole jest wymagane do rejestracji i rozlicze\u0144.",
    proforma_number_failed: "Nie uda\u0142o si\u0119 nada\u0107 numeru proformy: {detail}",
    proforma_create_failed: "Nie uda\u0142o si\u0119 wygenerowa\u0107 proformy: {detail}",
    payu_api_error: "PayU API: {detail}",
    // ── Misc create / update failures ──
    create_user_failed: "Nie uda\u0142o si\u0119 utworzy\u0107 konta: {detail}",
    create_user_failed_short: "Nie uda\u0142o si\u0119 utworzy\u0107 usera: {detail}",
    create_company_failed: "Nie uda\u0142o si\u0119 utworzy\u0107 firmy: {detail}",
    create_profile_failed: "Nie uda\u0142o si\u0119 utworzy\u0107 profilu: {detail}",
    update_profile_after_auth_failed: "Konto utworzone, ale update profile nie powi\xF3d\u0142 si\u0119: {detail}",
    magic_link_failed: "Magic link nie wygenerowany: {detail}",
    magic_link_failed_warning: "Konto utworzone, magic link nie wygenerowany: {detail}",
    password_update_failed: "Nie uda\u0142o si\u0119 zaktualizowa\u0107 has\u0142a: {detail}",
    auth_update_failed: "Nie uda\u0142o si\u0119 zaktualizowa\u0107 auth.users: {detail}",
    profile_after_auth_update_failed: "Auth zaktualizowany, ale profil nie: {detail}",
    duplicate_check_failed: "Nie uda\u0142o si\u0119 sprawdzi\u0107 duplikat\xF3w kupc\xF3w.",
    unknown_template: "Nieznany template: {template}",
    legacy_supplier_id_backfill_failed: "Nie uda\u0142o si\u0119 przygotowa\u0107 identyfikatora dostawcy: {detail}",
    own_company_only_ai_desc: "Dostawca mo\u017Ce generowa\u0107 opis tylko dla swojej firmy.",
    method_not_allowed: "Method Not Allowed"
  },
  en: {
    retailer_delivery_unconfirmed: "The email provider accepted the message, but its delivery record is unconfirmed. Do not resend; check delivery with the administrator first.",
    // ── Auth / token ──
    no_auth_header: "Authorization header missing",
    no_auth_token: "Authorization token missing",
    invalid_token: "Invalid token",
    profile_not_found: "User profile not found",
    profile_no_role: "User profile not found",
    account_inactive: "Account is inactive",
    account_inactive_buyer: "Buyer account is inactive",
    // ── Role gates ──
    only_admin: "Only an administrator can call this function.",
    only_admin_create_users: "Only an administrator can create B2B accounts",
    only_admin_update_users: "Only an administrator can update B2B accounts",
    only_admin_reset_password: "Only an administrator can reset passwords",
    only_admin_or_supplier: "Only an administrator or supplier can call this function.",
    only_buyer_or_admin_mark_seen: "Only a buyer or administrator can mark a submission as seen",
    only_buyer_or_admin_mark_seen_list: "Only a buyer or administrator can mark submissions as seen",
    only_admin_send_batch: "Only an administrator can send batch emails to retailers.",
    only_supplier_buy_pkg: "Only a supplier can purchase packages",
    only_admin_or_supplier_ai_desc: "This function is available only to administrators or suppliers.",
    only_admin_ai_chat: "This function is available only to administrators.",
    ai_moderation_review_failed: "Could not analyse the submission with AI.",
    no_offer_write_perm: "No permission to write submission",
    // ── Walidacja body ──
    invalid_json: "Invalid JSON",
    missing_email: "Provide a valid email address.",
    missing_email_short: "Email missing",
    missing_password: "Password must be at least 8 characters.",
    missing_company_name: "Provide a company name.",
    company_name_too_long: "Company name is too long.",
    missing_nip: "Provide the company Tax ID. This field is required for registration and billing.",
    invalid_role: "Invalid role (admin/supplier/buyer)",
    supplier_needs_company: "Supplier requires company_id",
    buyer_needs_retailer: "Buyer requires retailer_id",
    buyer_needs_name: "Buyer requires a first and last name",
    buyer_needs_name_full: "Buyer must have a first and last name.",
    buyer_needs_email: "Buyer must have an email address.",
    buyer_needs_one_retailer: "Buyer must be assigned to one retailer.",
    buyer_needs_category: "An active buyer must have at least one category.",
    retailer_not_found: "Selected retailer does not exist.",
    retailer_not_found_short: "Retailer not found.",
    missing_user_id: "user_id missing",
    missing_send_ids: "send_ids is empty \u2014 nothing to send.",
    missing_retailer_id: "retailer_id missing",
    missing_legacy_id: "Missing / invalid legacy_id",
    missing_template: "template missing",
    missing_recipient: "No email recipient.",
    missing_send_id: "sendId missing",
    missing_offer_id: "Submission ID missing",
    missing_supplier_id: "Supplier identifier missing",
    missing_plan_id: "plan_id missing",
    missing_user_password_or_link: "Provide new_password OR send_magic_link=true",
    missing_data_company: "No company data to describe.",
    missing_chat_messages: "No messages to analyse.",
    // ── Auth state ──
    email_exists: "An account with this email already exists. Try signing in or recovering the password.",
    buyer_email_duplicate: "A buyer with this email already exists.",
    user_not_found: "User not found",
    target_profile_not_found: "Buyer profile to update not found.",
    buyer_only_path: "This path is only for buyer management.",
    // ── Send batch ──
    no_active_buyers: 'Retailer {retailerName} has no active buyer with an email. Add a Buyer in "Retailers" first.',
    sends_read_failed: "Sends read error: {detail}",
    no_approved_sends: "No submissions ready for email \u2014 all are rejected, in moderation, already read, or email was already sent.",
    // ── Send single ──
    send_not_found: "Send not found",
    send_bad_status: "Send has status {status} \u2014 not sending",
    resend_error: "Resend error",
    // ── PayU ──
    no_company_assigned: "Account is not assigned to a company. Contact the administrator.",
    plan_not_found: "Plan {planId} does not exist or is inactive",
    payu_order_register_failed: "Could not register the order: {detail}",
    payu_config_error: "PayU configuration is invalid: {detail}",
    payu_currency_rate_missing: "PayU configuration requires an EUR to {currency} conversion rate. Set PAYU_EUR_TO_PAYU_RATE or configure the PayU POS in EUR.",
    payu_currency_mismatch: "The order currency does not match the PayU POS currency. Used configuration: {context}. Compare POS ID and OAuth client_id with the REST API payment point in PayU.",
    // ── Proforma (bank transfer) ──
    proforma_nip_required: "Provide the company Tax ID. This field is required for registration and billing.",
    proforma_number_failed: "Could not assign a proforma number: {detail}",
    proforma_create_failed: "Could not generate the proforma: {detail}",
    payu_api_error: "PayU API: {detail}",
    // ── Misc create / update failures ──
    create_user_failed: "Could not create the account: {detail}",
    create_user_failed_short: "Could not create the user: {detail}",
    create_company_failed: "Could not create the company: {detail}",
    create_profile_failed: "Could not create the profile: {detail}",
    update_profile_after_auth_failed: "Account created, but profile update failed: {detail}",
    magic_link_failed: "Magic link not generated: {detail}",
    magic_link_failed_warning: "Account created, magic link not generated: {detail}",
    password_update_failed: "Could not update the password: {detail}",
    auth_update_failed: "Could not update auth.users: {detail}",
    profile_after_auth_update_failed: "Auth updated, but profile did not: {detail}",
    duplicate_check_failed: "Could not check buyer duplicates.",
    unknown_template: "Unknown template: {template}",
    legacy_supplier_id_backfill_failed: "Could not prepare supplier identifier: {detail}",
    own_company_only_ai_desc: "Supplier can generate description only for their own company.",
    method_not_allowed: "Method Not Allowed"
  }
};
function errLoc(locale, key, params = {}) {
  const lng = pickErrLocale(locale);
  const lookup = MESSAGES[lng]?.[key] || MESSAGES.pl[key] || key;
  let msg = lookup;
  for (const [k, v] of Object.entries(params || {})) {
    msg = msg.split(`{${k}}`).join(String(v ?? ""));
  }
  return msg;
}
function resolveLocale({ bodyLocale, profileLocale, acceptLanguage } = {}) {
  if (bodyLocale) return pickErrLocale(bodyLocale);
  if (profileLocale) return pickErrLocale(profileLocale);
  if (acceptLanguage) return pickErrLocale(String(acceptLanguage).split(",")[0]);
  return "pl";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  errLoc,
  pickErrLocale,
  resolveLocale
});
