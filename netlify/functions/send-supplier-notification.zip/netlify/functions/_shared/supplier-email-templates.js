var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var supplier_email_templates_exports = {};
__export(supplier_email_templates_exports, {
  pickTemplate: () => pickTemplate,
  tplAccountActivated: () => tplAccountActivated,
  tplAccountRejected: () => tplAccountRejected,
  tplAccountSuspended: () => tplAccountSuspended,
  tplAdminNewRegistration: () => tplAdminNewRegistration,
  tplOfferApproved: () => tplOfferApproved,
  tplOfferExpired: () => tplOfferExpired,
  tplOfferReadByBuyer: () => tplOfferReadByBuyer,
  tplOfferSentToRetailer: () => tplOfferSentToRetailer,
  tplOfferToModeration: () => tplOfferToModeration,
  tplOffersReadByBuyer: () => tplOffersReadByBuyer,
  tplOffersSentToRetailer: () => tplOffersSentToRetailer,
  tplRegistrationAccepted: () => tplRegistrationAccepted
});
module.exports = __toCommonJS(supplier_email_templates_exports);
const SUPPORTED_TPL_LOCALES = ["pl", "en"];
function pickLocale(input) {
  if (!input) return "pl";
  const raw = String(input).trim().toLowerCase().split(/[-_]/)[0];
  return SUPPORTED_TPL_LOCALES.includes(raw) ? raw : "pl";
}
const CONTACT_EMAIL = process.env.ACCOUNT_EMAIL_CONTACT_FIX === "true" ? "hello@freshmarket.eu" : "newsletter@freshmarket.eu";
const FOOTER = (appUrl, locale = "pl") => {
  const addressLine = locale === "en" ? "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Poland" : "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Polska";
  return `
<tr><td style="background:#0f172a;padding:18px 28px;text-align:center;">
  <div style="color:rgba(255,255,255,0.92);font-weight:700;font-size:13px;margin-bottom:4px;">Fresh Market PreConnect</div>
  <div style="color:rgba(255,255,255,0.45);font-size:11px;line-height:1.7;">
    ${addressLine}<br>
    <a href="${esc(appUrl)}" style="color:rgba(255,255,255,0.7);text-decoration:none;">freshmarket.eu</a> \xB7
    <a href="mailto:${CONTACT_EMAIL}" style="color:rgba(255,255,255,0.7);text-decoration:none;">${CONTACT_EMAIL}</a>
  </div>
</td></tr>`;
};
function shell({ title, accent = "#0d9488", body, appUrl, locale = "pl" }) {
  return `<!DOCTYPE html>
<html lang="${locale}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title></head>
<body style="margin:0;padding:0;background:#ececec;font-family:Arial,Helvetica,sans-serif;color:#1a1a1a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ececec;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 18px rgba(15,23,42,0.08);">
      <tr><td style="background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,${accent} 100%);padding:24px 32px;text-align:center;">
        <div style="color:white;font-weight:800;font-size:20px;letter-spacing:-0.4px;">Fresh Market <span style="color:rgba(255,255,255,0.6);font-weight:600;font-size:12px;">PreConnect</span></div>
      </td></tr>
      ${body}
      ${FOOTER(appUrl, locale)}
    </table>
  </td></tr>
</table>
</body></html>`;
}
function pBlock(text) {
  return `<p style="margin:0 0 10px;color:#334155;line-height:1.65;font-size:14px;">${text}</p>`;
}
function ctaButton(label, url, color = "#0d9488") {
  return `<div style="margin:18px 0 8px;text-align:center;">
    <a href="${esc(url)}" style="display:inline-block;background:${color};color:white;padding:11px 24px;border-radius:7px;font-weight:700;font-size:13px;text-decoration:none;">${esc(label)}</a>
  </div>`;
}
function tplRegistrationAccepted({ companyName, contactName, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplRegistrationAcceptedEN({ companyName, contactName, appUrl });
  return tplRegistrationAcceptedPL({ companyName, contactName, appUrl });
}
function tplRegistrationAcceptedPL({ companyName, contactName, appUrl }) {
  const subject = "Fresh Market \u2013 otrzymali\u015Bmy zg\u0142oszenie rejestracyjne";
  const greet = contactName ? `Dzie\u0144 dobry ${esc(contactName)},` : "Dzie\u0144 dobry,";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`dzi\u0119kujemy za rejestracj\u0119 firmy <strong>${esc(companyName)}</strong> na platformie Fresh Market PreConnect.`)}
  ${pBlock("Twoje konto zosta\u0142o utworzone i czeka na <strong>zatwierdzenie przez administratora</strong>. W tym czasie mo\u017Cesz zalogowa\u0107 si\u0119 do panelu i uzupe\u0142ni\u0107 profil firmy: dane podstawowe, logo, certyfikaty, opis. Im pe\u0142niejszy profil, tym szybciej decyzja zatwierdzaj\u0105ca.")}
  ${pBlock("Po zatwierdzeniu konta otrzymasz osobnego maila i odblokujemy:")}
  <ul style="color:#334155;font-size:14px;line-height:1.7;padding-left:18px;margin:0 0 10px;">
    <li>dost\u0119p do PreConnect \u2014 wysy\u0142ka ofert do sieci handlowych,</li>
    <li>dost\u0119p do Spotka\u0144 B2B Fresh Market 2026 (aktywowany indywidualnie).</li>
  </ul>
  ${ctaButton("Otw\xF3rz panel dostawcy", `${appUrl}/dostawca`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, body, appUrl, locale: "pl" }) };
}
function tplRegistrationAcceptedEN({ companyName, contactName, appUrl }) {
  const subject = "Fresh Market \u2013 we received your registration";
  const greet = contactName ? `Hello ${esc(contactName)},` : "Hello,";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`thank you for registering <strong>${esc(companyName)}</strong> on the Fresh Market PreConnect platform.`)}
  ${pBlock("Your account has been created and is awaiting <strong>admin approval</strong>. In the meantime you can sign in to the panel and complete your company profile: basic details, logo, certificates, description. The more complete the profile, the faster the approval decision.")}
  ${pBlock("Once your account is approved you will receive a separate email and we will unlock:")}
  <ul style="color:#334155;font-size:14px;line-height:1.7;padding-left:18px;margin:0 0 10px;">
    <li>access to PreConnect \u2014 submissions to retailers,</li>
    <li>access to Fresh Market 2026 B2B Meetings (activated individually).</li>
  </ul>
  ${ctaButton("Open supplier panel", `${appUrl}/dostawca`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, body, appUrl, locale: "en" }) };
}
function tplAccountActivated({ companyName, contactName, preconnectEnabled, fmB2bEnabled, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplAccountActivatedEN({ companyName, contactName, preconnectEnabled, fmB2bEnabled, appUrl });
  return tplAccountActivatedPL({ companyName, contactName, preconnectEnabled, fmB2bEnabled, appUrl });
}
function tplAccountActivatedPL({ companyName, contactName, preconnectEnabled, fmB2bEnabled, appUrl }) {
  const subject = "Fresh Market \u2013 Twoje konto zosta\u0142o aktywowane";
  const greet = contactName ? `Dzie\u0144 dobry ${esc(contactName)},` : "Dzie\u0144 dobry,";
  const enabledLines = [
    preconnectEnabled ? "\u2713 <strong>PreConnect</strong> \u2014 mo\u017Cesz wysy\u0142a\u0107 oferty do sieci handlowych" : null,
    fmB2bEnabled ? "\u2713 <strong>Spotkania B2B Fresh Market 2026</strong> \u2014 dopuszczeni do harmonogramu spotka\u0144" : null
  ].filter(Boolean);
  const enabledBlock = enabledLines.length ? `<ul style="color:#0d9488;font-size:14px;line-height:1.8;padding-left:18px;margin:6px 0 10px;list-style:none;">${enabledLines.map((l) => `<li>${l}</li>`).join("")}</ul>` : "";
  const disabledNote = !preconnectEnabled && !fmB2bEnabled ? pBlock("Aktywne modu\u0142y dla Twojej firmy zostan\u0105 dodane przez administratora w kolejnym kroku.") : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`konto firmy <strong>${esc(companyName)}</strong> zosta\u0142o <strong style="color:#059669;">zatwierdzone</strong> przez administratora Fresh Market.`)}
  ${enabledBlock}
  ${disabledNote}
  ${pBlock("Zaloguj si\u0119 do panelu, sprawd\u017A profil firmy i ustaw preferencje. Je\u015Bli kt\xF3ry\u015B modu\u0142 nie jest jeszcze aktywny, zostanie odblokowany przez administratora po stronie Fresh Market.")}
  ${ctaButton("Otw\xF3rz panel dostawcy", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "pl" }) };
}
function tplAccountActivatedEN({ companyName, contactName, preconnectEnabled, fmB2bEnabled, appUrl }) {
  const subject = "Fresh Market \u2013 your account has been activated";
  const greet = contactName ? `Hello ${esc(contactName)},` : "Hello,";
  const enabledLines = [
    preconnectEnabled ? "\u2713 <strong>PreConnect</strong> \u2014 you can send submissions to retailers" : null,
    fmB2bEnabled ? "\u2713 <strong>Fresh Market 2026 B2B Meetings</strong> \u2014 admitted to the meeting schedule" : null
  ].filter(Boolean);
  const enabledBlock = enabledLines.length ? `<ul style="color:#0d9488;font-size:14px;line-height:1.8;padding-left:18px;margin:6px 0 10px;list-style:none;">${enabledLines.map((l) => `<li>${l}</li>`).join("")}</ul>` : "";
  const disabledNote = !preconnectEnabled && !fmB2bEnabled ? pBlock("Active modules for your company will be added by the administrator in the next step.") : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`the account for <strong>${esc(companyName)}</strong> has been <strong style="color:#059669;">approved</strong> by the Fresh Market administrator.`)}
  ${enabledBlock}
  ${disabledNote}
  ${pBlock("Sign in to the panel, review the company profile and set preferences. If a module isn't active yet, the administrator will unlock it on the Fresh Market side.")}
  ${ctaButton("Open supplier panel", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "en" }) };
}
function tplAccountRejected({ companyName, contactName, statusNote, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplAccountRejectedEN({ companyName, contactName, statusNote, appUrl });
  return tplAccountRejectedPL({ companyName, contactName, statusNote, appUrl });
}
function tplAccountRejectedPL({ companyName, contactName, statusNote, appUrl }) {
  const subject = "Fresh Market \u2013 rejestracja wymaga uzupe\u0142nienia";
  const greet = contactName ? `Dzie\u0144 dobry ${esc(contactName)},` : "Dzie\u0144 dobry,";
  const noteBlock = statusNote ? `<div style="background:#fef3c7;border-left:4px solid #f59e0b;padding:12px 16px;margin:12px 0;color:#78350f;font-size:13px;line-height:1.65;">${esc(statusNote)}</div>` : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`niestety nie mo\u017Cemy w tej chwili aktywowa\u0107 konta firmy <strong>${esc(companyName)}</strong> na platformie Fresh Market PreConnect.`)}
  ${noteBlock || pBlock("Pow\xF3d: prosimy o kontakt w celu uzupe\u0142nienia danych firmy lub sprawdzenia statusu rejestracji.")}
  ${pBlock(`Skontaktuj si\u0119 z nami pod adresem <a href='mailto:${CONTACT_EMAIL}' style='color:#0d9488;'>${CONTACT_EMAIL}</a> \u2014 pomo\u017Cemy doprowadzi\u0107 rejestracj\u0119 do ko\u0144ca.`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#dc2626", body, appUrl, locale: "pl" }) };
}
function tplAccountRejectedEN({ companyName, contactName, statusNote, appUrl }) {
  const subject = "Fresh Market \u2013 registration needs to be completed";
  const greet = contactName ? `Hello ${esc(contactName)},` : "Hello,";
  const noteBlock = statusNote ? `<div style="background:#fef3c7;border-left:4px solid #f59e0b;padding:12px 16px;margin:12px 0;color:#78350f;font-size:13px;line-height:1.65;">${esc(statusNote)}</div>` : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`unfortunately we are not able to activate the account for <strong>${esc(companyName)}</strong> on the Fresh Market PreConnect platform at this moment.`)}
  ${noteBlock || pBlock("Reason: please contact us to complete the company details or check the registration status.")}
  ${pBlock(`Contact us at <a href='mailto:${CONTACT_EMAIL}' style='color:#0d9488;'>${CONTACT_EMAIL}</a> \u2014 we will help you finalise the registration.`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#dc2626", body, appUrl, locale: "en" }) };
}
function tplAccountSuspended({ companyName, contactName, statusNote, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplAccountSuspendedEN({ companyName, contactName, statusNote, appUrl });
  return tplAccountSuspendedPL({ companyName, contactName, statusNote, appUrl });
}
function tplAccountSuspendedPL({ companyName, contactName, statusNote, appUrl }) {
  const subject = "Fresh Market \u2013 konto zosta\u0142o wstrzymane";
  const greet = contactName ? `Dzie\u0144 dobry ${esc(contactName)},` : "Dzie\u0144 dobry,";
  const noteBlock = statusNote ? `<div style="background:#fee2e2;border-left:4px solid #dc2626;padding:12px 16px;margin:12px 0;color:#991b1b;font-size:13px;line-height:1.65;">${esc(statusNote)}</div>` : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`konto firmy <strong>${esc(companyName)}</strong> zosta\u0142o tymczasowo wstrzymane przez administratora.`)}
  ${noteBlock}
  ${pBlock(`Wstrzymane konto nadal pozwala zalogowa\u0107 si\u0119 do panelu i uzupe\u0142ni\u0107 profil, ale wstrzymujemy wysy\u0142k\u0119 ofert i Spotkania B2B do czasu wyja\u015Bnienia. Skontaktuj si\u0119 z <a href='mailto:${CONTACT_EMAIL}' style='color:#0d9488;'>${CONTACT_EMAIL}</a>.`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#dc2626", body, appUrl, locale: "pl" }) };
}
function tplAccountSuspendedEN({ companyName, contactName, statusNote, appUrl }) {
  const subject = "Fresh Market \u2013 account suspended";
  const greet = contactName ? `Hello ${esc(contactName)},` : "Hello,";
  const noteBlock = statusNote ? `<div style="background:#fee2e2;border-left:4px solid #dc2626;padding:12px 16px;margin:12px 0;color:#991b1b;font-size:13px;line-height:1.65;">${esc(statusNote)}</div>` : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock(`the account for <strong>${esc(companyName)}</strong> has been temporarily suspended by the administrator.`)}
  ${noteBlock}
  ${pBlock(`A suspended account still lets you sign in to the panel and update the profile, but submissions and B2B Meetings are paused until further notice. Contact <a href='mailto:${CONTACT_EMAIL}' style='color:#0d9488;'>${CONTACT_EMAIL}</a>.`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#dc2626", body, appUrl, locale: "en" }) };
}
function tplOfferToModeration({ companyName, offerTitle, retailerName, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplOfferToModerationEN({ companyName, offerTitle, retailerName, appUrl });
  return tplOfferToModerationPL({ companyName, offerTitle, retailerName, appUrl });
}
function tplOfferToModerationPL({ companyName, offerTitle, retailerName, appUrl }) {
  const subject = "Fresh Market \u2013 oferta zosta\u0142a przyj\u0119ta do moderacji";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Dzie\u0144 dobry,")}
  ${pBlock(`Twoja oferta <strong>${esc(offerTitle)}</strong>${retailerName ? ` skierowana do sieci <strong>${esc(retailerName)}</strong>` : ""} zosta\u0142a przyj\u0119ta do moderacji.`)}
  ${pBlock("Zesp\xF3\u0142 Fresh Market sprawdza dopasowanie oferty do kategorii zakupowej tej sieci. O decyzji poinformujemy mailem.")}
  ${ctaButton("Zobacz w panelu", `${appUrl}/dostawca`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, body, appUrl, locale: "pl" }) };
}
function tplOfferToModerationEN({ companyName, offerTitle, retailerName, appUrl }) {
  const subject = "Fresh Market \u2013 submission accepted for review";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Hello,")}
  ${pBlock(`your submission <strong>${esc(offerTitle)}</strong>${retailerName ? ` addressed to <strong>${esc(retailerName)}</strong>` : ""} has been accepted for review.`)}
  ${pBlock("The Fresh Market team is checking whether the submission fits the retailer's buying category. We'll let you know the decision by email.")}
  ${ctaButton("View in panel", `${appUrl}/dostawca`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, body, appUrl, locale: "en" }) };
}
function tplOfferApproved({ companyName, offerTitle, retailerName, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplOfferApprovedEN({ companyName, offerTitle, retailerName, appUrl });
  return tplOfferApprovedPL({ companyName, offerTitle, retailerName, appUrl });
}
function tplOfferApprovedPL({ companyName, offerTitle, retailerName, appUrl }) {
  const subject = "Fresh Market \u2013 oferta zosta\u0142a zatwierdzona";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Dzie\u0144 dobry,")}
  ${pBlock(`Twoja oferta <strong>${esc(offerTitle)}</strong>${retailerName ? ` dla sieci <strong>${esc(retailerName)}</strong>` : ""} zosta\u0142a zatwierdzona przez administratora.`)}
  ${pBlock("Oferta jest gotowa do wysy\u0142ki w najbli\u017Cszym mailu zbiorczym do tej sieci. Otrzymasz potwierdzenie, gdy wiadomo\u015B\u0107 zostanie wys\u0142ana.")}
  ${ctaButton("Otw\xF3rz panel dostawcy", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "pl" }) };
}
function tplOfferApprovedEN({ companyName, offerTitle, retailerName, appUrl }) {
  const subject = "Fresh Market \u2013 submission approved";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Hello,")}
  ${pBlock(`your submission <strong>${esc(offerTitle)}</strong>${retailerName ? ` for <strong>${esc(retailerName)}</strong>` : ""} has been approved by the administrator.`)}
  ${pBlock("The submission is ready to be sent in the next batch email to that retailer. You'll get a confirmation once the message goes out.")}
  ${ctaButton("Open supplier panel", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "en" }) };
}
function offerItemsList(offers = [], locale = "pl") {
  const items = (offers || []).filter(Boolean);
  if (!items.length) return "";
  const visible = items.slice(0, 8);
  const extra = items.length - visible.length;
  const moreLabel = locale === "en" ? `+ ${extra} more` : `+ ${extra} kolejne`;
  const fallbackTitle = locale === "en" ? "Submission" : "Oferta";
  return `<ul style="color:#334155;font-size:14px;line-height:1.7;padding-left:18px;margin:8px 0 12px;">
    ${visible.map((o) => `<li><strong>${esc(o.title || o.offerTitle || o.product || fallbackTitle)}</strong></li>`).join("")}
    ${extra > 0 ? `<li>${moreLabel}</li>` : ""}
  </ul>`;
}
function pluralOffersPL(count) {
  const n = Math.abs(Number(count || 0));
  if (n === 1) return "ofert\u0119";
  const last = n % 10;
  const lastTwo = n % 100;
  if (last >= 2 && last <= 4 && !(lastTwo >= 12 && lastTwo <= 14)) return "oferty";
  return "ofert";
}
function pluralOffersEN(count) {
  return Number(count) === 1 ? "submission" : "submissions";
}
function tplOffersSentToRetailer({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplOffersSentToRetailerEN({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl });
  return tplOffersSentToRetailerPL({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl });
}
function tplOffersSentToRetailerPL({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl }) {
  const count = Number(offerCount || (offers || []).length || 1);
  const subject = count === 1 ? `Fresh Market \u2013 oferta zosta\u0142a wys\u0142ana do ${retailerName || "sieci"}` : `Fresh Market \u2013 wys\u0142ali\u015Bmy ${count} ${pluralOffersPL(count)} do ${retailerName || "sieci"}`;
  const list = offerItemsList(offers?.length ? offers : [{ title: offerTitle }], "pl");
  const intro = count === 1 ? `Twoja oferta zosta\u0142a wys\u0142ana do sieci <strong>${esc(retailerName || "")}</strong>${sentAt ? ` w dniu ${esc(sentAt)}` : ""}.` : `Wys\u0142ali\u015Bmy do sieci <strong>${esc(retailerName || "")}</strong> <strong>${count} ${pluralOffersPL(count)}</strong>${sentAt ? ` w dniu ${esc(sentAt)}` : ""}.`;
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Dzie\u0144 dobry,")}
  ${pBlock(intro)}
  ${list}
  ${pBlock("Kupiec otrzyma\u0142 zbiorczy mail Fresh Market PreConnect. Gdy otworzy mail albo wejdzie na list\u0119 ofert w panelu, oznaczymy wysy\u0142k\u0119 jako dostarczon\u0105 i poka\u017Cemy rozliczenie w panelu.")}
  ${ctaButton("Zobacz w panelu", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "pl" }) };
}
function tplOffersSentToRetailerEN({ companyName, offerTitle, offers, offerCount, retailerName, sentAt, appUrl }) {
  const count = Number(offerCount || (offers || []).length || 1);
  const subject = count === 1 ? `Fresh Market \u2013 submission sent to ${retailerName || "retailer"}` : `Fresh Market \u2013 ${count} ${pluralOffersEN(count)} sent to ${retailerName || "retailer"}`;
  const list = offerItemsList(offers?.length ? offers : [{ title: offerTitle }], "en");
  const intro = count === 1 ? `Your submission has been sent to <strong>${esc(retailerName || "")}</strong>${sentAt ? ` on ${esc(sentAt)}` : ""}.` : `We sent <strong>${count} ${pluralOffersEN(count)}</strong> to <strong>${esc(retailerName || "")}</strong>${sentAt ? ` on ${esc(sentAt)}` : ""}.`;
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Hello,")}
  ${pBlock(intro)}
  ${list}
  ${pBlock("The buyer received the Fresh Market PreConnect batch email. When they open the email or visit the offer list in the panel, we'll mark the submission as delivered and show the billing in your panel.")}
  ${ctaButton("View in panel", `${appUrl}/dostawca`, "#059669")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#059669", body, appUrl, locale: "en" }) };
}
function tplOfferSentToRetailer(payload) {
  return tplOffersSentToRetailer({
    ...payload,
    offers: payload?.offers || [{ title: payload?.offerTitle }],
    offerCount: payload?.offerCount || 1
  });
}
function tplOffersReadByBuyer({ companyName, offerTitle, offers, offerCount, retailerName, openedVia, openedAt, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplOffersReadByBuyerEN({ companyName, offerTitle, offers, offerCount, retailerName, openedVia, openedAt, appUrl });
  return tplOffersReadByBuyerPL({ companyName, offerTitle, offers, offerCount, retailerName, openedVia, openedAt, appUrl });
}
function tplOffersReadByBuyerPL({ companyName, offerTitle, offers, offerCount, retailerName, openedVia, openedAt, appUrl }) {
  const count = Number(offerCount || (offers || []).length || 1);
  const channel = openedVia === "email" ? "otworzy\u0142 mail Fresh Market PreConnect z Twoimi propozycjami" : openedVia === "app_list" ? "wszed\u0142 na list\u0119 ofert PreConnect i zobaczy\u0142 Twoje propozycje" : "otworzy\u0142 Twoj\u0105 propozycj\u0119 w panelu PreConnect";
  const subject = count === 1 ? `Fresh Market \u2013 ${retailerName || "sie\u0107"} zobaczy\u0142a Twoj\u0105 ofert\u0119` : `Fresh Market \u2013 ${retailerName || "sie\u0107"} zobaczy\u0142a Twoje oferty`;
  const list = offerItemsList(offers?.length ? offers : [{ title: offerTitle }], "pl");
  const intro = count === 1 ? `Kupiec sieci <strong>${esc(retailerName || "")}</strong> ${channel}${openedAt ? ` (${esc(openedAt)})` : ""}.` : `Kupiec sieci <strong>${esc(retailerName || "")}</strong> ${channel}${openedAt ? ` (${esc(openedAt)})` : ""}. Zobaczone oferty:`;
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Dzie\u0144 dobry,")}
  ${pBlock(intro)}
  ${list}
  ${pBlock("To oznacza, \u017Ce wysy\u0142ka zosta\u0142a dostarczona. Rozliczenie z pakietu jest widoczne w panelu Fresh Market PreConnect.")}
  ${pBlock("Nie musisz nic robi\u0107 od razu \u2014 miej tylko pod r\u0119k\u0105 aktualne ceny, wolumeny, certyfikaty i kalendarz dostaw, je\u015Bli kupiec poprosi o szczeg\xF3\u0142y.")}
  ${ctaButton("Zobacz w panelu", `${appUrl}/dostawca`, "#7c3aed")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#7c3aed", body, appUrl, locale: "pl" }) };
}
function tplOffersReadByBuyerEN({ companyName, offerTitle, offers, offerCount, retailerName, openedVia, openedAt, appUrl }) {
  const count = Number(offerCount || (offers || []).length || 1);
  const channel = openedVia === "email" ? "opened the Fresh Market PreConnect email with your submissions" : openedVia === "app_list" ? "visited the PreConnect submissions list and saw your submissions" : "opened your submission in the PreConnect panel";
  const subject = count === 1 ? `Fresh Market \u2013 ${retailerName || "retailer"} saw your submission` : `Fresh Market \u2013 ${retailerName || "retailer"} saw your submissions`;
  const list = offerItemsList(offers?.length ? offers : [{ title: offerTitle }], "en");
  const intro = count === 1 ? `The buyer at <strong>${esc(retailerName || "")}</strong> ${channel}${openedAt ? ` (${esc(openedAt)})` : ""}.` : `The buyer at <strong>${esc(retailerName || "")}</strong> ${channel}${openedAt ? ` (${esc(openedAt)})` : ""}. Submissions seen:`;
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Hello,")}
  ${pBlock(intro)}
  ${list}
  ${pBlock("This means the submission was delivered. The package billing is visible in the Fresh Market PreConnect panel.")}
  ${pBlock("You don't have to act right away \u2014 just keep current prices, volumes, certificates and delivery calendar ready in case the buyer asks for details.")}
  ${ctaButton("View in panel", `${appUrl}/dostawca`, "#7c3aed")}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#7c3aed", body, appUrl, locale: "en" }) };
}
function tplOfferReadByBuyer(payload) {
  return tplOffersReadByBuyer({
    ...payload,
    offers: payload?.offers || [{ title: payload?.offerTitle }],
    offerCount: payload?.offerCount || 1
  });
}
function tplOfferExpired({ companyName, offerTitle, retailerName, refunded, appUrl, locale }) {
  const lng = pickLocale(locale);
  if (lng === "en") return tplOfferExpiredEN({ companyName, offerTitle, retailerName, refunded, appUrl });
  return tplOfferExpiredPL({ companyName, offerTitle, retailerName, refunded, appUrl });
}
function tplOfferExpiredPL({ companyName, offerTitle, retailerName, refunded, appUrl }) {
  const subject = "Fresh Market \u2013 oferta wygas\u0142a";
  const refundLine = refunded ? pBlock("\u2713 \u015Arodki za niewykorzystan\u0105 wysy\u0142k\u0119 zosta\u0142y zwr\xF3cone na Tw\xF3j portfel kredyt\xF3w.") : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Dzie\u0144 dobry,")}
  ${pBlock(`Twoja oferta <strong>${esc(offerTitle)}</strong>${retailerName ? ` wys\u0142ana do sieci <strong>${esc(retailerName)}</strong>` : ""} wygas\u0142a \u2014 kupiec nie odczyta\u0142 wiadomo\u015Bci w terminie 14 dni.`)}
  ${refundLine}
  ${pBlock("Mo\u017Cesz przygotowa\u0107 zaktualizowan\u0105 ofert\u0119 i zleci\u0107 ponown\u0105 wysy\u0142k\u0119 z poziomu panelu.")}
  ${ctaButton("Otw\xF3rz panel dostawcy", `${appUrl}/dostawca`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#d97706", body, appUrl, locale: "pl" }) };
}
function tplOfferExpiredEN({ companyName, offerTitle, retailerName, refunded, appUrl }) {
  const subject = "Fresh Market \u2013 submission expired";
  const refundLine = refunded ? pBlock("\u2713 The credits for the unused submission have been returned to your credit wallet.") : "";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock("Hello,")}
  ${pBlock(`your submission <strong>${esc(offerTitle)}</strong>${retailerName ? ` sent to <strong>${esc(retailerName)}</strong>` : ""} has expired \u2014 the buyer didn't open the message within 14 days.`)}
  ${refundLine}
  ${pBlock("You can prepare an updated submission and trigger a new send from the panel.")}
  ${ctaButton("Open supplier panel", `${appUrl}/dostawca`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, accent: "#d97706", body, appUrl, locale: "en" }) };
}
function tplAdminNewRegistration({ companyName, contactEmail, country, appUrl }) {
  const subject = `Fresh Market \u2013 nowa rejestracja: ${companyName}`;
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(`Nowa rejestracja w panelu Fresh Market wymaga zatwierdzenia.`)}
  <table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 12px;font-size:13px;color:#334155;">
    <tr><td style="padding:4px 14px 4px 0;color:#64748b;">Firma:</td><td style="padding:4px 0;font-weight:700;">${esc(companyName)}</td></tr>
    <tr><td style="padding:4px 14px 4px 0;color:#64748b;">Kontakt:</td><td style="padding:4px 0;">${esc(contactEmail)}</td></tr>
    <tr><td style="padding:4px 14px 4px 0;color:#64748b;">Kraj:</td><td style="padding:4px 0;">${esc(country || "\u2014")}</td></tr>
  </table>
  ${ctaButton("Otw\xF3rz panel administratora \u2192 Firmy", `${appUrl}/admin`)}
</td></tr>`;
  return { subject, html: shell({ title: subject, body, appUrl }) };
}
function pickTemplate(name, payload) {
  switch (name) {
    case "registration_accepted":
      return tplRegistrationAccepted(payload);
    case "account_activated":
      return tplAccountActivated(payload);
    case "account_rejected":
      return tplAccountRejected(payload);
    case "account_suspended":
      return tplAccountSuspended(payload);
    case "offer_to_moderation":
      return tplOfferToModeration(payload);
    case "offer_approved":
      return tplOfferApproved(payload);
    case "offer_sent_to_retailer":
      return tplOfferSentToRetailer(payload);
    case "offers_sent_to_retailer":
      return tplOffersSentToRetailer(payload);
    case "offer_read_by_buyer":
      return tplOfferReadByBuyer(payload);
    case "offers_read_by_buyer":
      return tplOffersReadByBuyer(payload);
    case "offer_expired":
      return tplOfferExpired(payload);
    case "admin_new_registration":
      return tplAdminNewRegistration(payload);
    default:
      return null;
  }
}
function esc(s) {
  if (s == null) return "";
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  pickTemplate,
  tplAccountActivated,
  tplAccountRejected,
  tplAccountSuspended,
  tplAdminNewRegistration,
  tplOfferApproved,
  tplOfferExpired,
  tplOfferReadByBuyer,
  tplOfferSentToRetailer,
  tplOfferToModeration,
  tplOffersReadByBuyer,
  tplOffersSentToRetailer,
  tplRegistrationAccepted
});
