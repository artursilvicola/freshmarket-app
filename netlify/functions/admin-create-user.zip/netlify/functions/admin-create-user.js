var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_create_user_exports = {};
__export(admin_create_user_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_create_user_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_error_messages = require("./_shared/error-messages.js");
const BUYER_CATEGORY_OPTIONS = /* @__PURE__ */ new Set(["owoce", "warzywa", "kwiaty"]);
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: cors, body: (0, import_error_messages.errLoc)(locale, "method_not_allowed") };
  }
  const env = (0, import_function_env.resolveEnvConfig)();
  const missingCore = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey"]);
  if (missingCore.length) {
    return errJson(500, (0, import_function_env.envErrorPayload)("admin-create-user", missingCore));
  }
  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    return errJson(401, (0, import_error_messages.errLoc)(locale, "no_auth_header"));
  }
  const token = authHeader.slice(7);
  const missingAuth = (0, import_function_env.missingEnvNames)(env, ["supabaseAnonKey"]);
  if (missingAuth.length) return errJson(500, (0, import_function_env.envErrorPayload)("admin-create-user", missingAuth));
  const supaUser = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } }
  });
  const { data: userData, error: uErr } = await supaUser.auth.getUser(token);
  if (uErr || !userData?.user) return errJson(401, (0, import_error_messages.errLoc)(locale, "invalid_token"));
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: profile, error: pErr } = await supaSvc.from("profiles").select("role, locale").eq("id", userData.user.id).maybeSingle();
  if (pErr || profile?.role !== "admin") {
    return errJson(403, (0, import_error_messages.errLoc)(locale, "only_admin_create_users"));
  }
  locale = (0, import_error_messages.resolveLocale)({ profileLocale: profile.locale, acceptLanguage: acceptLang });
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return errJson(400, (0, import_error_messages.errLoc)(locale, "invalid_json"));
  }
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, profileLocale: profile.locale, acceptLanguage: acceptLang });
  const {
    email,
    role,
    name = null,
    company_id = null,
    retailer_id = null,
    phone = null,
    position = null,
    active = true,
    fm26_active = false,
    buyer_categories = [],
    send_magic_link = true
  } = body;
  const normalizedEmail = normalizeEmail(email);
  const normalizedName = normalizeText(name);
  if (!normalizedEmail) return errJson(400, (0, import_error_messages.errLoc)(locale, "missing_email_short"));
  if (!["admin", "supplier", "buyer"].includes(role)) {
    return errJson(400, (0, import_error_messages.errLoc)(locale, "invalid_role"));
  }
  if (role === "supplier" && !company_id) {
    return errJson(400, (0, import_error_messages.errLoc)(locale, "supplier_needs_company"));
  }
  if (role === "buyer" && !retailer_id) {
    return errJson(400, (0, import_error_messages.errLoc)(locale, "buyer_needs_retailer"));
  }
  if (role === "buyer" && !normalizedName) {
    return errJson(400, (0, import_error_messages.errLoc)(locale, "buyer_needs_name"));
  }
  if (role === "buyer") {
    const { data: retailer, error: rErr } = await supaSvc.from("retailers").select("id").eq("id", Number(retailer_id)).maybeSingle();
    if (rErr || !retailer) return errJson(400, (0, import_error_messages.errLoc)(locale, "retailer_not_found"));
    const { data: profiles, error: dupErr } = await supaSvc.from("profiles").select("id, email").eq("role", "buyer").not("email", "is", null);
    if (dupErr) return errJson(500, (0, import_error_messages.errLoc)(locale, "duplicate_check_failed"));
    const duplicate = (profiles || []).find((p) => normalizeEmail(p.email) === normalizedEmail);
    if (duplicate) return errJson(409, (0, import_error_messages.errLoc)(locale, "buyer_email_duplicate"));
  }
  const { data: created, error: cErr } = await supaSvc.auth.admin.createUser({
    email: normalizedEmail,
    email_confirm: true,
    // omijamy email confirmation - admin tworzy konta
    user_metadata: { name: normalizedName, role, company_id, retailer_id: retailer_id ? Number(retailer_id) : null }
  });
  if (cErr || !created?.user) {
    return errJson(
      cErr?.message?.toLowerCase().includes("already been registered") ? 409 : 500,
      (0, import_error_messages.errLoc)(locale, "create_user_failed_short", { detail: cErr?.message || "" })
    );
  }
  const profileRow = {
    id: created.user.id,
    email: normalizedEmail,
    role,
    name: normalizedName,
    company_id,
    retailer_id: retailer_id ? Number(retailer_id) : null,
    phone: normalizeText(phone),
    position: normalizeText(position),
    active: active !== false,
    fm26_active: !!fm26_active,
    buyer_categories: normalizeBuyerCategories(buyer_categories),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  const { data: savedProfile, error: upErr } = await supaSvc.from("profiles").upsert(profileRow, { onConflict: "id" }).select().single();
  if (upErr) {
    return errJson(500, (0, import_error_messages.errLoc)(locale, "update_profile_after_auth_failed", { detail: upErr.message }));
  }
  let magic_link = null;
  if (send_magic_link) {
    const { data: linkData, error: linkErr } = await supaSvc.auth.admin.generateLink({
      type: "magiclink",
      email: normalizedEmail,
      options: {
        redirectTo: env.b2bAppUrl
      }
    });
    if (linkErr) {
      return okJson({
        user_id: created.user.id,
        email,
        magic_link: null,
        warning: (0, import_error_messages.errLoc)(locale, "magic_link_failed_warning", { detail: linkErr.message })
      });
    }
    magic_link = linkData?.properties?.action_link || null;
  }
  return okJson({
    user_id: created.user.id,
    email: normalizedEmail,
    role,
    company_id,
    retailer_id: retailer_id ? Number(retailer_id) : null,
    magic_link,
    profile: savedProfile
  });
};
function okJson(payload) {
  return {
    statusCode: 200,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
function errJson(code, msg) {
  return {
    statusCode: code,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(typeof msg === "string" ? { error: msg } : msg)
  };
}
function normalizeText(value) {
  if (value == null) return null;
  const next = String(value).trim();
  return next || null;
}
function normalizeEmail(value) {
  const next = normalizeText(value);
  return next ? next.toLowerCase() : null;
}
function normalizeBuyerCategories(values = []) {
  return [...new Set((Array.isArray(values) ? values : []).filter((v) => BUYER_CATEGORY_OPTIONS.has(v)))];
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
