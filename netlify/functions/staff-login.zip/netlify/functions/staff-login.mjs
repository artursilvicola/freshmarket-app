
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/staff-login.js
import { createClient } from "@supabase/supabase-js";

// netlify/functions/_shared/netlify-modern.js
function getEnv(name) {
  try {
    const v = globalThis.Netlify?.env?.get?.(name);
    if (v != null && v !== "") return v;
  } catch {
  }
  return process.env[name] ?? "";
}
function envConfig() {
  const first = (...keys) => keys.map(getEnv).find(Boolean) || "";
  return {
    supabaseUrl: first("SUPABASE_URL", "VITE_SUPABASE_URL"),
    supabaseAnonKey: first("SUPABASE_ANON_KEY", "VITE_SUPABASE_ANON_KEY"),
    supabaseServiceRoleKey: first("SUPABASE_SERVICE_ROLE_KEY"),
    staffPinPepper: first("STAFF_PIN_PEPPER")
  };
}
function missingOf(cfg, keys) {
  return keys.filter((k) => !cfg[k]);
}
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, Accept-Language",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
function json(status, body, extra = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...extra }
  });
}
async function readJson(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}
function trustedIp(context) {
  const ip = String(context?.ip || "").trim();
  return ip ? ip.slice(0, 64) : null;
}
function langOf(request) {
  return /^en/i.test(String(request.headers.get("accept-language") || "")) ? "en" : "pl";
}

// netlify/functions/_shared/staff-auth.js
import { createHmac, randomInt } from "node:crypto";
var STAFF_EMAIL_DOMAIN = "obsluga.freshmarket.eu";
function normalizeStaffCode(raw) {
  return String(raw || "").trim().toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 32);
}
function staffEmailFor(code) {
  return `${normalizeStaffCode(code).toLowerCase()}@${STAFF_EMAIL_DOMAIN}`;
}
function isValidPin(pin) {
  return /^\d{6}$/.test(String(pin || ""));
}
function staffPassword(pepper, code, pin) {
  return createHmac("sha256", pepper).update(`${normalizeStaffCode(code)}:${pin}`).digest("base64url");
}
function classifyAuthError(err, session) {
  if (!err) return session ? "success" : "system_error";
  const code = String(err.code || err.error_code || "").toLowerCase();
  if (code === "invalid_credentials" || code === "invalid_grant") return "invalid_credentials";
  const status = Number(err.status || 0);
  const message = String(err.message || "").trim().toLowerCase();
  if (status === 400 && message === "invalid login credentials") return "invalid_credentials";
  return "system_error";
}

// netlify/functions/staff-login.js
var MSG = {
  pl: {
    FM_BAD_INPUT: "Podaj kod operatora i 6-cyfrowy PIN.",
    FM_DEVICE_REQUIRED: "Brak identyfikatora urz\u0105dzenia \u2014 od\u015Bwie\u017C stron\u0119 i spr\xF3buj ponownie.",
    FM_BAD_CREDENTIALS: "Nieprawid\u0142owy kod lub PIN.",
    FM_BLOCKED: "Konto obs\u0142ugi jest zablokowane. Zg\u0142o\u015B si\u0119 do organizatora.",
    FM_LOCKED: (s) => `Za du\u017Co b\u0142\u0119dnych pr\xF3b. Spr\xF3buj ponownie za ${Math.ceil((s || 900) / 60)} min.`,
    FM_BUSY: "Trwa inna pr\xF3ba logowania na to konto. Odczekaj chwil\u0119 i spr\xF3buj ponownie.",
    FM_RATE_LIMIT: "Za du\u017Co pr\xF3b z tego urz\u0105dzenia. Odczekaj 15 minut.",
    FM_WRONG_DAY: (d) => `To konto dzia\u0142a tylko w dniu wydarzenia (${d}).`,
    FM_DEVICE_MISMATCH: "To konto jest przypisane do innego urz\u0105dzenia. Popro\u015B organizatora o reset PIN-u.",
    FM_SYSTEM_ERROR: "Chwilowy problem z logowaniem (serwer). Spr\xF3buj ponownie za chwil\u0119 \u2014 pr\xF3ba nie zosta\u0142a policzona.",
    FM_DB: "B\u0142\u0105d bazy przy logowaniu.",
    FM_NO_PEPPER: "Brak konfiguracji STAFF_PIN_PEPPER (Netlify env)."
  },
  en: {
    FM_BAD_INPUT: "Enter the operator code and the 6-digit PIN.",
    FM_DEVICE_REQUIRED: "Missing device identifier \u2014 reload the page and try again.",
    FM_BAD_CREDENTIALS: "Invalid code or PIN.",
    FM_BLOCKED: "This staff account is blocked. Contact the organiser.",
    FM_LOCKED: (s) => `Too many wrong attempts. Try again in ${Math.ceil((s || 900) / 60)} min.`,
    FM_BUSY: "Another login attempt for this account is in progress. Wait a moment and try again.",
    FM_RATE_LIMIT: "Too many attempts from this device. Wait 15 minutes.",
    FM_WRONG_DAY: (d) => `This account only works on the event day (${d}).`,
    FM_DEVICE_MISMATCH: "This account is bound to another device. Ask the organiser for a PIN reset.",
    FM_SYSTEM_ERROR: "Temporary login problem (server). Try again in a moment \u2014 the attempt was not counted.",
    FM_DB: "Database error during login.",
    FM_NO_PEPPER: "STAFF_PIN_PEPPER is not configured (Netlify env)."
  }
};
var msg = (lang, code, arg) => {
  const m = MSG[lang][code] || MSG[lang].FM_BAD_CREDENTIALS;
  return typeof m === "function" ? m(arg) : m;
};
var STATUS = { FM_LOCKED: 423, FM_RATE_LIMIT: 423, FM_BUSY: 423, FM_BAD_CREDENTIALS: 401, FM_SYSTEM_ERROR: 503, FM_DB: 500 };
var staff_login_default = async (request, context) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (request.method !== "POST") return json(405, { error: "Method not allowed" });
  const lang = langOf(request);
  const cfg = envConfig();
  const missing = missingOf(cfg, ["supabaseUrl", "supabaseServiceRoleKey", "supabaseAnonKey"]);
  if (missing.length) return json(500, { error: `Brak konfiguracji: ${missing.join(", ")}`, code: "FM_ENV" });
  if (!cfg.staffPinPepper || cfg.staffPinPepper.length < 32) return json(500, { error: msg(lang, "FM_NO_PEPPER"), code: "FM_NO_PEPPER" });
  const body = await readJson(request);
  if (!body) return json(400, { error: msg(lang, "FM_BAD_INPUT"), code: "FM_BAD_INPUT" });
  const code = normalizeStaffCode(body.code);
  const pin = String(body.pin || "");
  const deviceId = String(body.device_id || "").replace(/[^A-Za-z0-9._-]/g, "").slice(0, 64);
  if (!code || !isValidPin(pin)) return json(400, { error: msg(lang, "FM_BAD_INPUT"), code: "FM_BAD_INPUT" });
  if (deviceId.length < 8) return json(400, { error: msg(lang, "FM_DEVICE_REQUIRED"), code: "FM_DEVICE_REQUIRED" });
  const ip = trustedIp(context);
  const svc = createClient(cfg.supabaseUrl, cfg.supabaseServiceRoleKey, { auth: { persistSession: false } });
  const { data: gate, error: gErr } = await svc.rpc("fm_staff_login_gate", { p_code: code, p_ip: ip, p_device: deviceId });
  if (gErr || !gate) return json(503, { error: msg(lang, "FM_SYSTEM_ERROR"), code: "FM_SYSTEM_ERROR" });
  if (!gate.allowed) {
    const reason = gate.reason || "FM_BAD_CREDENTIALS";
    return json(STATUS[reason] || 403, { error: msg(lang, reason, gate.retry_after_s ?? gate.event_date), code: reason, retry_after_s: gate.retry_after_s ?? void 0 });
  }
  const attemptId = gate.attempt_id;
  let auth = null, outcome;
  try {
    const anon = createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const r = await anon.auth.signInWithPassword({ email: staffEmailFor(code), password: staffPassword(cfg.staffPinPepper, code, pin) });
    auth = r.data;
    outcome = classifyAuthError(r.error, r.data?.session);
  } catch {
    outcome = "system_error";
  }
  const { data: res, error: rErr } = await svc.rpc("fm_staff_login_result", { p_attempt_id: attemptId, p_outcome: outcome, p_device: deviceId });
  const revoke = async () => {
    if (auth?.session?.access_token) await svc.auth.admin.signOut(auth.session.access_token, "local").catch(() => {
    });
  };
  if (rErr) {
    await revoke();
    return json(503, { error: msg(lang, "FM_SYSTEM_ERROR"), code: "FM_SYSTEM_ERROR" });
  }
  if (outcome === "system_error") {
    await revoke();
    return json(503, { error: msg(lang, "FM_SYSTEM_ERROR"), code: "FM_SYSTEM_ERROR" });
  }
  if (outcome === "invalid_credentials") {
    if (res?.locked) return json(423, { error: msg(lang, "FM_LOCKED", res.retry_after_s), code: "FM_LOCKED", retry_after_s: res.retry_after_s || 900 });
    return json(401, { error: msg(lang, "FM_BAD_CREDENTIALS"), code: "FM_BAD_CREDENTIALS", attempts_left: res?.attempts_left ?? void 0 });
  }
  if (!res?.ok || res.device_id !== deviceId) {
    await revoke();
    const reason = res?.reason === "FM_DEVICE_MISMATCH" || res?.ok && res.device_id !== deviceId ? "FM_DEVICE_MISMATCH" : "FM_SYSTEM_ERROR";
    return json(reason === "FM_DEVICE_MISMATCH" ? 403 : 503, { error: msg(lang, reason), code: reason });
  }
  return json(200, {
    access_token: auth.session.access_token,
    refresh_token: auth.session.refresh_token,
    expires_at: auth.session.expires_at,
    staff: { id: gate.id, code: gate.code, display_name: gate.display_name }
  });
};
export {
  staff_login_default as default
};
