var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var resend_webhook_exports = {};
__export(resend_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(resend_webhook_exports);
var import_node_crypto = __toESM(require("node:crypto"), 1);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_legacy_send_seen = require("./_shared/legacy-send-seen.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, svix-id, svix-timestamp, svix-signature",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return reply(405, { error: "Method Not Allowed" });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey", "resendWebhookSecret"]);
  if (missing.length) {
    console.error("[resend-webhook] missing env:", missing);
    return reply(200, { ignored: "missing_env", missing });
  }
  const rawBody = event.body || "";
  const svixId = event.headers["svix-id"] || event.headers["Svix-Id"];
  const svixTs = event.headers["svix-timestamp"] || event.headers["Svix-Timestamp"];
  const svixSig = event.headers["svix-signature"] || event.headers["Svix-Signature"];
  if (!svixId || !svixTs || !svixSig) {
    console.warn("[resend-webhook] brak svix headers");
    return reply(200, { ignored: "missing_svix_headers" });
  }
  const tsMs = Number(svixTs) * 1e3;
  if (!Number.isFinite(tsMs) || Math.abs(Date.now() - tsMs) > 10 * 60 * 1e3) {
    console.warn("[resend-webhook] timestamp out of window");
    return reply(200, { ignored: "stale_timestamp" });
  }
  const secret = env.resendWebhookSecret.startsWith("whsec_") ? env.resendWebhookSecret.slice(6) : env.resendWebhookSecret;
  const secretBytes = Buffer.from(secret, "base64");
  const signedContent = `${svixId}.${svixTs}.${rawBody}`;
  const expectedSig = import_node_crypto.default.createHmac("sha256", secretBytes).update(signedContent).digest("base64");
  const candidates = svixSig.split(" ").map((part) => part.split(",")[1]).filter(Boolean);
  const expectedBuf = Buffer.from(expectedSig, "base64");
  const sigOk = candidates.some((sig) => {
    try {
      const sigBuf = Buffer.from(sig, "base64");
      return sigBuf.length === expectedBuf.length && import_node_crypto.default.timingSafeEqual(sigBuf, expectedBuf);
    } catch {
      return false;
    }
  });
  if (!sigOk) {
    console.warn("[resend-webhook] z\u0142a sygnatura");
    return reply(200, { ignored: "bad_signature" });
  }
  let payload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return reply(200, { ignored: "invalid_json" });
  }
  const type = String(payload?.type || "");
  const messageId = payload?.data?.email_id;
  if (type !== "email.opened") {
    console.log("[resend-webhook] event:", type, "message_id:", messageId);
    return reply(200, { ok: true, ignored: `event_${type}` });
  }
  if (!messageId) {
    return reply(200, { ignored: "no_message_id" });
  }
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  let { data: rows, error: selErr } = await supaSvc.from("legacy_sends").select("id, legacy_id, status, email_opened_at, data").eq("resend_message_id", messageId);
  if (selErr) {
    console.error("[resend-webhook] select error", selErr);
    return reply(200, { error: "db_select_failed", message: selErr.message });
  }
  if (!rows || rows.length === 0) {
    const alt = await supaSvc.from("legacy_sends").select("id, legacy_id, status, email_opened_at, data").contains("data", { resendMessageIds: [messageId] });
    if (alt.error) {
      console.error("[resend-webhook] jsonb select error", alt.error);
      return reply(200, { error: "db_select_failed", message: alt.error.message });
    }
    rows = alt.data || [];
  }
  if (!rows || rows.length === 0) {
    console.warn("[resend-webhook] no sends with message_id:", messageId);
    return reply(200, { ignored: "unknown_message_id", messageId });
  }
  const result = await (0, import_legacy_send_seen.markLegacySendsSeen)({
    supaSvc,
    env,
    legacyIds: rows.map((row) => row.legacy_id),
    channel: "email",
    notifySupplier: true
  });
  return reply(200, { ok: true, message_id: messageId, ...result });
};
function reply(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
