var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var notify_supplier_read_exports = {};
__export(notify_supplier_read_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(notify_supplier_read_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_legacy_send_seen = require("./_shared/legacy-send-seen.js");
var import_error_messages = require("./_shared/error-messages.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return json(405, { error: (0, import_error_messages.errLoc)(locale, "method_not_allowed") });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("notify-supplier-read", missing));
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return json(401, { error: (0, import_error_messages.errLoc)(locale, "no_auth_token") });
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: userData, error: userErr } = await supaSvc.auth.getUser(token);
  if (userErr || !userData?.user) {
    return json(401, { error: (0, import_error_messages.errLoc)(locale, "invalid_token") });
  }
  const { data: profile, error: profileErr } = await supaSvc.from("profiles").select("id, role, retailer_id, active, locale").eq("id", userData.user.id).maybeSingle();
  if (profileErr) return json(500, { error: profileErr.message });
  if (!profile?.active) return json(403, { error: (0, import_error_messages.errLoc)(locale, "account_inactive") });
  if (!["buyer", "admin"].includes(profile?.role)) {
    return json(403, { error: (0, import_error_messages.errLoc)(locale, "only_buyer_or_admin_mark_seen") });
  }
  locale = (0, import_error_messages.resolveLocale)({ profileLocale: profile.locale, acceptLanguage: acceptLang });
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "invalid_json") });
  }
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, profileLocale: profile.locale, acceptLanguage: acceptLang });
  const legacyId = Number(body.legacy_id);
  if (!Number.isFinite(legacyId) || legacyId <= 0) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_legacy_id") });
  }
  const result = await (0, import_legacy_send_seen.markLegacySendsSeen)({
    supaSvc,
    env,
    legacyIds: [legacyId],
    channel: "app_detail",
    allowedRetailerId: profile.role === "buyer" ? profile.retailer_id : null,
    notifySupplier: true
  });
  return json(200, result);
};
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
