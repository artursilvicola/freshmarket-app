var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var register_supplier_self_exports = {};
__export(register_supplier_self_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(register_supplier_self_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_supplier_email_templates = require("./_shared/supplier-email-templates.js");
var import_error_messages = require("./_shared/error-messages.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return json(405, { error: "Method Not Allowed" });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseServiceRoleKey", "resendApiKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("register-supplier-self", missing));
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: (0, import_error_messages.errLoc)("pl", "invalid_json") });
  }
  const SUPPORTED_LOCALES = ["pl", "en"];
  const rawLocale = String(body.locale || "pl").trim().toLowerCase().split(/[-_]/)[0];
  const locale = SUPPORTED_LOCALES.includes(rawLocale) ? rawLocale : "pl";
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  const companyName = String(body.company_name || "").trim();
  const country = String(body.country || "PL").trim().toUpperCase();
  const contactName = String(body.contact_name || "").trim();
  const contactPhone = String(body.contact_phone || "").trim();
  const nip = String(body.nip || "").trim();
  const acceptedTermsVersion = String(body.accepted_terms_version || "1.0").trim();
  const acceptedPrivacyVersion = String(body.accepted_privacy_version || "1.0").trim();
  const acceptedAt = (/* @__PURE__ */ new Date()).toISOString();
  if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_email") });
  }
  if (!password || password.length < 8) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_password") });
  }
  if (!companyName || companyName.length < 2) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_company_name") });
  }
  if (companyName.length > 200) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "company_name_too_long") });
  }
  if (process.env.NIP_REQUIRED === "true" && !nip) {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_nip") });
  }
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: existing } = await supaSvc.from("profiles").select("id, email, role, company_id").eq("email", email).maybeSingle();
  if (existing) {
    const isOrphan = (existing.role || "supplier") === "supplier" && !existing.company_id;
    if (!isOrphan) {
      return json(409, { error: (0, import_error_messages.errLoc)(locale, "email_exists") });
    }
    try {
      await supaSvc.auth.admin.deleteUser(existing.id);
    } catch {
    }
    const { error: orphanDelErr } = await supaSvc.from("profiles").delete().eq("id", existing.id);
    if (orphanDelErr) {
      return json(409, { error: (0, import_error_messages.errLoc)(locale, "email_exists") });
    }
  }
  const { data: userData, error: userErr } = await supaSvc.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    // pomijamy email verification dla MVP — admin i tak musi zatwierdzić
    user_metadata: {
      role: "supplier",
      company_name: companyName,
      accepted_terms_version: acceptedTermsVersion,
      accepted_privacy_version: acceptedPrivacyVersion,
      accepted_at: acceptedAt,
      locale
    }
  });
  if (userErr || !userData?.user) {
    return json(500, { error: (0, import_error_messages.errLoc)(locale, "create_user_failed", { detail: userErr?.message || "unknown" }) });
  }
  const userId = userData.user.id;
  const { data: company, error: coErr } = await supaSvc.from("companies").insert({
    name: companyName,
    country,
    nip: nip || null,
    phone: contactPhone || null,
    account_status: "pending_review",
    preconnect_enabled: false,
    fm_b2b_enabled: false
  }).select().single();
  if (coErr || !company) {
    try {
      await supaSvc.auth.admin.deleteUser(userId);
    } catch {
    }
    try {
      await supaSvc.from("profiles").delete().eq("id", userId);
    } catch {
    }
    return json(500, { error: (0, import_error_messages.errLoc)(locale, "create_company_failed", { detail: coErr?.message || "unknown" }) });
  }
  const { error: profErr } = await supaSvc.from("profiles").upsert(
    {
      id: userId,
      email,
      role: "supplier",
      name: contactName || null,
      phone: contactPhone || null,
      company_id: company.id,
      active: true,
      fm26_active: false,
      accepted_terms_version: acceptedTermsVersion,
      accepted_privacy_version: acceptedPrivacyVersion,
      accepted_at: acceptedAt,
      locale
    },
    { onConflict: "id" }
  );
  if (profErr) {
    try {
      await supaSvc.from("companies").delete().eq("id", company.id);
    } catch {
    }
    try {
      await supaSvc.auth.admin.deleteUser(userId);
    } catch {
    }
    try {
      await supaSvc.from("profiles").delete().eq("id", userId);
    } catch {
    }
    return json(500, { error: (0, import_error_messages.errLoc)(locale, "create_profile_failed", { detail: profErr.message }) });
  }
  const tpls = [
    {
      template: "registration_accepted",
      to: email,
      payload: { companyName, contactName, appUrl: env.b2bAppUrl, locale }
    },
    {
      template: "admin_new_registration",
      to: "newsletter@freshmarket.eu",
      payload: { companyName, contactEmail: email, country, appUrl: env.b2bAppUrl }
    }
  ];
  const emailResults = await Promise.all(
    tpls.map(async ({ template, to, payload }) => {
      const tpl = (0, import_supplier_email_templates.pickTemplate)(template, payload);
      if (!tpl) return { template, ok: false, error: "no_template" };
      try {
        const res = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${env.resendApiKey}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            from: "Fresh Market <newsletter@freshmarket.eu>",
            to: [to],
            subject: tpl.subject,
            html: tpl.html
          })
        });
        if (!res.ok) {
          const detail = await res.text();
          return { template, ok: false, status: res.status, detail };
        }
        const r = await res.json().catch(() => ({}));
        return { template, ok: true, message_id: r.id || null };
      } catch (e) {
        return { template, ok: false, error: e?.message || String(e) };
      }
    })
  );
  return json(200, {
    ok: true,
    user_id: userId,
    company_id: company.id,
    account_status: "pending_review",
    accepted_terms_version: acceptedTermsVersion,
    accepted_privacy_version: acceptedPrivacyVersion,
    accepted_at: acceptedAt,
    message: "Konto utworzone, czeka na zatwierdzenie przez administratora.",
    emails: emailResults
  });
};
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
