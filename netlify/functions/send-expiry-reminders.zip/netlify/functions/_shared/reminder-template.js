var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var reminder_template_exports = {};
__export(reminder_template_exports, {
  tplCreditExpiryReminder: () => tplCreditExpiryReminder
});
module.exports = __toCommonJS(reminder_template_exports);
function esc(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function fmtDMY(d) {
  const s = String(d || "").slice(0, 10);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  return m ? `${m[3]}.${m[2]}.${m[1]}` : s;
}
function pickLocale(input) {
  const raw = String(input || "pl").trim().toLowerCase().split(/[-_]/)[0];
  return raw === "en" ? "en" : "pl";
}
function shell({ title, body, appUrl, locale }) {
  const footerAddr = locale === "en" ? "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Poland" : "KJOW Sp. z o.o. \xB7 ul. Marii 17/25, 05-803 Pruszk\xF3w, Polska";
  return `<!DOCTYPE html>
<html lang="${locale}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title></head>
<body style="margin:0;padding:0;background:#ececec;font-family:Arial,Helvetica,sans-serif;color:#1a1a1a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ececec;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 18px rgba(15,23,42,0.08);">
      <tr><td style="background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#d97706 100%);padding:24px 32px;text-align:center;">
        <div style="color:white;font-weight:800;font-size:20px;letter-spacing:-0.4px;">Fresh Market <span style="color:rgba(255,255,255,0.6);font-weight:600;font-size:12px;">PreConnect</span></div>
      </td></tr>
      ${body}
      <tr><td style="background:#0f172a;padding:18px 28px;text-align:center;">
        <div style="color:rgba(255,255,255,0.92);font-weight:700;font-size:13px;margin-bottom:4px;">Fresh Market PreConnect</div>
        <div style="color:rgba(255,255,255,0.45);font-size:11px;line-height:1.7;">
          ${footerAddr}<br>
          <a href="${esc(appUrl)}" style="color:rgba(255,255,255,0.7);text-decoration:none;">freshmarket.eu</a>
        </div>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;
}
function pBlock(text) {
  return `<p style="margin:0 0 10px;color:#334155;line-height:1.65;font-size:14px;">${text}</p>`;
}
function ctaButton(label, url) {
  return `<div style="margin:18px 0 8px;text-align:center;">
    <a href="${esc(url)}" style="display:inline-block;background:#0d9488;color:white;padding:11px 24px;border-radius:7px;font-weight:700;font-size:13px;text-decoration:none;">${esc(label)}</a>
  </div>`;
}
function tplCreditExpiryReminder({ companyName, qtyRemaining, expiresAt, appUrl, locale }) {
  const lng = pickLocale(locale);
  const date = fmtDMY(expiresAt);
  const url = `${appUrl || "https://b2b.freshmarket.eu"}/dostawca`;
  if (lng === "en") {
    const subject2 = "Fresh Market \u2013 your credits expire in 14 days";
    const greet2 = companyName ? `Hello ${esc(companyName)},` : "Hello,";
    const body2 = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet2)}
  ${pBlock("In 14 days your PreConnect credits expire. Unused credits will be forfeited after the expiry date.")}
  <div style="margin:6px 0 4px;padding:12px 16px;background:#fffbeb;border:1px solid #fde68a;border-radius:8px;color:#78350f;font-size:14px;">
    <strong>Valid until: ${esc(date)}</strong>${qtyRemaining != null ? ` \xB7 ${esc(qtyRemaining)} unused credit(s)` : ""}
  </div>
  ${pBlock("Use your credits before the deadline by sending submissions to retailers, or purchase a new package to keep going.")}
  ${ctaButton("Open supplier panel", url)}
</td></tr>`;
    return { subject: subject2, html: shell({ title: subject2, body: body2, appUrl, locale: "en" }) };
  }
  const subject = "Fresh Market \u2013 Twoje kredyty wygasaj\u0105 za 14 dni";
  const greet = companyName ? `Dzie\u0144 dobry ${esc(companyName)},` : "Dzie\u0144 dobry,";
  const body = `
<tr><td style="padding:24px 32px 8px;">
  ${pBlock(greet)}
  ${pBlock("Za 14 dni up\u0142ywa termin wa\u017Cno\u015Bci Twoich kredyt\xF3w. Niewykorzystane kredyty przepadn\u0105 po terminie wa\u017Cno\u015Bci.")}
  <div style="margin:6px 0 4px;padding:12px 16px;background:#fffbeb;border:1px solid #fde68a;border-radius:8px;color:#78350f;font-size:14px;">
    <strong>Wa\u017Cne do: ${esc(date)}</strong>${qtyRemaining != null ? ` \xB7 ${esc(qtyRemaining)} niewykorzystanych kredyt\xF3w` : ""}
  </div>
  ${pBlock("Wykorzystaj kredyty przed terminem, wysy\u0142aj\u0105c propozycje do sieci, albo kup nowy pakiet, aby dzia\u0142a\u0107 dalej.")}
  ${ctaButton("Otw\xF3rz panel dostawcy", url)}
</td></tr>`;
  return { subject, html: shell({ title: subject, body, appUrl, locale: "pl" }) };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  tplCreditExpiryReminder
});
