var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var load_kompendium_exports = {};
__export(load_kompendium_exports, {
  loadKompendium: () => loadKompendium
});
module.exports = __toCommonJS(load_kompendium_exports);
var import_node_fs = __toESM(require("node:fs"), 1);
var import_node_path = __toESM(require("node:path"), 1);
var import_node_url = require("node:url");
const import_meta = {};
let __dirname = "";
try {
  if (typeof import_meta !== "undefined" && import_meta.url) {
    __dirname = import_node_path.default.dirname((0, import_node_url.fileURLToPath)(import_meta.url));
  }
} catch (e) {
  __dirname = "";
}
const KOMPENDIUM_FILES = [
  {
    relativeName: "docs/PRECONNECT_KOMPENDIUM_DLA_GPT.md",
    basename: "PRECONNECT_KOMPENDIUM_DLA_GPT.md",
    headerLabel: "CZ\u0118\u015A\u0106 A \u2014 Kompendium PreConnect (panel B2B, role, workflow, pakiety wysy\u0142ek)"
  },
  {
    relativeName: "docs/FRESH_MARKET_EVENT_2026_KOMPENDIUM.md",
    basename: "FRESH_MARKET_EVENT_2026_KOMPENDIUM.md",
    headerLabel: "CZ\u0118\u015A\u0106 B \u2014 Kompendium Fresh Market 2026 (event: cennik, pakiety uczestnictwa, stoiska, agenda, FAQ)"
  }
];
let cachedContent = null;
let cachedLoaded = null;
function tryPaths(relativeName, basename) {
  const candidates = [];
  if (__dirname) {
    candidates.push(
      import_node_path.default.resolve(__dirname, "..", "..", relativeName),
      import_node_path.default.resolve(__dirname, "..", relativeName),
      import_node_path.default.resolve(__dirname, relativeName),
      import_node_path.default.resolve(__dirname, basename)
    );
  }
  candidates.push(
    import_node_path.default.resolve(process.cwd(), relativeName),
    import_node_path.default.resolve(process.cwd(), basename),
    import_node_path.default.resolve("/var/task", relativeName),
    import_node_path.default.resolve("/var/task", basename),
    import_node_path.default.resolve("/var/task/docs", basename)
  );
  for (const candidate of candidates) {
    try {
      if (import_node_fs.default.existsSync(candidate)) {
        const stat = import_node_fs.default.statSync(candidate);
        if (stat.isFile() && stat.size > 0) return candidate;
      }
    } catch (e) {
    }
  }
  return null;
}
function stripBom(text) {
  if (!text) return text;
  return text.charCodeAt(0) === 65279 ? text.slice(1) : text;
}
function loadOnce() {
  if (cachedContent !== null || cachedLoaded !== null) return;
  const parts = [];
  const loaded = [];
  for (const file of KOMPENDIUM_FILES) {
    const found = tryPaths(file.relativeName, file.basename);
    if (!found) {
      console.warn("[load-kompendium] missing:", file.relativeName);
      loaded.push({ file: file.relativeName, ok: false, reason: "not_found" });
      continue;
    }
    try {
      const raw = stripBom(import_node_fs.default.readFileSync(found, "utf8")).trim();
      parts.push(
        "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",
        file.headerLabel,
        "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",
        "",
        raw,
        ""
      );
      loaded.push({ file: file.relativeName, ok: true, path: found, bytes: raw.length });
    } catch (e) {
      console.warn("[load-kompendium] read error", file.relativeName, e?.message || e);
      loaded.push({ file: file.relativeName, ok: false, reason: e?.message || String(e) });
    }
  }
  cachedContent = parts.length ? parts.join("\n") : "";
  cachedLoaded = loaded;
}
function loadKompendium() {
  loadOnce();
  const anyOk = (cachedLoaded || []).some((entry) => entry.ok);
  return {
    ok: anyOk,
    content: cachedContent || "",
    loaded: cachedLoaded || []
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  loadKompendium
});
