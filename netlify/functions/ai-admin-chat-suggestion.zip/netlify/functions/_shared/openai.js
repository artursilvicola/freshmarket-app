var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var openai_exports = {};
__export(openai_exports, {
  fetchWebsiteSnippet: () => fetchWebsiteSnippet,
  openAiChat: () => openAiChat,
  stripHtmlToText: () => stripHtmlToText
});
module.exports = __toCommonJS(openai_exports);
async function openAiChat({
  apiKey,
  model = "gpt-4.1-mini",
  system,
  user,
  temperature = 0.4,
  responseFormat = null
}) {
  const payload = {
    model,
    temperature,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user }
    ]
  };
  if (responseFormat) {
    payload.response_format = responseFormat;
  }
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = null;
  }
  if (!res.ok) {
    throw new Error(json?.error?.message || text || "OpenAI request failed");
  }
  const content = json?.choices?.[0]?.message?.content;
  if (!content) throw new Error("OpenAI returned empty content");
  return typeof content === "string" ? content.trim() : String(content).trim();
}
function stripHtmlToText(html = "", limit = 4e3) {
  const withoutScripts = String(html).replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");
  return withoutScripts.replace(/<[^>]+>/g, " ").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/\s+/g, " ").trim().slice(0, limit);
}
async function fetchWebsiteSnippet(url) {
  if (!url) return { finalUrl: null, text: "" };
  try {
    const parsed = new URL(url);
    if (!/^https?:$/i.test(parsed.protocol)) return { finalUrl: null, text: "" };
    const res = await fetch(parsed.toString(), {
      headers: {
        "User-Agent": "FreshMarketB2B-AI/1.0",
        Accept: "text/html,application/xhtml+xml"
      }
    });
    if (!res.ok) return { finalUrl: parsed.toString(), text: "" };
    const html = await res.text();
    return {
      finalUrl: res.url || parsed.toString(),
      text: stripHtmlToText(html)
    };
  } catch {
    return { finalUrl: null, text: "" };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  fetchWebsiteSnippet,
  openAiChat,
  stripHtmlToText
});
