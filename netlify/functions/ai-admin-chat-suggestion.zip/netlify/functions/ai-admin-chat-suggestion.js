var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ai_admin_chat_suggestion_exports = {};
__export(ai_admin_chat_suggestion_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ai_admin_chat_suggestion_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_function_env = require("./_shared/function-env.js");
var import_openai = require("./_shared/openai.js");
var import_load_kompendium = require("./_shared/load-kompendium.js");
var import_error_messages = require("./_shared/error-messages.js");
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const handler = async (event) => {
  const acceptLang = event.headers["accept-language"] || event.headers["Accept-Language"];
  let locale = (0, import_error_messages.resolveLocale)({ acceptLanguage: acceptLang });
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST") return json(405, { error: (0, import_error_messages.errLoc)(locale, "method_not_allowed") });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseAnonKey", "supabaseServiceRoleKey", "openAiApiKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("ai-admin-chat-suggestion", missing));
  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader?.startsWith("Bearer ")) return json(401, { error: (0, import_error_messages.errLoc)(locale, "no_auth_header") });
  const token = authHeader.slice(7);
  const supaUser = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } }
  });
  const { data: userData, error: userErr } = await supaUser.auth.getUser(token);
  if (userErr || !userData?.user) return json(401, { error: (0, import_error_messages.errLoc)(locale, "invalid_token") });
  const supaSvc = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: caller, error: callerErr } = await supaSvc.from("profiles").select("id, role, name, email, locale").eq("id", userData.user.id).maybeSingle();
  if (callerErr || caller?.role !== "admin") {
    return json(403, { error: (0, import_error_messages.errLoc)(locale, "only_admin_ai_chat") });
  }
  locale = (0, import_error_messages.resolveLocale)({ profileLocale: caller.locale, acceptLanguage: acceptLang });
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: (0, import_error_messages.errLoc)(locale, "invalid_json") });
  }
  locale = (0, import_error_messages.resolveLocale)({ bodyLocale: body.locale, profileLocale: caller.locale, acceptLanguage: acceptLang });
  const participant = {
    name: text(body.participant?.name) || "Uczestnik",
    role: text(body.participant?.role) || "supplier",
    title: text(body.participant?.title) || null
  };
  const thread = Array.isArray(body.thread) ? body.thread.map((msg) => ({
    author: text(msg.author) || "user",
    text: text(msg.text) || "",
    timestamp: text(msg.timestamp) || null
  })).filter((msg) => msg.text).slice(-12) : [];
  if (!thread.length) return json(400, { error: (0, import_error_messages.errLoc)(locale, "missing_chat_messages") });
  const km = (0, import_load_kompendium.loadKompendium)();
  if (!km.ok) console.warn("[ai-admin-chat-suggestion] kompendium fallback:", km.reason);
  const systemPrompt = buildSystemPrompt(km.content);
  const userPrompt = buildSuggestionPrompt(participant, thread);
  const suggestion = await (0, import_openai.openAiChat)({
    apiKey: env.openAiApiKey,
    model: env.openAiModel,
    system: systemPrompt,
    user: userPrompt,
    temperature: 0.4
  });
  return json(200, {
    ok: true,
    suggestion: cleanSuggestion(suggestion),
    kompendium_loaded: km.ok,
    kompendium_files: km.loaded
  });
};
function buildSystemPrompt(kompendiumContent) {
  const introRules = [
    "Jeste\u015B asystentem administratora Fresh Market. Pomagasz adminowi formu\u0142owa\u0107 odpowiedzi na pytania dostawc\xF3w (suppliers) i kupc\xF3w (buyers) w panelu PreConnect.",
    "",
    "\u2550\u2550\u2550 NAJWA\u017BNIEJSZE \u2014 JAK CZYTA\u0106 HISTORI\u0118 WIADOMO\u015ACI \u2550\u2550\u2550",
    "- OSTATNIA wiadomo\u015B\u0107 w historii to AKTUALNE pytanie, na kt\xF3re masz odpowiedzie\u0107.",
    "- Wcze\u015Bniejsze wiadomo\u015Bci to TYLKO KONTEKST \u2014 nie odno\u015B si\u0119 do nich, chyba \u017Ce ostatnia wiadomo\u015B\u0107 bezpo\u015Brednio o nie pyta.",
    "- Je\u015Bli ostatnia wiadomo\u015B\u0107 to nowe pytanie, IGNORUJ tematy z wcze\u015Bniejszych wiadomo\u015Bci.",
    "- Przyk\u0142ad: je\u015Bli rozm\xF3wca napisa\u0142 wcze\u015Bniej o aktywacji konta, a w ostatniej wiadomo\u015Bci pyta o cen\u0119 udzia\u0142u \u2014 odpowiadasz TYLKO na pytanie o cen\u0119.",
    "",
    "ZASADY FORMATOWANIA:",
    "- Odpowiadasz w j\u0119zyku rozm\xF3wcy (PL lub EN \u2014 zale\u017Cnie od ostatniej wiadomo\u015Bci).",
    "- Styl: \u017Cyczliwy, rzeczowy, biznesowy. 2\u20135 zda\u0144. Bez bullet\xF3w, bez nag\u0142\xF3wk\xF3w, bez cudzys\u0142ow\xF3w.",
    "- Bez podpisu na ko\u0144cu (admin dodaje sam).",
    "- Kr\xF3tko: max 80 s\u0142\xF3w.",
    "",
    "ZASADY MERYTORYCZNE (KRYTYCZNE \u2014 NIE HALUCYNUJ):",
    "- Korzystaj WY\u0141\u0104CZNIE z fakt\xF3w z bazy wiedzy poni\u017Cej. NIE wymy\u015Blaj danych.",
    "- Zakaz wymy\u015Blania liczb, cen, termin\xF3w, zasad, mechanizm\xF3w. Je\u015Bli czego\u015B nie ma w bazie wiedzy poni\u017Cej \u2014 NIE pisz tego.",
    "- Zakaz pisania o '14 dniach zwrotu kredytu' lub podobnych nieaktualnych zasadach billingu \u2014 model rozlicze\u0144 to NIE jest dzi\u015B relewantne dla pyta\u0144 o cen\u0119 udzia\u0142u w evencie.",
    "- Nigdy nie obiecuj rzeczy nieoczywistych: spotkania 1:1 zale\u017C\u0105 od akceptacji kupc\xF3w, finalny harmonogram od algorytmu i admina.",
    "- Je\u015Bli pytanie wykracza poza baz\u0119 wiedzy \u2014 odpowiedz uczciwie 'sprawdz\u0119 i wr\xF3c\u0119 z konkretn\u0105 odpowiedzi\u0105' albo skieruj do Oksany (oksana@freshmarket.eu, +48 509 086 949).",
    "",
    "MAPOWANIE PYTA\u0143 NA CZ\u0118\u015ACI BAZY:",
    "- 'Ile kosztuje udzia\u0142?', 'Cena pakietu?', 'Ile za stoisko?' \u2192 Cz\u0119\u015B\u0107 B sekcje 8 (pakiety) + 9 (cennik) + 10 (stoiska).",
    "- 'Kiedy event?', 'Gdzie?', 'Agenda?' \u2192 Cz\u0119\u015B\u0107 B sekcje 0, 1, 7.",
    "- 'Jak dzia\u0142aj\u0105 spotkania B2B?', 'Co to networking?' \u2192 Cz\u0119\u015B\u0107 B sekcje 5, 6.",
    "- 'Jak zalogowa\u0107 si\u0119?', 'Jak doda\u0107 ofert\u0119?', 'Jak dzia\u0142a PreConnect?' \u2192 Cz\u0119\u015B\u0107 A.",
    "- 'Kiedy mog\u0119 aktywowa\u0107 konto?', 'Kiedy plan spotka\u0144?' \u2192 Cz\u0119\u015B\u0107 B sekcja 18 (wa\u017Cne daty)."
  ];
  if (!kompendiumContent) {
    introRules.push(
      "",
      "MINIMALNA BAZA FAKT\xD3W (fallback \u2014 pe\u0142na baza wiedzy nie za\u0142adowa\u0142a si\u0119):",
      "- Fresh Market 2026: 24 wrze\u015Bnia 2026, O\u017Car\xF3w Mazowiecki, Ptak Warsaw Expo.",
      "- Plan spotka\u0144 publikowany 22 wrze\u015Bnia po korektach admina.",
      "- Kontakt do organizatora: Oksana Koz\u0142owska, oksana@freshmarket.eu, +48 509 086 949.",
      "- PreConnect (b2b.freshmarket.eu) = panel B2B z profilami firm, ofertami, matchmakingiem i harmonogramem spotka\u0144."
    );
    return introRules.join("\n");
  }
  introRules.push(
    "",
    "BAZA WIEDZY sk\u0142ada si\u0119 z DW\xD3CH CZ\u0118\u015ACI \u2014 czytaj OBYDWIE przed ka\u017Cd\u0105 odpowiedzi\u0105:",
    "  \u2022 CZ\u0118\u015A\u0106 A \u2014 Kompendium PreConnect (panel B2B): role, workflow, pakiety wysy\u0142ek, FAQ techniczne.",
    "  \u2022 CZ\u0118\u015A\u0106 B \u2014 Kompendium Fresh Market 2026 (event): cennik uczestnictwa, pakiety Standard/Business/Premium, stoiska, agenda, FAQ klienta.",
    "",
    "Pytania o panel B2B / oferty / wysy\u0142ki \u2192 CZ\u0118\u015A\u0106 A.",
    "Pytania o cen\u0119 udzia\u0142u / pakiety / stoiska / agend\u0119 / faktur\u0119 \u2192 CZ\u0118\u015A\u0106 B.",
    "Je\u015Bli pytanie mieszane \u2014 \u0142\u0105cz obie cz\u0119\u015Bci.",
    "",
    kompendiumContent.trim()
  );
  return introRules.join("\n");
}
function buildSuggestionPrompt(participant, thread) {
  const lastFromParticipant = [...thread].reverse().find((msg) => msg.author !== "admin");
  const lastQuestion = lastFromParticipant?.text || "(brak)";
  const history = thread.map((msg, i) => {
    const isLast = i === thread.length - 1;
    const role = msg.author === "admin" ? "Admin" : participant.name;
    return `${isLast ? "\u2192 " : "  "}${role}: ${msg.text}`;
  }).join("\n");
  return [
    `ROZM\xD3WCA: ${participant.name} (rola: ${participant.role}${participant.title ? `, ${participant.title}` : ""})`,
    "",
    "HISTORIA WIADOMO\u015ACI (od najstarszej, strza\u0142ka \u2192 wskazuje OSTATNI\u0104):",
    history,
    "",
    "\u2550\u2550\u2550 AKTUALNE PYTANIE (na to MASZ odpowiedzie\u0107) \u2550\u2550\u2550",
    lastQuestion,
    "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",
    "",
    "ZADANIE:",
    "1. Zidentyfikuj o co PYTA rozm\xF3wca w AKTUALNYM PYTANIU powy\u017Cej.",
    "2. Znajd\u017A odpowied\u017A w bazie wiedzy (Cz\u0119\u015B\u0107 A albo B \u2014 patrz MAPOWANIE PYTA\u0143 w system prompt).",
    "3. Napisz JEDN\u0104 gotow\u0105 odpowied\u017A administratora (2\u20135 zda\u0144, max 80 s\u0142\xF3w, bez podpisu, bez cudzys\u0142ow\xF3w, w j\u0119zyku rozm\xF3wcy).",
    "4. Je\u015Bli odpowied\u017A wymaga liczb/cen/dat \u2014 WY\u0141\u0104CZNIE z bazy wiedzy. Je\u015Bli czego\u015B nie ma \u2014 napisz 'sprawdz\u0119 i wr\xF3c\u0119 z konkretami' albo skieruj do Oksany.",
    "5. NIE odpowiadaj na wcze\u015Bniejsze tematy z historii \u2014 tylko na AKTUALNE PYTANIE."
  ].join("\n");
}
function cleanSuggestion(value) {
  return String(value || "").replace(/\s+\n/g, "\n").trim();
}
function text(value) {
  if (value == null) return null;
  const next = String(value).trim();
  return next || null;
}
function json(statusCode, payload) {
  return {
    statusCode,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
