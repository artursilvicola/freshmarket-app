var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fm_plan_send_exports = {};
__export(fm_plan_send_exports, {
  artefactPath: () => artefactPath,
  findCard: () => findCard,
  handler: () => handler,
  idempotencyKey: () => idempotencyKey,
  renderCardPdf: () => renderCardPdf,
  webpToPngDataUri: () => import_fm_plan_logos.webpToPngDataUri
});
module.exports = __toCommonJS(fm_plan_send_exports);
var import_node_crypto = require("node:crypto");
var import_supabase_js = require("@supabase/supabase-js");
var import_pdfmake = __toESM(require("pdfmake"), 1);
var import_function_env = require("./_shared/function-env.js");
var import_fm_plan_raw = require("./_shared/fm-plan-raw.js");
var import_fm_plan_logos = require("./_shared/fm-plan-logos.js");
var import_model = require("../../src/lib/fm-plan/model.js");
var import_layout = require("../../src/lib/fm-plan/layout.js");
var import_fonts = require("../../src/lib/fm-plan/fonts.js");
const json = (statusCode, body) => ({ statusCode, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }, body: JSON.stringify(body) });
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PUBLISHED_PHASES = /* @__PURE__ */ new Set(["published", "final_published", "event_day"]);
const BUCKET = "fm-plan-cards";
const LEDGER = "fm_plan_deliveries";
const IDEMPOTENCY_WINDOW_MS = 24 * 60 * 60 * 1e3;
const uniqueEmails = (rows) => [...new Set((rows || []).map((row) => String(row.email || "").trim().toLowerCase()).filter((email) => EMAIL_RE.test(email)))];
const slug = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/&amp;/g, "and").replace(/[^A-Za-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48);
const sha256 = (buf) => (0, import_node_crypto.createHash)("sha256").update(buf).digest("hex");
const planTag = (ts) => String(ts).replace(/[^0-9]/g, "").slice(0, 20);
const idempotencyKey = (kind, targetId, planAt, email, suffix = "") => `fm2026-${kind}-${String(targetId).replace(/[^0-9A-Za-z]/g, "")}-${sha256(String(email).toLowerCase()).slice(0, 24)}-${planTag(planAt)}${suffix}`;
function findCard(model, kind, id) {
  if (kind === "supplier") return model.suppliers.find((s) => String(s.id) === String(id)) || null;
  const rid = Number(id);
  if (!Number.isInteger(rid) || rid <= 0) return null;
  return model.chains.find((c) => Number(c.id) === rid) || null;
}
let printer = null;
function getPrinter() {
  if (!printer) {
    const fonts = Object.fromEntries(Object.entries(import_fonts.FM_PLAN_FONT_FAMILIES).map(([fam, v]) => [fam, Object.fromEntries(Object.entries(v).map(([k, f]) => [k, Buffer.from(import_fonts.FM_PLAN_FONTS_VFS[f], "base64")]))]));
    printer = new import_pdfmake.default(fonts);
  }
  return printer;
}
function renderCardPdf(card, mode) {
  const def = card.kind === "supplier" ? (0, import_layout.supplierDoc)(card, { mode }) : (0, import_layout.chainDoc)(card, { mode });
  return new Promise((resolve, reject) => {
    const doc = getPrinter().createPdfKitDocument(def);
    const chunks = [];
    doc.on("data", (c) => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    doc.end();
  });
}
const artefactPath = (kind, targetId, planAt) => `${planTag(planAt)}/${kind}-${String(targetId).replace(/[^0-9A-Za-z-]/g, "")}.json`;
async function getOrCreateManifest(db, path, build) {
  const bucket = db.storage.from(BUCKET);
  const parse = async (blob) => {
    const m = JSON.parse(Buffer.from(await blob.arrayBuffer()).toString("utf8"));
    if (m?.v !== 1 || !m.pdf_base64) throw new Error("artefact_manifest_invalid");
    return m;
  };
  const first = await bucket.download(path);
  if (!first.error && first.data) return { manifest: await parse(first.data), reused: true };
  const manifest = await build();
  const up = await bucket.upload(path, Buffer.from(JSON.stringify(manifest), "utf8"), { contentType: "application/json", upsert: false });
  if (!up.error) return { manifest, reused: false };
  const again = await bucket.download(path);
  if (!again.error && again.data) return { manifest: await parse(again.data), reused: true };
  throw new Error("artefact_store_failed: " + String(up.error.message || up.error));
}
async function resolveRecipients(db, kind, card) {
  if (kind === "supplier") {
    const { data: company, error: error2 } = await db.from("companies").select("id, name, fm_b2b_enabled, account_status, fm_plan_sent_at").eq("id", card.id).maybeSingle();
    if (error2) return { error: "company_lookup_failed" };
    if (!company || company.fm_b2b_enabled !== true || ["suspended", "rejected"].includes(company.account_status)) return { error: "supplier_not_eligible" };
    const { data: profiles2, error: profilesError2 } = await db.from("profiles").select("email, role, active").eq("company_id", company.id).eq("role", "supplier");
    if (profilesError2) return { error: "supplier_recipients_lookup_failed" };
    return { name: company.name, recipients: uniqueEmails((profiles2 || []).filter((p) => p.active !== false)) };
  }
  const { data: retailer, error } = await db.from("retailers").select("id, name, fm26_active, fm_plan_sent_at").eq("id", card.id).maybeSingle();
  if (error) return { error: "retailer_lookup_failed" };
  if (!retailer || retailer.fm26_active !== true) return { error: "retailer_not_eligible" };
  const { data: profiles, error: profilesError } = await db.from("profiles").select("email, role, active, fm26_active").eq("retailer_id", retailer.id).eq("role", "buyer");
  if (profilesError) return { error: "buyer_recipients_lookup_failed" };
  return { name: retailer.name, recipients: uniqueEmails((profiles || []).filter((p) => p.active !== false && p.fm26_active !== false)) };
}
const MAIL = {
  pl: {
    subject: (k) => k === "supplier" ? "Fresh Market 2026 \u2014 Tw\xF3j plan spotka\u0144 B2B (24 wrze\u015Bnia)" : "Fresh Market 2026 \u2014 kolejka spotka\u0144 B2B dla Pa\u0144stwa sieci (24 wrze\u015Bnia)",
    body: (k, name) => `
      <p>Dzie\u0144 dobry,</p>
      <p>w za\u0142\u0105czniku przesy\u0142amy ${k === "supplier" ? "<b>plan spotka\u0144 B2B</b> firmy <b>" + name + "</b>" : "<b>kolejk\u0119 spotka\u0144 B2B</b> dla sieci <b>" + name + "</b>"} na Fresh Market 2026 \u2014 <b>24 wrze\u015Bnia 2026</b>, MCC Mazurkas, O\u017Car\xF3w Mazowiecki (rejestracja 8:00\u20139:00).</p>
      <p>${k === "supplier" ? "Na karcie znajd\u0105 Pa\u0144stwo numery spotka\u0144, sieci handlowe i wej\u015Bcie (GATE 1 / GATE 2), przy kt\xF3rym stoi logo danej sieci. Obowi\u0105zuje kolejno\u015B\u0107 numer\xF3w, nie godziny \u2014 aktualnie obs\u0142ugiwane numery wida\u0107 w aplikacji <b>b2b.freshmarket.eu</b> i na du\u017Cym ekranie w sali spotka\u0144. Kart\u0119 warto wydrukowa\u0107 lub mie\u0107 w telefonie." : "Na karcie znajd\u0105 Pa\u0144stwo kolejno\u015B\u0107 dostawc\xF3w (z logo, krajem, kr\xF3tkim opisem i kontaktem), informacje o dniu spotka\u0144 oraz kontakty do naszego zespo\u0142u. Spotkania zaczynaj\u0105 si\u0119 o 10:00 (na \u017Cyczenie od 9:00), lunch 13:00\u201314:00, koniec rozm\xF3w B2B o 17:00, po czym zapraszamy na uroczyst\u0105 kolacj\u0119 (sala Bolero)."}</p>
      <p>Pytania w dniu wydarzenia: Oksana Koz\u0142owska (PL) \xB7 oksana@freshmarket.eu \xB7 tel. +48 509 086 949; Jagoda Knadel (EN) \xB7 jagoda.knadel@freshmarket.eu \xB7 tel./WhatsApp +48 603 811 818.</p>
      <p>Do zobaczenia na Fresh Market!<br>Zesp\xF3\u0142 Fresh Market \xB7 support@freshmarket.eu</p>`
  },
  en: {
    subject: (k) => k === "supplier" ? "Fresh Market 2026 \u2014 your B2B meeting schedule (24 September)" : "Fresh Market 2026 \u2014 B2B meeting queue for your chain (24 September)",
    body: (k, name) => `
      <p>Dear Partner,</p>
      <p>please find attached ${k === "supplier" ? "the <b>B2B meeting schedule</b> for <b>" + name + "</b>" : "the <b>B2B meeting queue</b> for <b>" + name + "</b>"} at Fresh Market 2026 \u2014 <b>24 September 2026</b>, MCC Mazurkas, O\u017Car\xF3w Mazowiecki near Warsaw (registration 8:00\u20139:00).</p>
      <p>${k === "supplier" ? "The card lists your meeting numbers, the retail chains and the entrance (GATE 1 / GATE 2) where each chain\u2019s logo is displayed. The order of numbers applies, not fixed times \u2014 the numbers currently being served are shown in the <b>b2b.freshmarket.eu</b> app and on the big screen in the meeting hall. Please print the card or keep it on your phone." : "The card lists the suppliers in meeting order (with logo, country, short description and contact), information about the meeting day and our team\u2019s contacts. Meetings start at 10:00 (from 9:00 on request), lunch 13:00\u201314:00, B2B meetings end at 17:00, followed by the gala dinner (Bolero hall)."}</p>
      <p>Questions on the day: Jagoda Knadel (EN) \xB7 jagoda.knadel@freshmarket.eu \xB7 tel./WhatsApp +48 603 811 818; Oksana Koz\u0142owska (PL) \xB7 oksana@freshmarket.eu \xB7 tel. +48 509 086 949.</p>
      <p>See you at Fresh Market!<br>Fresh Market Team \xB7 support@freshmarket.eu</p>`
  }
};
async function sendViaResend(env, { to, subject, html, filename, pdf, tag, idempotencyKey: key, from = "Fresh Market <newsletter@freshmarket.eu>", reply_to = "support@freshmarket.eu" }) {
  const headers = { "Content-Type": "application/json", Authorization: `Bearer ${env.resendApiKey}` };
  if (key) headers["Idempotency-Key"] = key;
  let res;
  try {
    res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers,
      body: JSON.stringify({
        from,
        reply_to,
        to: [to],
        subject,
        html,
        attachments: [{ filename, content: pdf.toString("base64") }],
        tags: [{ name: "fm2026", value: tag }]
      })
    });
  } catch (e) {
    return { error: "resend_network: " + String(e?.message || e).slice(0, 120), status: 0, uncertain: true };
  }
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    const conflict = res.status === 409 || /idempoten/i.test(detail);
    return { error: `resend_${res.status}${detail ? ": " + detail.slice(0, 200) : ""}`, status: res.status, conflict, uncertain: res.status >= 500 };
  }
  const sent = await res.json().catch(() => ({}));
  return { id: sent.id || null };
}
const sameInstant = (a, b) => {
  const x = Date.parse(a), y = Date.parse(b);
  return Number.isFinite(x) && Number.isFinite(y) && x === y;
};
async function handler(event) {
  if (event.httpMethod !== "POST") return json(405, { error: "method_not_allowed" });
  const env = (0, import_function_env.resolveEnvConfig)();
  const missing = (0, import_function_env.missingEnvNames)(env, ["supabaseUrl", "supabaseAnonKey", "supabaseServiceRoleKey", "resendApiKey"]);
  if (missing.length) return json(500, (0, import_function_env.envErrorPayload)("fm-plan-send", missing));
  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader?.startsWith("Bearer ")) return json(401, { error: "no_auth_header" });
  const token = authHeader.slice(7);
  const supaUser = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseAnonKey, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data: userData, error: uErr } = await supaUser.auth.getUser(token);
  if (uErr || !userData?.user) return json(401, { error: "invalid_token" });
  const db = (0, import_supabase_js.createClient)(env.supabaseUrl, env.supabaseServiceRoleKey);
  const { data: profile } = await db.from("profiles").select("role, email, active").eq("id", userData.user.id).maybeSingle();
  if (profile?.role !== "admin" || profile.active === false) return json(403, { error: "admin_only" });
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "invalid_json" });
  }
  if (body.kind !== "supplier" && body.kind !== "chain") return json(400, { error: "invalid_kind" });
  const kind = body.kind;
  const test = body.test === true;
  const force = body.force === true;
  if (body.pdfBase64 != null || body.logos != null) return json(400, { error: "client_payload_not_accepted" });
  const raw = await (0, import_fm_plan_raw.loadFmPlanRaw)(db);
  if (raw.error) return json(500, { error: raw.error });
  const phase = String(raw.settings?.algo_phase || "").trim().toLowerCase();
  const hasPlan = !!(raw.settings?.schedule && raw.plan_updated_at);
  if (!test) {
    if (!PUBLISHED_PHASES.has(phase)) return json(409, { error: "plan_not_published" });
    if (!hasPlan) return json(409, { error: "plan_missing" });
    if (!body.planUpdatedAt || !sameInstant(body.planUpdatedAt, raw.plan_updated_at)) return json(409, { error: "plan_changed", plan_updated_at: raw.plan_updated_at });
  }
  const model = (0, import_model.buildPlanModel)(raw, { simulate: test && !hasPlan });
  if (!test && model.mode !== "final") return json(409, { error: "plan_not_final" });
  const card = findCard(model, kind, body.id);
  if (!card) return json(400, { error: "card_not_found" });
  if (!card.meetings.length) return json(409, { error: "no_meetings" });
  const rec = await resolveRecipients(db, kind, card);
  if (rec.error) return json(400, { error: rec.error });
  const recipients = test ? uniqueEmails([{ email: profile.email }]) : rec.recipients;
  if (!recipients.length) return json(400, { error: test ? "admin_email_missing" : "no_canonical_recipients" });
  const name = String(rec.name || card.name || "").slice(0, 200);
  const filename = `${card.card}-${slug(name)}-${card.lang}.pdf`;
  const m = MAIL[card.lang === "pl" ? "pl" : "en"];
  const subject = (test ? "[TEST] " : "") + m.subject(kind);
  const html = m.body(kind, name);
  const targetId = String(card.id);
  if (test) {
    let logos2 = { attached: 0, requested: 0 }, pdf2;
    try {
      logos2 = await (0, import_fm_plan_logos.attachCanonicalLogos)(card, env.supabaseUrl);
    } catch {
    }
    try {
      pdf2 = await renderCardPdf(card, model.mode);
    } catch (e) {
      return json(500, { error: "render_failed", detail: String(e?.message || e).slice(0, 200) });
    }
    const testPath = `test/${raw.plan_updated_at ? planTag(raw.plan_updated_at) : "simulation"}/${kind}-${targetId.replace(/[^0-9A-Za-z-]/g, "")}.json`;
    const manifest = {
      v: 1,
      test: true,
      kind,
      target_id: targetId,
      plan_updated_at: raw.plan_updated_at,
      lang: card.lang,
      name,
      card: card.card,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      subject: "[TEST] " + m.subject(kind),
      html: m.body(kind, name),
      filename,
      tag: "plan-card-test",
      pdf_sha256: sha256(pdf2),
      pdf_base64: pdf2.toString("base64"),
      logos: logos2
    };
    const up = await db.storage.from(BUCKET).upload(testPath, Buffer.from(JSON.stringify(manifest), "utf8"), { contentType: "application/json", upsert: true });
    if (up.error) return json(500, { ok: false, test: true, error: "artefact_failed", detail: "artefact_store_failed: " + String(up.error.message || up.error).slice(0, 200), artefact: { path: testPath } });
    const r = await sendViaResend(env, { to: recipients[0], subject: manifest.subject, html: manifest.html, filename, pdf: pdf2, tag: manifest.tag });
    if (r.error) return json(502, { ok: false, test: true, mode: model.mode, filename, failed: [{ email: recipients[0], error: r.error }], logos: logos2, artefact: { path: testPath, stored: true } });
    return json(200, { ok: true, test: true, mode: model.mode, filename, sent: [recipients[0]], logos: logos2, artefact: { path: testPath, stored: true, sha256: manifest.pdf_sha256 } });
  }
  const result = { sent: [], already_sent: [], in_progress: [], unconfirmed: [], stale_unconfirmed: [], failed: [] };
  const { data: existing, error: ledgerError } = await db.from(LEDGER).select("id, email, status, created_at, attempts, attempt, attempt_started_at, idempotency_key").eq("kind", kind).eq("target_id", targetId).eq("plan_updated_at", raw.plan_updated_at);
  if (ledgerError) return json(500, { error: "deliveries_lookup_failed" });
  const byEmail = new Map((existing || []).map((r) => [String(r.email).toLowerCase(), r]));
  const now = () => (/* @__PURE__ */ new Date()).toISOString();
  const pending = recipients.filter((to) => byEmail.get(to)?.status !== "sent");
  for (const to of recipients) if (byEmail.get(to)?.status === "sent") result.already_sent.push(to);
  if (!pending.length) return json(200, { ok: true, mode: model.mode, filename, recipient_count: recipients.length, marked: false, plan_updated_at: raw.plan_updated_at, ...result });
  const path = artefactPath(kind, targetId, raw.plan_updated_at);
  let logos = null, art;
  try {
    art = await getOrCreateManifest(db, path, async () => {
      try {
        logos = await (0, import_fm_plan_logos.attachCanonicalLogos)(card, env.supabaseUrl);
      } catch {
        logos = { attached: 0, requested: 0 };
      }
      const pdf2 = await renderCardPdf(card, model.mode);
      return {
        v: 1,
        kind,
        target_id: targetId,
        plan_updated_at: raw.plan_updated_at,
        lang: card.lang,
        name,
        card: card.card,
        created_at: now(),
        from: "Fresh Market <newsletter@freshmarket.eu>",
        reply_to: "support@freshmarket.eu",
        subject: m.subject(kind),
        html: m.body(kind, name),
        filename,
        tag: `plan-card-${kind}`,
        pdf_sha256: sha256(pdf2),
        pdf_base64: pdf2.toString("base64"),
        logos
      };
    });
  } catch (e) {
    return json(500, { error: "artefact_failed", detail: String(e?.message || e).slice(0, 200) });
  }
  const M = art.manifest;
  const pdf = Buffer.from(M.pdf_base64, "base64");
  const pdfSha = M.pdf_sha256 || sha256(pdf);
  const mail = { subject: M.subject, html: M.html, filename: M.filename, pdf, tag: M.tag, from: M.from, reply_to: M.reply_to };
  for (const to of pending) {
    const prior = byEmail.get(to);
    let rowId, key, attempt, fresh = false;
    if (prior) {
      const started = Date.parse(prior.attempt_started_at || prior.created_at || 0);
      const stale = !(Date.now() - started <= IDEMPOTENCY_WINDOW_MS);
      rowId = prior.id;
      attempt = Number(prior.attempt) || 1;
      if (stale && !force) {
        result.stale_unconfirmed.push(to);
        continue;
      }
      if (stale) {
        const nextKey = idempotencyKey(kind, targetId, raw.plan_updated_at, to, `-a${attempt + 1}`);
        const { data: cas, error: casErr } = await db.from(LEDGER).update({ attempt: attempt + 1, attempt_started_at: now(), idempotency_key: nextKey, attempts: (Number(prior.attempts) || 0) + 1, last_error: null, pdf_path: path, pdf_sha256: pdfSha }).eq("id", rowId).eq("attempt", attempt).eq("status", "sending").select("id");
        if (casErr) {
          result.failed.push({ email: to, error: "delivery_update_failed" });
          continue;
        }
        if (!cas || !cas.length) {
          const { data: cur, error: curErr } = await db.from(LEDGER).select("id, status, attempt, idempotency_key").eq("id", rowId).maybeSingle();
          if (curErr || !cur) {
            result.failed.push({ email: to, error: "delivery_read_failed", uncertain: true });
            continue;
          }
          if (cur.status === "sent") {
            result.already_sent.push(to);
            continue;
          }
          if (cur.status !== "sending" || !cur.idempotency_key) {
            result.in_progress.push(to);
            continue;
          }
          attempt = Number(cur.attempt) || attempt;
          key = cur.idempotency_key;
        } else {
          attempt = attempt + 1;
          key = nextKey;
        }
      } else {
        key = prior.idempotency_key || idempotencyKey(kind, targetId, raw.plan_updated_at, to);
        const { error: bumpErr } = await db.from(LEDGER).update({ attempts: (Number(prior.attempts) || 0) + 1, idempotency_key: key, pdf_path: path, pdf_sha256: pdfSha }).eq("id", rowId);
        if (bumpErr) {
          result.failed.push({ email: to, error: "delivery_update_failed" });
          continue;
        }
      }
    } else {
      key = idempotencyKey(kind, targetId, raw.plan_updated_at, to);
      attempt = 1;
      const { data: claim, error: claimErr } = await db.from(LEDGER).insert({ kind, target_id: targetId, plan_updated_at: raw.plan_updated_at, email: to, status: "sending", sent_by: userData.user.id, idempotency_key: key, pdf_path: path, pdf_sha256: pdfSha, attempts: 1, attempt: 1, attempt_started_at: now() }).select("id").single();
      if (claimErr || !claim) {
        if (claimErr?.code === "23505") result.in_progress.push(to);
        else result.failed.push({ email: to, error: "delivery_claim_failed" });
        continue;
      }
      rowId = claim.id;
      fresh = true;
    }
    const r = await sendViaResend(env, { to, ...mail, idempotencyKey: key });
    if (r.error) {
      if (r.conflict) {
        await db.from(LEDGER).update({ last_error: r.error }).eq("id", rowId);
        result.failed.push({ email: to, error: "idempotency_conflict", detail: r.error });
        continue;
      }
      if (!r.uncertain && fresh) {
        await db.from(LEDGER).delete().eq("id", rowId).eq("status", "sending");
        result.failed.push({ email: to, error: r.error });
        continue;
      }
      await db.from(LEDGER).update({ last_error: r.error }).eq("id", rowId).eq("attempt", attempt);
      result.failed.push({ email: to, error: r.error, uncertain: true });
      continue;
    }
    const { data: done, error: doneErr } = await db.from(LEDGER).update({ status: "sent", resend_id: r.id, sent_at: now(), last_error: null }).eq("id", rowId).eq("attempt", attempt).select("id");
    if (doneErr || !done || !done.length) {
      result.unconfirmed.push(to);
      continue;
    }
    result.sent.push(to);
  }
  let marked = false;
  if (result.sent.length + result.already_sent.length === recipients.length) {
    const table = kind === "chain" ? "retailers" : "companies";
    const { error } = await db.from(table).update({ fm_plan_sent_at: now() }).eq("id", card.id);
    marked = !error;
  }
  const ok = ["failed", "in_progress", "unconfirmed", "stale_unconfirmed"].every((k) => result[k].length === 0);
  return json(200, {
    ok,
    mode: model.mode,
    filename: M.filename,
    recipient_count: recipients.length,
    marked,
    plan_updated_at: raw.plan_updated_at,
    artefact: { path, sha256: pdfSha, reused: art.reused },
    logos: logos || M.logos || null,
    ...result
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  artefactPath,
  findCard,
  handler,
  idempotencyKey,
  renderCardPdf,
  webpToPngDataUri
});
