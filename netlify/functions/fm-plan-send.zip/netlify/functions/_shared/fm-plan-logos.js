var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fm_plan_logos_exports = {};
__export(fm_plan_logos_exports, {
  __testing: () => __testing,
  attachCanonicalLogos: () => attachCanonicalLogos,
  canonicalLogoDataUri: () => canonicalLogoDataUri,
  downscaleRgba: () => downscaleRgba,
  encodePngRgba: () => encodePngRgba,
  isAllowedLogoUrl: () => isAllowedLogoUrl,
  isJpeg: () => isJpeg,
  isPng: () => isPng,
  isWebp: () => isWebp,
  webpToPngDataUri: () => webpToPngDataUri
});
module.exports = __toCommonJS(fm_plan_logos_exports);
var import_node_module = require("node:module");
var import_promises = require("node:fs/promises");
var import_node_zlib = require("node:zlib");
const import_meta = {};
const MAX_BYTES = 2 * 1024 * 1024;
const MAX_SIDE = 4e3;
const TARGET_W = 600, TARGET_H = 300;
const FETCH_TIMEOUT_MS = 4e3;
const CONCURRENCY = 6;
const CACHE_MAX = 300;
const cache = /* @__PURE__ */ new Map();
function resolveWasm() {
  const spec = "@jsquash/webp/codec/dec/webp_dec.wasm";
  if (typeof require === "function") return require.resolve(spec);
  const base = typeof __filename === "string" && __filename || typeof import_meta !== "undefined" && import_meta.url || null;
  return (0, import_node_module.createRequire)(base).resolve(spec);
}
let decoderReady = null;
async function webpDecoder() {
  if (!decoderReady) {
    decoderReady = (async () => {
      const mod = await import("@jsquash/webp/decode.js");
      const wasm = await WebAssembly.compile(await (0, import_promises.readFile)(resolveWasm()));
      await mod.init(wasm);
      return mod.default;
    })().catch((e) => {
      decoderReady = null;
      throw e;
    });
  }
  return decoderReady;
}
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 4294967295;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const td = Buffer.concat([Buffer.from(type, "ascii"), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(td), 0);
  return Buffer.concat([len, td, crc]);
}
function encodePngRgba(rgba, width, height) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0;
    Buffer.from(rgba.buffer, rgba.byteOffset + y * width * 4, width * 4).copy(raw, y * (width * 4 + 1) + 1);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", (0, import_node_zlib.deflateSync)(raw, { level: 6 })), chunk("IEND", Buffer.alloc(0))]);
}
function downscaleRgba(rgba, width, height, maxW = TARGET_W, maxH = TARGET_H) {
  const scale = Math.min(1, maxW / width, maxH / height);
  if (scale >= 1) return { data: rgba, width, height };
  const w = Math.max(1, Math.round(width * scale)), h = Math.max(1, Math.round(height * scale));
  const out = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) {
    const y0 = Math.floor(y * height / h), y1 = Math.max(y0 + 1, Math.floor((y + 1) * height / h));
    for (let x = 0; x < w; x++) {
      const x0 = Math.floor(x * width / w), x1 = Math.max(x0 + 1, Math.floor((x + 1) * width / w));
      let r = 0, g = 0, b = 0, a = 0, n = 0;
      for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
        const i = (yy * width + xx) * 4;
        const al = rgba[i + 3];
        r += rgba[i] * al;
        g += rgba[i + 1] * al;
        b += rgba[i + 2] * al;
        a += al;
        n++;
      }
      const o = (y * w + x) * 4;
      if (a > 0) {
        out[o] = r / a;
        out[o + 1] = g / a;
        out[o + 2] = b / a;
      }
      out[o + 3] = a / n;
    }
  }
  return { data: out, width: w, height: h };
}
const isWebp = (buf) => buf.length > 12 && buf.subarray(0, 4).toString("ascii") === "RIFF" && buf.subarray(8, 12).toString("ascii") === "WEBP";
const isPng = (buf) => buf.length > 8 && buf[0] === 137 && buf[1] === 80 && buf[2] === 78 && buf[3] === 71;
const isJpeg = (buf) => buf.length > 3 && buf[0] === 255 && buf[1] === 216 && buf[2] === 255;
async function webpToPngDataUri(buf) {
  const decode = await webpDecoder();
  const img = await decode(Uint8Array.from(buf).buffer);
  if (!img || !img.width || !img.height || img.width > MAX_SIDE || img.height > MAX_SIDE) return null;
  const small = downscaleRgba(img.data, img.width, img.height);
  return "data:image/png;base64," + encodePngRgba(small.data, small.width, small.height).toString("base64");
}
function isAllowedLogoUrl(url, supabaseUrl) {
  try {
    const u = new URL(String(url || ""));
    const base = new URL(String(supabaseUrl || ""));
    return u.protocol === "https:" && u.origin === base.origin && u.pathname.startsWith("/storage/v1/object/public/");
  } catch {
    return false;
  }
}
async function fetchBytes(url) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    const r = await fetch(url, { signal: ctrl.signal, redirect: "error" });
    if (!r.ok) return null;
    const len = Number(r.headers.get("content-length") || 0);
    if (len > MAX_BYTES) return null;
    const buf = Buffer.from(await r.arrayBuffer());
    return buf.length > MAX_BYTES ? null : buf;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function canonicalLogoDataUri(url, supabaseUrl) {
  if (!isAllowedLogoUrl(url, supabaseUrl)) return null;
  if (cache.has(url)) return cache.get(url);
  let out = null;
  try {
    const buf = await fetchBytes(url);
    if (buf) {
      if (isPng(buf)) out = "data:image/png;base64," + buf.toString("base64");
      else if (isJpeg(buf)) out = "data:image/jpeg;base64," + buf.toString("base64");
      else if (isWebp(buf)) out = await webpToPngDataUri(buf);
    }
  } catch {
    out = null;
  }
  if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value);
  cache.set(url, out);
  return out;
}
async function attachCanonicalLogos(card, supabaseUrl) {
  const jobs = [];
  jobs.push([card, card.logoUrl]);
  for (const m of card.meetings) {
    const target = card.kind === "supplier" ? m.chain : m.supplier;
    jobs.push([target, target.logoUrl]);
  }
  const byUrl = /* @__PURE__ */ new Map();
  for (const [, url] of jobs) if (url && !byUrl.has(url)) byUrl.set(url, null);
  const urls = [...byUrl.keys()];
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, urls.length) }, async () => {
    while (next < urls.length) {
      const url = urls[next++];
      byUrl.set(url, await canonicalLogoDataUri(url, supabaseUrl));
    }
  }));
  let attached = 0;
  for (const [target, url] of jobs) {
    target.logo = url ? byUrl.get(url) || null : null;
    if (target.logo) attached++;
  }
  return { attached, requested: urls.length };
}
const __testing = { cache };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  __testing,
  attachCanonicalLogos,
  canonicalLogoDataUri,
  downscaleRgba,
  encodePngRgba,
  isAllowedLogoUrl,
  isJpeg,
  isPng,
  isWebp,
  webpToPngDataUri
});
